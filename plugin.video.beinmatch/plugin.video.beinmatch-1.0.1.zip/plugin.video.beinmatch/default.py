# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,getnet,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error
################''
baseurl='http://aflam06.com'

##########################################parsing tools


def showmenu():
        
        addDir('مباريات اليوم','http://www.beinmatch.com/',101,'img/1.png','',1)
        addDir('اهداف وملخصات','http://www.beinmatch.com/home/videos',100,'img/2.png','',1)
       
        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  

        
        
         
 
          
       


def search(name,sterm,page):##may pastte code of getmovies here
                surl='http://aflam06.com/?s='

                if page>1:
                    
                        #https://www.almstba.tv/video/category.php?cat=english-movies&page=2&order=DESC
                       
                        page_url=baseurl+"/page/"+str(page)+"/"+"?s="+sterm
                  
                else:
                
                        page_url=surl+sterm
                print "url_page",page_url
                data=readnet(page_url)           
##################################################################                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('class="block"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<div class="title">(.*?)</div>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    href=href+"/?view=1"
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>8:
                    
                   addDir("next page",url,103,'img/next.png','',str(page+1))

                
                





               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                    
                        #http://www.beinmatch.com/home/videos/10
                        npage=int(page)-1
                        page_url='http://www.beinmatch.com/home/videos/'+str(npage*5)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
                
                blocks=data.split("tabIndex")
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                        

                            
                            
                    block=block.replace(';','')
                    regx=''' <div id="scoreStl" style=".*?">(.*?)</div>'''                    
                    try:
                            goals=re.findall(regx,block, re.M|re.I)
                    except:
                            trace_error()
                            
                    goals=str(goals)
                    
                    
                    regx="goToMatch(.*?,'(.*?)')"                  
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''url((.*?))'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    
                    print "title",title[1]
                    print "title1",title
                    href=str(title).split(",")[0]
                   
                    print "href",href
                   
                    href='http://www.beinmatch.com/home/live/'+href.replace('("(','')
                    
                    #title=title+"-"+tag        
                    try:
                      addDir(title[1]+"_"+goals,href,1,'','',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>4:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                

def getmovies2(name,url,page):##movies
               
               
                if page>1:
                    
                        #http://www.beinmatch.com/home/videos/10
                        npage=int(page)-1
                        page_url='http://www.beinmatch.com/home/videos/'+str(npage*5)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
                
                blocks=data.split("tabIndex")
                i=0
                
                
            
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
            
                    if 'لم يبدأ البث بعد' in block:
                            
                      tag='not started yet'
                    elif 'شاهد الأهداف' in block:
                            
                           
                            tag='FT'
                    else:
                            tag='watch now'   
                    
                    regx=''' <div id="scoreStl" style=".*?">(.*?)</div>'''                    
                    try:
                            goals=re.findall(regx,block, re.M|re.I)
                    except:
                            trace_error()
                            
                    goals=str(goals)
                    
                    #<button class="btn" onclick="goToMatch(3727,'الاتحاد_vs_الشباب');">
                                                                            
                    regx="goToMatch(.*?,'(.*?)')"
                    href=finddata(block,'goToMatch(',',')
                    print 'href', href
                   
                    regx1='''<td class="tdTeam">(.*?)</td>'''
                    regx2='''class="teamWrap">(.*?)</p></td>'''
                    try:
                            hteam=re.findall(regx1,block, re.M|re.I)[0]
                            ateam=re.findall(regx2,block, re.M|re.I)[0]
                            title=hteam+'-'+ateam
                    except:
                            trace_error()
                            continue

                    regx='''<td.*?>\s(.*?)GMT</td'''
                    try:
                            time=re.findall(regx,block, re.M|re.I)[0]
                            time=time.strip()+" GMT"
                    except:
                            time=''
                    regx='''url((.*?))'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    
                    try:title=title.encode('utf-8','ignore')
                    except:title=str(title)
                    
                    print "href",href
                    if tag=='not started yet':
                            href="Error:No started yet"
                    else:        
                       href='http://www.beinmatch.com/home/live/'+href
                    print 'tage'
                    title=time+" :"+title
                    try:
                      addDir(title+"-"+tag,href,2,'','',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
             
                
                







###############################################series


def getseries(name,url,page):##series
                if page>1:
                    
                        #https://www.almstba.tv/video/category.php?cat=english-movies&page=2&order=DESC
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('class="thumbnail animation-2"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''<img.*?src="(.*?)" alt="(.*?)".*?/>'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,100,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>50:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))




                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,url,page):##series

                print "page",page
               
                if page>1:
                    
                        #http://www.movs4u.com/movie/page/2/
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=readnet(page_url)
               
                
                
               
                if data is None:
                    return
               
                #blocks=data.split('قائمة الحلقات:')
                regx='''<li><a target="_blank" href="(.*?)" title=".*?">(.*?)</a></li>'''
                match=re.findall(regx,tblock, re.M|re.I)
                print "match",match
                for href,title in match:
                    addDir(title,href,1,'','',1,maintitle=True)    
                i=0
                return 


#######################################host resolving
def get_youtube_link(value):
    """
    Examples:
    - http://youtu.be/SA2iWivDJiE
    - http://www.youtube.com/watch?v=_oPAwA_Udwc&feature=feedu
    - http://www.youtube.com/embed/SA2iWivDJiE
    - http://www.youtube.com/v/SA2iWivDJiE?version=3&amp;hl=en_US
    -'plugin://plugin.video.youtube/?action=play_video&amp;videoid=FBBLhRgrw0o'
    """
    from urlparse import urlparse
    vid=None
    if value is None:
        return None
    else:
        value = value.strip()
        if value.startswith('plugin://'):
           
            try:
                vid = value.split('=')[value.count('=')]
                
            except:
                return None
        else:
            query = urlparse(value)
            if query.hostname == 'youtu.be':
                vid= query.path[1:]
            elif query.hostname in ('www.youtube.com', 'youtube.com'):
                if query.path == '/watch':
                    p = parse_qs(query.query)
                    vid= p['v'][0]
                if query.path[:7] == '/embed/':
                    vid= query.path.split('/')[2]
                if query.path[:3] == '/v/':
                    vid=query.path.split('/')[2]
            
        addDir('play','plugin://plugin.video.youtube/?action=play_video&videoid=%s' % vid,0,'','',1,link=True)    
        #return 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % vid

        
def getservers2(name,url):
         data=readnet(url)
         regx='''source: "(.*?)"'''
         href=finddata(data,'source:',",")
         if not href:
            getservers(name,url)
            return
         href=href.replace('"','').strip()
         addDir("play",href,0,"","",1,link=True)
         return

def getservers(name,url):
                data=readnet(url)
                regx='''<link rel='shortlink' href='(.*?)' />'''
                regx='''<iframe.*?src="(.*?)".*?></iframe'''
                try:
                        id=re.findall(regx,data, re.M|re.I)[0]
                        print "id",id
                except:
                   getservers2(name,url)
                   return
                        
                
                print "id",id
                
                if 'ok.php' in id:
                   id=id.split('id=')[1].split('?')[0]
                   print "finalid",id
                   link='http://ok.ru/videoembed/'+id
                   resolvehost(link)
                elif "dailymotion" in id:
                        resolvehost(id)
                        return
                elif 'youtube' in id:
                      get_youtube_link(link)  
                
                            
                
                return
                #http://aflam06.com/wp-content/themes/YourColor/servers/server.php?q=11878&i=1
                for i in range(1,8):
                        href='http://aflam06.com/wp-content/themes/YourColor/servers/server.php?q='+id+'&i='+str(i)

                        
                   
                        data=readnet(href)

                        regx='''<iframe.*?src="(.*?)".*?</iframe>'''
                        regx2="<iframe.*?src='(.*?)'.*?</iframe>"
                        try:
                                href=re.findall(regx,data.lower(), re.M|re.I)[0]
                        except:
                                
                                try:href=re.findall(regx2,data, re.M|re.I)[0]
                                except:continue
                        server=getDomain(href)
                        addDir(server,href,2,"img/server.png",'',1)
                 
def resolve_host(url):
        resolve_host(url)    

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        getservers2(name,url)       
elif mode==3:
        print ""+url
        playlink(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getmovies2(name,url,page)

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
        sterm = getsearchtext()      
         
        search("Search",sterm,page) 
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
