# -*- coding: utf8 -*-
try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
import urllib2,urllib
import re
import httplib
import time,itertools
__settings__ = xbmcaddon.Addon(id='plugin.video.anakbnet')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = (sys.argv[0])
baseurl='http://www.anakbnet.com/'
def read_url2(url):
        try:
            req = urllib2.Request(url)
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
            return data
        except urllib2.URLError, e:
            print 'URL: '+url
            if hasattr(e, 'code'):
                print 'We failed with error code - %s.' % e.code
            elif hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: %s' %e.reason
def read_url3(url):#redirect error
        try:
           p = urllib2.build_opener(urllib2.HTTPCookieProcessor).open(url)
           return p.read()
        except:
                addDir("Download failed:","","",'')      
                return None
def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.anakbnet.com')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link
def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial
    return inner                                                                                                                                                                            
def getCategories():
        #addDir('Search','http://www.anakbnet.com/video/search.php',3,'img/SEARCH.png',1)
        
        addDir('أفلام عربية أون لاين','http://www.anakbnet.com/video/browse.php?c=1&p=1',11,'img/2.png',1)
        #addDir('أفلام أجنبية اون لاين','http://www.anakbnet.com/video/',11,'img/1.jpg',1)
        addDir('أفلام أجنبية اون لاين','http://www.anakbnet.com/video/browse.php?c=2&p=1',11,'img/1.jpg',1)
	addDir('افلام منوعه','http://www.anakbnet.com/video/browse.php?c=11&p=1',11,'img/1.jpg',1)
		
	addDir('أفلام كارتون مدبلجة أون لاين','http://www.anakbnet.com/video/browse.php?c=3&p=1',11,'img/3.jpg',1)
	
	
	
	
    
        
       
def search():
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   print "mfarajx3",search_entered
        else:
             print "search error"

        url='http://www.anakbnet.com/?s=' +search_entered  
        
        getVideos("Search",url,1)
               


               
def getVideos(name1, urlmain,page):
               if page>1:
                  #http://www.anakbnet.com/cdep2-p2.html
                  
                  url_page=urlmain.replace(".html","-p"+str(page)+".html") 
                  url_page=urlmain+'/&p='+str(page)
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               
	       regx='''<a href="(.*?)">\s*<div class="image">\s*<img src="(.*?)" alt="(.*?)" .*?/>'''
               regx='''<a href='(.*?)'>\s*<img src='(.*?)' .*? alt="(.*?)" .*?/>'''
               regx='''<div class="icon">\s*<a href="(.*?)">\s*<img src="(.*?)" .*? alt="(.*?)" .*? />'''
               
               
        		
               
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               if not match :
                       return
               for href,image,title in match:
                        pic = ''
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        title=title.replace("مشاهدة وتحميل فيلم","")
                        title=title.replace("اون لاين","")
                        addDir(name,url,2, image,page)
               addDir('next page>',urlmain, 1,'http://ewastealternatives.org/sites/default/files/images/nextBUTTON.png',str(page+1))               
               
               
               
               
               
               
               
               
               
               
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    addDir(server,href,7,'')
def get_servers(url):
	        data=read_url(url)
	        data=data.lower()
                	
                
                regx='''<iframe .+?src="(.+?)".+?></iframe>'''
                
                
                link = re.findall(regx,data, re.M|re.I)[0]
                import urlresolver
                print "link",link
                
                stream_link = urlresolver.resolve(link)
                
                if stream_link is None or "unresolvable" in stream_link:
                       addDir("Error:unresolvable link","",1,"",1)
                       return
                playlink( stream_link )     
            

            


                
def resolve_host(url):
    if 'vk.com' in url:
            stream_link=resolve_vk(url)
    elif "youwatch" in url:
            stream_link=resolve_youwatch(url)
    elif 'dailymotion' in url:
            print "mfarajx5",url
            if not url.startswith('http:'):
                    url='http:'+url
      
            stream_link=resolve_dailymotion(url)
    elif 'youtube' in url:
        videoid = get_youtube_videoid(url)
        stream_link = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
        listItem = xbmcgui.ListItem(path=str(stream_link))
        xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)
        return    
    else:        
      import urlresolver
      stream_link = urlresolver.resolve(url)
      print "stream_link",stream_link
      if stream_link is None or "unresolvable" in stream_link:
            addDir("Error:unresolvable link","",1,"",1)
            return
    listItem = xbmcgui.ListItem(path=str(stream_link))
    xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem) 
def get_hostlink(url):
	        data=read_url2(url)
                regx='''<iframe src="(.+?)" width='''
                match = re.findall(regx,data, re.M|re.I)
                print 'match-mfaraj',match,url
                if len(match)<1:
                        regx="'proxy.link'.+?'(.+?)'"
                        match = re.findall(regx,data, re.M|re.I)
                        print 'match-mfaraj2',match,url                        
                i=0
                for href in match:
                    i=i+1
                    server='link1'+str(i)
                    addLink(server,href,7,'')
def resolve_youwatch(url):
		print 'youwatch data'
		from packer import unpack, detect
		data=read_url2(url)
		get_packedjava = re.search("<script type=.text.javascript.>(eval.function.*?)</script>", data, re.S|re.DOTALL)
		if get_packedjava and detect(get_packedjava.group(1)):
			print 'get_packedjava'
			sJavascript = get_packedjava.group(1)
			sUnpacked = unpack(sJavascript)
			if sUnpacked:
				print "unpacked"
				stream_url = re.search('file:"(.*?)"', sUnpacked, re.S)
				if stream_url:
					link= stream_url.group(1)
					return link
		print "no valic stream link found"
                return None    
def resolve_vk(url):
        web_url =url
        print "45m",web_url
        debug=True
        from addon.common.net import Net
        import json as json
        net = Net()
        try:
            soup   = net.http_GET(web_url).content
            html   = soup.decode('cp1251')
            print "html",html
            vars_s = re.findall("""var vars = (.+)""",html)
            if vars_s :
                jsonvars        = json.loads(vars_s[0])
                purged_jsonvars = {}
                for item in jsonvars :
                    if re.search('url[0-9]+', str(item)) :
                        purged_jsonvars[item] = jsonvars[item]               
                lines  = []
                ls_url = []
                for item in purged_jsonvars :
                    ls_url.append(item)
                    quality = item.lstrip('url')
                    lines.append(str(quality))
                if len(ls_url) == 1 :
                    return purged_jsonvars[ls_url[0]].encode('utf-8')
                result =1
                if result != -1 :
                    return purged_jsonvars[ls_url[result]].encode('utf-8')
                else :
                    return None
            else :
                return "No links found"
        except urllib2.URLError, e:            
            print 'Error','Http error: '+str(e)            
        except Exception, e:
            print '**** VK Error occured: %s' % e
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]                                
        return param

def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
def addDir(name,url,mode,iconimage,page=1):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
params=get_params()
url=None
name=None
mode=None
initial=None
max=None
rating=None
cast=None
year=None
genre=None
duration=None
writer=None
director=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
	
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        page=1
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
if mode==None or url==None or len(url)<1:
        print ""
        getCategories()
elif mode==1:
        print ""+url
        getVideos(name,url,page)
elif mode==11:
        print ""+url
        getVideos(name,url,page)
elif mode==3:
        print ""+url        
        GENRES(url)
elif mode==5:
        print ""+url        
        language(url)
elif mode==2:
        print ""+url
        get_servers(url)
elif mode==3:
        print ""+url
        search()		
elif mode==6:
        print ""+url
        get_hostlink(url)
elif mode==7:
        resolve_host(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
