# -*- coding: utf8 -*-



import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,downloadImage,resolvehost,finddata,trace_error,finditems,finditem
################''
baseurl='https://myegy.tv'

##########################################parsing tools


def showmenu():
        ##main
	addDir('search','https://myegy.tv/latest?search=',103,'img/search.png','',1,searchall=__file__)
        addDir('الافلام الاجنبيه','https://myegy.tv/movies/english',100,'img/1.png','',1)        
	addDir('الافلام العربيه','https://myegy.tv/movies/arabic',100,'img/2.png','',1)
	addDir('ألافلام الهنديه','https://myegy.tv/movies/indian',100,'img/3.png','',1)
	addDir('الافلام الوثائقيه','https://myegy.tv/movies/documentary',100,'img/4.png','',1)
	addDir('افلام انيمي','https://myegy.tv/movies/anime',100,'img/5.png','',1)

	addDir('المسلسلات الاجنبيه','https://myegy.tv/tv/english',200,'img/6.png','',1)
        addDir('المسلسلات العربيه','https://myegy.tv/tv/arabic',200,'img/7.png','',1)
        addDir('مسلسلات انيمي','https://myegy.tv/tv/anime',200,'img/8.png','',1)
        addDir('رياضه','https://myegy.tv/tv/sports',200,'img/9.png','',1)
        
        
        
        
        
        return
        
	

        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        searchkey = getsearchtext()      
         
        url=str(searchkey )     
                 
        search_results("Search",'https://myegy.tv/latest?search=' + url,1)


def search_results(namemain,url,page):##may pastte code of getmovies here

              
                if page>1:
                    
                        #https://www.almstba.tv/video/category.php?cat=english-movies&page=2&order=DESC
                        #https://myegy.tv/movies/english?page=2
                        ##https://myegy.tv/latest?search=love&page=2
                        page_url=url+"&page="+str(page)
                  
                else:
                       
                       page_url=url
                print "url_page",page_url
                
                data=readnet(page_url)           
                
                
                try:data.split('class="Items"')[1]
                except:pass
                if data is None:
                    return
               
                
               
                blocks=data.split('class="item  movies"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href='https://myegy.tv'+re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<span class="title">(.*?)</span>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image='https://myegy.tv'+re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    image=downloadImage(image)

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,2,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>25:
                    
                   addDir("next page",url,104,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))


               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                    
                        #https://www.almstba.tv/video/category.php?cat=english-movies&page=2&order=DESC
                        #https://myegy.tv/movies/english?page=2
                        page_url=url+"?page="+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
                try:data.split('class="Items"')[1]
                except:pass
                if data is None:
                    return
               
                
               
                blocks=data.split('class="item  movies"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href='https://myegy.tv'+re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<span class="title">(.*?)</span>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image='https://myegy.tv'+re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    image=downloadImage(image)

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,2,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>25:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))












###############################################series


def getseries(name,url,page):##series
                if page>1:
                    
                        #https://www.almstba.tv/video/category.php?cat=english-movies&page=2&order=DESC
                        #https://myegy.tv/movies/english?page=2
                        page_url=url+"?page="+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
                try:data.split('class="Items"')[1]
                except:pass
                if data is None:
                    return
               
                
               
                blocks=data.split('class="item  tv"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href='https://myegy.tv'+re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<span class="title">(.*?)</span>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image='https://myegy.tv'+re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    
                    regx='''<span class="info">(.*?)</span>'''
                    
                    try:
                            episode=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            episode=''                   
                      
                               
                    title=title+"-"+episode                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,2,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>25:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))





                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,url,page):##series

                print "page",page
               
                if page>1:
                    
                        #http://www.movs4u.com/movie/page/2/
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=readnet(page_url)
               
                
                
               
                if data is None:
                    return
               
                blocks=data.split('class="imagen"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    tblock=block.split('class="episodiotitle"')[1]    
                    regx='''<a href="(.*?)">(.*?)</a>'''                    
                    match=re.findall(regx,tblock, re.M|re.I)[0]                   
                    
                    href=match[0]
                    title=os.path.basename(href[:-1])
                    name=match[1]
                    name=title+"-"+name
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    try:href=href.encode("utf-8")
                    except:href=str(href)
                    name=name.replace("مترجمه","")
                    addDir(name,href,1,'img/2.jpg','',1,maintitle=True)
                    #except:pass
               
                   
                
                
                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                


#######################################host resolving                                                    
                    

def getservers(name,url):
               
                if os.path.exists("/tmp/TSmedia/captcha_id"):
                        os.remove("/tmp/TSmedia/captcha_id")
                if os.path.exists("/tmp/TSmedia/captcha.jpg"):
                        os.remove("/tmp/TSmedia/captcha.jpg")   

                data=readnet(url)
                regx='''<a href="(.*?)"  class="button fa fa-download" rel="nohistory" target="_blank"></a>'''
                regx='''<a href="(.*?)"  class="button fa fa-download" rel="nohistory" target="_blank"></a>'''

                match=finditems(data,'<div class="size">','<div class="images">')
                quals=[]
                #print "match",match
               
                for item in match:
                    item=finditem(item,'</div>','</div>').strip()
                    print "item",item
                    quals.append((item))
                 
                quals=['340','480','720','1080','1920']
                match=re.findall(regx,data, re.M|re.I)
                i=0
                print "match",len(match)
               
                for link in match:
                        link=link.replace("/f/","/w/")
                        print "link",link
                       
                        data2=readnet(link)
                        regx='''<source src="(.*?)" type="video/mp4" />'''
	                mp4link=re.findall(regx,data2, re.M|re.I)[0]
	                try:quality=quals[i]
	                except:quality="res=p"
                        addDir(quality,mp4link,3,"img/server.png","",1)
                        i=i+1

                return
                blocks=finditems(data,'class="links visible">',"</div>")
               
                i=i+1
                for block in blocks:
                        
                       block2= finditem(block,'filecloud.io','uptobox.com')
                       regx='''href="(.*?)"'''
                       hrefs=re.findall(regx,block2, re.M|re.I)
                       link='https://myegy.tv'+hrefs[len(hrefs)-1]
                       
                      
                       addDir("link "+str(i)+" captcha",link,1,"img/server.png","",1)
                       i=i+1
                       
                return       
                
                                        
                     
                


                 
def resolve_host(url):
        resolvehost(url)    

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==2:
        print ""+url
        
        getservers(name,url)
elif mode==1:
        from myegy import getlink
        url=getlink(url)
        resolvehost(url)        
elif mode==3:
        print ""+url
        playlink(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)
elif mode==104:
	print ""+url
        search_results(url)
        
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
