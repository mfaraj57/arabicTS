import base64
import requests
import re
import json
from xbmctools import addDir,resolvehost
def getlink(url):
          s = requests.Session()
          import time
          #Exp Movie For Uptobox Server
          #r = s.get('https://myegy.tv/link/385843')
          postlink = url.replace('tv/link', 'tv/!/link')
          print "urlmyegy",url
          #sys.exit(0)
          r = s.get(url)
          html = r.content
          result    =      re.search('data:image/png;base64,(.*)"', html)
          #Collecting Post Data Values For Captcha & Target URL########################################################
          user_pt      = re.search('user":0,"@":"(.*)"},"category', html)
          user_pt      = str(user_pt.group(1))
          subheader_pt = re.search('SubHeader","state":{"@":"(.*)"}},"content', html)
          subheader_pt = str(subheader_pt.group(1))
          captcha_pt   = re.search('captcha":"(.*)"}},"footer":{"id":"footer","css_class":"Footer movies"',html)
          captcha_pt   = str(captcha_pt.group(1)[:16])
          content_pt   = re.search(captcha_pt+'","state":{"@":"(.*)"}},"footer":{"id":"footer"',html)
          content_pt   = str(content_pt.group(1))
          footermv_pt  = re.search('Footer movies","state":{"@":"(.*)"}}}',html)
          footermv_pt  = str(footermv_pt.group(1))
          #Finding & Converting & Storing BASE64 Image String To Local################################################## 
          baseimg = str('data:image/png;base64,')+ str(result.group(1))
          fh = open("/tmp/TSmedia/captcha.jpg", "wb")
          print "need captcha_id"
          fh.write(str(baseimg.split(",")[1].decode('base64')))
          fh.close()

          ######



          while os.path.exists("/tmp/TSmedia/captcha_id")==False:
               time.sleep(2)
          print "captcha id entered" 
          captcha_id=open("/tmp/TSmedia/captcha_id").read()

          ########

          headers = {
              'Host': 'myegy.tv',
              'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
              'Accept': 'text/plain, */*; q=0.01',
              'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
              'Content-Type': 'application/x-www-form-urlencoded',
              'X-Requested-With': 'XMLHttpRequest',
              'Referer': 'https://myegy.tv/',
              'Connection': 'keep-alive'}

          data = '{"jsonrpc":"2.0","method":"GetLink","state":{"header":{"user":0,"@":"'+user_pt+'"},"subheader":{"@":"'+subheader_pt+'"},"content":{"@":"'+content_pt+'"},"footer":{"@":"'+footermv_pt+'"}},"params":{"captcha":"'+captcha_pt+'","word":"'+captcha_id+'"},"id":1}'
          #Post Link Format same First Link + "!" = (...tv/!/link..) will generate json response from server
          r=s.post(postlink,data=data, headers=headers)
          htmldata = r.content
          TargetURL = json.loads(htmldata)
          stream_url=resolvehost(TargetURL['result'])
          try:addDir("link",stream_url,1,"","",1,link=True)
          except:pass
          print TargetURL['result']
