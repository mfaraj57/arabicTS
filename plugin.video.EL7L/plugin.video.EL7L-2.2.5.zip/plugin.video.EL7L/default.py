# -*- coding: utf8 -*-



try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
from xbmctools import addDir,readnet,supported,get_params,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error,getitems,downloadImage

baseurl='https://el7l.tv'
###################################
def showmenu():
        import xbmctools 
	xbmctools.addDir('••أخــر الاضافات••','https://el7l.tv/',120,'img/ADD.png','',1,searchall=__file__)
	addDir('••أفلام أجنبية أون لاين••','https://el7l.tv/online2/415/%D8%A7%D9%81%D9%84%D8%A7%D9%85_%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9/1.html',100,'img/FEATURED.png','',1)
	addDir('••أفلام مصنفة ••','url',55,'img/GEN.png',1)	
	addDir('••أفلام عربي أون لاين••','https://el7l.tv/online2/12/_%D8%A7%D9%81%D9%84%D8%A7%D9%85_%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9/1.html',100,'img/AR.png','',1)
	addDir('••بــــــوليود••','https://el7l.tv/online2/470/%D8%A7%D9%81%D9%84%D8%A7%D9%85_%D9%87%D9%86%D8%AF%D9%8A%D8%A9/1.html',100,'img/BLLYOOD.png','',1)
	addDir('••أفلام أسيوية••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+%D8%A7%D8%B3%D9%8A%D9%88%D9%8A%D8%A9',100,'img/Action.png','',1)
	addDir('YEARS','url',500,'img/Other.png','',1)
	addDir('••أفلام أنمي أون لاين••','https://el7l.tv/online2/14/_%D8%A7%D9%81%D9%84%D8%A7%D9%85_%D9%83%D8%A7%D8%B1%D8%AA%D9%88%D9%86/1.html',100,'img/AAAA.png','',1)

       
        
        
        
def GENRES(url):
      	addDir('••أفلام أكشــــن••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+%D8%A7%D9%83%D8%B4%D9%86',100,'img/Action.png','',1)
	addDir('••أفلام رعـــب••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+%D8%B1%D8%B9%D8%A8',100,'img/Horror.png','',1)
	addDir('••أفلام رومــــانسية••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+%D8%B1%D9%88%D9%85%D8%A7%D9%86%D8%B3%D9%8A%D8%A9+%D9%88%D8%AD%D8%A8',100,'img/Romantic.png','',1)
	addDir('••كـــومديـــا••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+%D9%83%D9%88%D9%85%D9%8A%D8%AF%D9%8A%D8%A9',100,'img/Comedy.png','',1)
	addDir('••درامــــــــــــا••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+%D8%AF%D8%B1%D8%A7%D9%85%D8%A7',100,'img/drama.png','',1)
	addDir('••الخيال العلمي••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+%D8%AE%D9%8A%D8%A7%D9%84+%D8%B9%D9%84%D9%85%D9%8A',100,'img/SienceFiction.png','',1)
	addDir('••أفلام للكبــار ••','https://el7l.tv/online2/469/%D8%A7%D9%81%D9%84%D8%A7%D9%85_%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9_%D9%84%D9%84%D9%83%D8%A8%D8%A7%D8%B1_%D9%81%D9%82%D8%B7/1.html',100,'img/XXX.png','',1)
	addDir('••أفلام رياضية ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+%D8%B1%D9%8A%D8%A7%D8%B6%D9%8A%D8%A9',100,'img/ADD.png','',1)

	addDir('••المصـــــارعه••','https://el7l.tv/online2/246/%D9%85%D8%B5%D8%A7%D8%B1%D8%B9%D8%A9_%D8%AD%D8%B1%D8%A9/1.html',100,'img/WWE.png','',1)  

        setView('movies', 'MAIN')
        

        




def YEARS(url):
        addDir('••افلام 2018 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2018',100,'img/Other.png','',1)

        addDir('••أفلام 2017 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2017',100,'img/Other.png','',1)

        addDir('••أفلام 2016 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2016',100,'img/Other.png','',1)
	addDir('••أفلام 2015 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2015',100,'img/Other.png','',1)
	addDir('••أفلام 2014 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2014',100,'img/Other.png','',1)
        addDir('••أفلام 2013 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2013',100,'img/Other.png','',1)
        addDir('••أفلام 2012 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2012',100,'img/Other.png','',1)
        addDir('••أفلام 2011 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2011',100,'img/Other.png','',1)
        addDir('••أفلام 2010 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2010',100,'img/Other.png','',1)
        addDir('••أفلام 2009 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2009',100,'img/Other.png','',1)
        addDir('••أفلام 2008 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2008',100,'img/Other.png','',1)
        addDir('••أفلام 2007 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2007',100,'img/Other.png','',1)
        addDir('••أفلام 2006 ••','https://el7l.tv/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85+2006',100,'img/Other.png','',1)
      
                
      
			
        
def getmovies(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                    
                        #https://www.movs4u.com/movie/page/2/
                        url_page=urlmain+"/page/"+str(page)
                        url_page=urlmain+'"/"/page/'+str(page)+".html"
                 
                  
                else:
                
                       url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                if data is None:
                    return
               
                blocks=data.split('class="file_index">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="https://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-https://star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    regx='''href="(.*?)"'''                    
                    href=re.findall(regx,block, re.M|re.I)[0]                  
                    regx='''src="(.*?)"'''                    
                    image=re.findall(regx,block, re.M|re.I)[0]
                    downloadImage(image)                    
                    regx='<h3>(.*?)</h3>'                    
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    try:name=name.encode("utf-8")
                    except:name=str(name)       
                    name=name.replace("فيلم","")             
                    try:href=href.encode("utf-8")
                    except:href=str(href)
                    print "name",name,href,image
                    addDir(name,href,1,image,'',1)
                    #except:pass
               
                   
                
                if len(blocks)>10:
                    
                   addDir("next page",urlmain,100,'https://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))









def getmovies2(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                        url_page=urlmain+'?p='+str(page)

                 
                  
                else:
                
                       url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                if data is None:
                    return
               
                blocks=data.split('class="file_index">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="https://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-https://star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    regx='''href="(.*?)"'''                    
                    href=re.findall(regx,block, re.M|re.I)[0]                  
                    regx='''src="(.*?)"'''                    
                    image=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='<h3>(.*?)</h3>'                    
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    try:name=name.encode("utf-8")
                    except:name=str(name)                    
                    name=name.replace("فيلم","") 
                    
                    try:href=href.encode("utf-8")
                    except:href=str(href)
                    print "name",name,href,image
                    addDir(name,href,1,image,'',1)
                    #except:pass
               
                   
                
                if len(blocks)>10:
                    
                   addDir("next page",urlmain,120,'https://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                
#######################################host resolving                                                    
                    
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    addDir(server,href,2,'img/server.png')

def getservers(url):
                url=url.replace("/online/","/play/")
                data=readnet(url)
                print data
                regx='''<li><a href="(.+?)" rel="#iframe"'''
                match = re.findall(regx,data, re.M|re.I)
                getmatch(match)
                regx1='''<iframe.+?src="(.+?)".+?></iframe>'''
                match1 = re.findall(regx1,data, re.M|re.I)
                getmatch(match1)
               


def resolve_host(url):
        resolvehost(url)    



params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
        
elif mode==1:
        print ""+url        
        getservers(url)
        
elif mode==2:
        print ""+url
        resolve_host(url)   
             
elif mode==3:
        print ""+url
        playlink(url)
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==120:
        print ""+url
        getmovies2(name,url,page)
        
elif mode==500:
	print ""+url        
        YEARS(url)
	
elif mode==103:
	print ""+url
        search(url)    
elif mode==55:
        print ""+url
        GENRES(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
