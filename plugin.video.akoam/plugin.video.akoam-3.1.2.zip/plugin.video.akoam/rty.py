#######################################################################
#
#    Scripts for Dreambox-Clone-Sim2-Updates
#    Support: www.digital-eliteboard.de
#    Made by : S.O.A
#
#######################################################################



from Screens.Screen import Screen
from Screens.Console import Console
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from os import listdir
import urllib2 
from enigma import eTimer



def Plugins(**kwargs):
	return [PluginDescriptor(name=_("SOA Clone Updater 3.1"), description=_("SOA Clone Updater 3.1"), where = [PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU ], fnc=main, icon = "plugin.png")]



def main(session, **kwargs):
	session.open(Scripts)



class Scripts(Screen):
	skin = """
	<screen position="center,center" size="660,475" title="SOA Clone Updater 3.1" >
		<widget name="list" position="10,10" size="860,475" scrollbarMode="showOnDemand" />
	</screen>"""

	def __init__(self, session, args=None):
		Screen.__init__(self, session)
		self.session = session
		try:
			list = listdir("/usr/lib/enigma2/python/Plugins/Extensions/update-plugin/scripts/")
			list = [x[:-3] for x in list if x.endswith('.sh')]
			list.sort()
		except:
			list = []
		self["list"] = MenuList(list)
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
                self.onLayoutFinish.append(self.settitle)
                self.softupdate()
                self.timer = eTimer()
                self.timer.callback.append(self.softupdate)
                self.timer.start(50, True)

	def softupdate(self):
            try:
                req = urllib2.Request('http://clones-only.com/updater/version')
                response = urllib2.urlopen(req)
                data = response.read()
                response.close()
                new_version=data.split("=")[1]
                curr_version=open("/usr/lib/enigma2/python/Plugins/Extensions/update-plugin/version","r").read().split("=")[1]
                link='http://clones-only.com/patcher/enigma2-plugin-extensions-update-plugin_'+new_version+'_all.ipk'
                if float(new_version)>float(curr_version):
                   print "update is available"
                   self.downloadupdate(link)
                else:
                   print "no download available"
                   pass 
            except:
                  print "unable to download update data"
	def downloadupdate(self,link):
            cmdlist=['opkg install -force-overwrite '+link,'killall -9 enigma2']
            desc='Updating plugin,please wait,your Box restart alone\nEnigma will restart after finishing updates'
            self.session.open(Console, desc, cmdlist=cmdlist) 
                            

            def run(self):
                    script = self["list"].getCurrent()
                    if script is not None:
                            MyCommand = "/usr/lib/enigma2/python/Plugins/Extensions/update-plugin/scripts/" + script + ".sh"
                            self.session.open(Console, script.replace("_", " "), cmdlist=[(MyCommand)])
