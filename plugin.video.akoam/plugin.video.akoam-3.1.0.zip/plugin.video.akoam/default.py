# -*- coding: utf8 -*-



import sys
import urllib,urllib2,re,os
################''
addon_path=os.path.dirname(__file__)
sys.path.append(addon_path+"\urlresolver")
sys.path.append(addon_path+"\pelisresolver") 
baseurl='http://akoam.com'
from xbmctools import addDir,readnet,supported,get_params,playlink,removeunicode,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,finditems,finditem,resolvehost,finddata,trace_error


##########################################parsing tools
def read_url3(url):#filmon
              return readnet(url)
              data=None
              m=True
              if True:
                  import cfscrape

                  scraper = cfscrape.create_scraper()  # returns a CloudflareScraper instance
                  # Or: scraper = cfscrape.CloudflareScraper()  # CloudflareScraper inherits from requests.Session
                  data=scraper.get(url).content  # => "<!DOCTYPE html><html><head>..."
                                          
                         
              else:
                        addDir("Download error,try again","","",'')
                        return

              return data

def showmenu():
        ##main
	

                  
                addDir('SEARCH',baseurl+'/search/',103,'img/SEARCH.png',1,searchall=__file__)

               	addDir('أفـــلام اجنبية',baseurl+'/cat/156/%D8%A7%D9%84%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',100,'img/mov.png','',1)
                addDir('الافلام-الاسيوية',baseurl+'/cat/171/%D8%A7%D9%84%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%84%D8%A7%D8%B3%D9%8A%D9%88%D9%8A%D8%A9',100,'img/islam.png','',1)  
                addDir('الافلام-فائقة-الدقة-Blu-ray',baseurl+'/cat/183/%D8%A7%D9%84%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%81%D8%A7%D8%A6%D9%82%D8%A9-%D8%A7%D9%84%D8%AF%D9%82%D8%A9-Blu-ray',100,'img/BROMO.png','',1)  

               	#addDir('سلسلة أفــلام أجنبية',baseurl+'/cat/164/%D8%A7%D8%B1%D8%B4%D9%8A%D9%81-%D9%88-%D8%B3%D9%84%D8%A7%D8%B3%D9%84-%D8%A7%D9%84%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',205,'img/MSE.png',1)
               	addDir('مسلسلات أجنبية',baseurl+'/cat/166/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',200,'img/E.png','',1) 
                  
                addDir('أفــلام عربية',baseurl+'/cat/155/الأفلام_العربية',100,'img/AR.png','',1)              

                addDir('مسلسلات عربية',baseurl+'/cat/80/',200,'img/SER.png','',1) 
                addDir('مسرحيــات',baseurl+'/cat/149/%D9%85%D8%B3%D8%B1%D8%AD%D9%8A%D8%A7%D8%AA',100,'img/THEATER.png','',1) 
                addDir('أفــلام هندية',baseurl+'/cat/168/%D8%A7%D9%84%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%84%D9%87%D9%86%D8%AF%D9%8A%D8%A9',200,'img/IN.png','',1)  
                                 
                addDir('أفــلام الانيمي',baseurl+'/cat/83/%D8%A7%D9%84%D8%A7%D9%86%D9%85%D9%8A',100,'img/ANIM.png','',1) 
                addDir('أهــداف كرة قدم',baseurl+'/cat/87/%D8%B1%D9%8A%D8%A7%D8%B6%D8%A9',100,'img/f.png','',1) 
                             
                #addDir('المصــارعه',baseurl+'/cat/88/%D8%A7%D9%84%D9%85%D8%B5%D8%A7%D8%B1%D8%B9%D8%A9-%D8%A7%D9%84%D8%AD%D8%B1%D8%A9',100,'img/WWE.png','',1)              
                addDir('أفــلام ثقافية',baseurl+'/cat/94/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%88%D8%AB%D8%A7%D8%A6%D9%82%D9%8A%D8%A9',100,'img/DOC.png','',1) 
                addDir('برامج تلفزيونية',baseurl+'/cat/81/%D8%A7%D9%84%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%A7%D9%84%D8%AA%D9%84%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D8%A9',200,'img/pro.png','',1) 
                addDir('فيديو كليب',baseurl+'/cat/89/%D9%81%D9%8A%D8%AF%D9%8A%D9%88-%D9%83%D9%84%D9%8A%D8%A8',100,'img/clib.png','',1) 
                

        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        searchkey = getsearchtext()      
         
        url= url+searchkey      
          
        search_results("Search",url,0)


def search_results(namemain,url,page):##may pastte code of getmovies here


                if page>1:
                    
                        #http://akoam.com/cat/156/الأفلام-الاجنبية/page/2
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=read_url3(page_url)           
                
                
                
                if data is None:
                    return
               
                
               
                blocks=data.split('class="tags_box"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<h1>(.*?)</h1>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''http://images.akoam.com/files/thumbs/(.*?)'''                    
                    try:
                            image='http://images.akoam.com/files/thumbs/'+re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    print "image",image

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    #title=removeunicode(title)
                    if "مسلسل" in title:
                        mode=201
                        
                    else:
                        mode=4
                    try:
                      addDir(title,href,mode,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
               

               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                    
                        #http://akoam.com/cat/156/الأفلام-الاجنبية/page/2
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=read_url3(page_url)           
                
                
                
                if data is None:
                    return
               
                
               
                blocks=data.split('class="subject_box shape"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<h3>(.*?)</h3>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    #title=removeunicode(title)
                    if "مسلسل" in title:
                        mode=201
                        
                    else:
                        mode=4
                    
                    try:
                      addDir(title,href,mode,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>35:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))












###############################################series


def getseries(name,url,page):##series
                if page>1:
                    
                        #http://akoam.com/cat/156/الأفلام-الاجنبية/page/2
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=read_url3(page_url)           
                
                
                
                if data is None:
                    return
               
                
               
                blocks=data.split('class="subject_box shape"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<h3>(.*?)</h3>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    #title=removeunicode(title)
                    try:
                      addDir(title,href,201,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>35:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))






                    
def getseasons(name,url,page):##series

                 
                data=read_url3(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return
                regx='''a href="(.*?)" target="_blank"><span style="color:#FFD700">(.*?)</span></a>'''
                regx='''<a href="(.*?)" target="_blank"><span style=".*?">(.*?)</span></a><br />'''
                seasons=re.findall(regx,data, re.M|re.I)
                
                addDir(name,url,202,'','',1)
                for href,title in seasons:
                    
                    #title=title.encode("utf-8","ignore")
                    addDir(title,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,url,page):##series

                print "page",page
               
                if page>1:
                    
                        #http://www.movs4u.com/movie/page/2/
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=read_url3(page_url)
               
                
                
               
                if data is None:
                    return
               
              
                regx='''<h2 class="sub_epsiode_title">(.*?)</h2>'''          
                match=re.findall(regx,data, re.M|re.I)
                i=0
                for title in match:
                    i=i+1
                    addDir(title,url,1,'img/2.jpg','',i,maintitle=True)
                return



#######################################host resolving                                                    
def getservers_movies(name,url,page):
                data=readnet(url)
                
               
                regx='''<a rel='nofollow' class='download_btn' target='_blank' href='(.*?)'>'''
                regx='''<a class='download_btn' target='_blank' href='(.*?)'></a>'''
                href=re.findall(regx,data, re.M|re.I)[0]
                addDir("direct_link",href,2,"img/server.png",'',1)
                resolve_host2(href)
                return
                regx='''<a class='sub_btn show' target='_blank' href='(.*?)'>'''
                
                match=re.findall(regx,data, re.M|re.I)
                images=finditems(data," url(",");")
               
                i=1
                print "images",images
                
                for href in match:
                    image=finditem(images[i][0]," url(",");").replace("(","").replace(")","")             
                    addDir("link",href,3,image,'',1)
                    i=i+1             
                    
                
                return


def getservers_series(name,url,page):
                data=readnet(url)
                blocks=data.split('class="title_box_episode"')
                data=blocks[page]
                print "data",data.encode("utf-8")
               
                regx='''<a rel='nofollow' class='download_btn' target='_blank' href='(.*?)'>'''
                href=re.findall(regx,data, re.M|re.I)[0]
                resolve_host2(href)
                return
                addDir("direct_link",href,2,"img/server.png",'',1)
                regx='''<a class='sub_btn show' target='_blank' href='(.*?)'>'''
                
                match=re.findall(regx,data, re.M|re.I)
                images=finditems(data," url(",");")
               
                i=1
                print "images",images
                for href in match:
                    image=finditem(images[i][0]," url(",");").replace("(","").replace(")","")             
                    addDir("link",href,3,image,'',1)
                    i=i+1             
                    
                
                return
                for href in match:

                        
                   
                    

                    
                    
                    title=getDomain(href)
                   
                    if True:
                            try:addDir(title,href,3,"img/server.png",'',1)
                            except:pass

                 
def resolve_host2(url):
        
        from yastools import getlinks
        stream_url=getlinks(url,False)
        playlink(stream_url)
        return
        addDir("link",stream_url,9,"","",1,link=True)
def resolve_host3(url):
        
        from yastools import getlinks
        server_url=getlinks(url,True)
        if not server_url.startswith("http:"):
            server_url="http:"+server_url


        stream_url=resolvehost(server_url)
        if stream_url==[]:
            stream_url=[0]
        playlink(stream_url)
        #addDir("link",stream_url,9,"","",1,link=True)
  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers_series(name,url,page)
elif mode==4:
        print ""+url
        
        getservers_movies(name,url,page)
        
elif mode==2:
        print ""+url
        resolve_host2(url)        
elif mode==3:
        print ""+url
        resolve_host3(url)  
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
