# -*- coding: utf8 -*-

###parsing technique coding by yassinov
import requests

import urllib , json,re
#from bs4 import BeautifulSoup #"import for enigma2"
def getlinks(url,server=False):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0'}
        
        
        s = requests.Session()

        #The test was done with download url same method for stream url
        #you need just to parse them and all stream urls they start with http://gocoo.co/xxxx
        encoded_movie_url=url         
        print "Protected Host = "+encoded_movie_url
        r = s.get(encoded_movie_url, headers=headers)
        htmldata = r.content
        for c in r.cookies:
            encoded_data=(c.value)
            
        jsondata=urllib.unquote(encoded_data).decode('utf8') 
        #print(jsondata)
        jsondata2 = json.loads(jsondata)
        Pre_Stream_URL = jsondata2['route']
        print "Pre Stream Url= "+Pre_Stream_URL.encode("utf-8")
        if server==True:
            regx='''<iframe.*?src="(.*?)".*?></iframe>'''
            data = s.get(Pre_Stream_URL, headers=headers).content
            link=re.findall(regx,data, re.M|re.I)[0]
            return link
            



        headers2 = {
        'Host': 'akoam.com',
        'Connection': 'keep-alive',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Origin': 'http://akoam.com',
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36 OPR/48.0.2685.39',
        'Referer': Pre_Stream_URL,
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'fr-FR,fr;q=0.8,en-US;q=0.6,en;q=0.4'}
        r=s.post(Pre_Stream_URL,data='', headers=headers2)
        htmldata = r.content
        jsondata3 = json.loads(htmldata)
        Final_Stream_URL = jsondata3['direct_link']
        print "Final Stream Url = "+Final_Stream_URL
        return Final_Stream_URL
