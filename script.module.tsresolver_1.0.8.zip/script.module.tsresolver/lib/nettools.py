# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/script.module.urlresolver/lib/urlresolver/plugins/lib/tools.py
# Compiled at: 2015-11-12 10:32:16
import urllib
import time
import traceback
import urllib2
import threading
try:
    import ssl
except:
    pass

import re
import htmlentitydefs
import cookielib
import unicodedata
try:
    import json
except:
    import simplejson as json

try:
    try:
        from cStringIO import StringIO
    except:
        from StringIO import StringIO

    import gzip
except:
    pass

from binascii import hexlify
import string
import codecs
from os import makedirs as mkdirs
from urlparse import urlparse
###########
gMainFunctionsQueueTab = [None, None]
gIPTVPlayerTempCookieDir = None
HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:21.0) Gecko/20100101 Firefox/21.0','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
   'Content-type': 'application/x-www-form-urlencoded'
   }
USER_AGENT = 'Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10'
def byteify(input):
    if isinstance(input, dict):
        return dict([(byteify(key), byteify(value)) for key, value in input.iteritems()])
    elif isinstance(input, list):
        return [byteify(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input
def htmlentity_transform(entity):
    """Transforms an HTML entity to a character."""
    # Known non-numeric HTML entity
    try:
        if entity in compat_html_entities.name2codepoint:
            return compat_chr(compat_html_entities.name2codepoint[entity])
    except Exception: pass

    mobj = re.match(r'#(x?[0-9A-Fa-f]+)', entity)
    if mobj is not None:
        numstr = mobj.group(1)
        if numstr.startswith(u'x'):
            base = 16
            numstr = u'0%s' % numstr
        else:
            base = 10
        try:
            ret = compat_chr(int(numstr, base))
            return ret
        except Exception:
            printExc()
    # Unknown entity in name, return its literal representation
    return (u'&%s;' % entity)
def getDomain(url, onlyDomain=True):
        parsed_uri = urlparse( url )
        if onlyDomain:
            domain = '{uri.netloc}'.format(uri=parsed_uri)
        else:
            domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
        return domain
def getDebugMode():
    DBG=''
    try:
        #from Components.config import config
        DBG = 2#config.plugins.iptvplayer.debugprint.value
    except Exception:
        file = open(resolveFilename(SCOPE_CONFIG, "settings"))
        for line in file:
            if line.startswith('config.plugins.iptvplayer.debugprint=' ) :
                DBG=line.split("=")[1].strip()
                break
    return DBG

def clean_html(html):
    """Clean an HTML snippet into a readable string"""
    if type(html) == type(u''):
        strType = 'unicode'
    elif type(html) == type(''):
        strType = 'utf-8'
        html = html.decode("utf-8", 'ignore')
        
    # Newline vs <br />
    html = html.replace('\n', ' ')
    html = re.sub(r'\s*<\s*br\s*/?\s*>\s*', '\n', html)
    html = re.sub(r'<\s*/\s*p\s*>\s*<\s*p[^>]*>', '\n', html)
    # Strip html tags
    html = re.sub('<.*?>', '', html)
    # Replace html entities
    html = unescapeHTML(html)
    
    if strType == 'utf-8': 
        html = html.encode("utf-8")
    
    return html.strip()


class Delegate(object):
    def __init__(self, proxyFunctionQueue, fnc):
        self.function = fnc
        self.proxyQueue = proxyFunctionQueue
        self.event = threading.Event()
        self.returnValues = None
        
    def __call__(self, *args, **kwargs):
        if self.proxyQueue:
            if self.proxyQueue.mainThreadName != threading.currentThread().getName():
                self.event.clear()
            
                item = CPQItemDelegate(self.function, args, kwargs, self.finished)
                self.proxyQueue.addItemQueue(item)
                
                self.event.wait()
                returnValues = self.returnValues
                self.returnValues = None
                return returnValues
            else:
                raise BaseException("Delegate cannot be used in MainThread!")

    def finished(self, *args):
        self.returnValues = args
        self.event.set()
        
    #def __del__(self):
    #    printDBG("Delegate.__del__ ---------------------------------")



class DelegateToMainThread(Delegate):
    def __init__(self, fnc, mainThreadIdx=0):
        global gMainFunctionsQueueTab
        Delegate.__init__(self, gMainFunctionsQueueTab[mainThreadIdx], fnc)
        
    #def __del__(self):
    #    printDBG("DelegateToMainThread.__del__ ---------------------------------")

def IsHttpsCertValidationEnabled():
    return False
class iptv_execute(object):
    '''
    Calling os.system is not recommended, it may fail due to lack of memory,
    please use iptv_execute instead, this should be used as follow:
    ret = iptv_execute()("cmd")
    ret['sts'], ret['code'], ret['data']
    
    iptv_execute must be used outside from MainThread context, please see 
    iptv_system class from iptvtools module which is dedicated to be
    used inside MainThread context
    '''
    WAIT_RET = "WaitForFinish"
    def __init__(self, mainThreadIdx=0):
        self.retVal = None
        self.event = threading.Event()
        self.mainThreadIdx = mainThreadIdx

    def __call__(self, cmd):
        printDBG("iptv_execute.__call__: Here we must not be in main thread context: [%s]" % threading.current_thread());
        self.event.clear()
        tmpRet = DelegateToMainThread(self._system, self.mainThreadIdx)(cmd)
        if tmpRet and tmpRet[0] == iptv_execute.WAIT_RET: 
            self.event.wait()
            ret = self.retVal
            self.retVal = None
            return ret
        else: 
            return {'sts':False}

    def _system(self, session, cmd):
        printDBG("iptv_execute._system: Here we must be in main thread context: [%s]" % threading.current_thread());
        self.iptv_system = iptv_system(cmd, self._callBack)
        return iptv_execute.WAIT_RET

    def _callBack(self, code, outData):
        printDBG("iptv_execute._callBack: Here we must be in main thread context: [%s]" % threading.current_thread());
        self.iptv_system = None
        self.retVal = {'sts':True, 'code':code, 'data':outData}
        self.event.set()

    #def __del__(self):
    #    printDBG("iptv_execute.__del__ ---------------------------------")
def GetDukPath():
    return "d::\\tmp"#config.plugins.iptvplayer.dukpath.value
def GetTmpDir(file = ''):
    path ="d:\\tmp"# config.plugins.iptvplayer.NaszaTMP.value
    path = path.replace('//', '/')
    try:mkdirs(path)
    except:pass
    return path + '/' + file
    
def CreateTmpFile(filename, data=''):
    sts = False
    filePath = GetTmpDir(filename)
    try:
        with open(filePath, 'w') as f:
            f.write(data)
            sts = True
    except Exception:
        printExc()
    return sts, filePath

def iptv_js_execute(jscode):
    sts, tmpPath = CreateTmpFile('.iptv_js.js', jscode)
    if sts:
        cmd =  GetDukPath() + ' ' + tmpPath + ' 2> /dev/null'
        printDBG("iptv_js_execute cmd[%s]" % cmd)
        ret = iptv_execute()( cmd )
        
        # leave last script for debug purpose
        if getDebugMode() == '':
            rm(tmpPath)
    else:
        ret = {'sts':False, 'code':-12, 'data':''}
    printDBG('iptv_js_execute cmd ret[%s]' % ret)
    return ret
def decorateUrl(url, metaParams={}):
    retUrl = strwithmeta( url )
    retUrl.meta.update(metaParams)
    urlLower = url.lower()
    if 'iptv_proto' not in retUrl.meta:
        if urlLower.startswith('merge://'):
            retUrl.meta['iptv_proto'] = 'merge'
        elif urlLower.split('?')[0].endswith('.m3u8'):
            retUrl.meta['iptv_proto'] = 'm3u8'
        elif urlLower.split('?')[0].endswith('.f4m'):
            retUrl.meta['iptv_proto'] = 'f4m'
        elif urlLower.startswith('rtmp'):
            retUrl.meta['iptv_proto'] = 'rtmp'
        elif urlLower.startswith('https'):
            retUrl.meta['iptv_proto'] = 'https'
        elif urlLower.startswith('http'):
            retUrl.meta['iptv_proto'] = 'http'
        elif urlLower.startswith('file'):
            retUrl.meta['iptv_proto'] = 'file'
        elif urlLower.startswith('rtsp'):
            retUrl.meta['iptv_proto'] = 'rtsp'
        elif urlLower.startswith('mms'):
            retUrl.meta['iptv_proto'] = 'mms'
        elif urlLower.startswith('mmsh'):
            retUrl.meta['iptv_proto'] = 'mmsh'
        elif 'protocol=hls' in url.lower():
            retUrl.meta['iptv_proto'] = 'm3u8'
    return retUrl

def _findLinks(data, serverName='', linkMarker='[\'"]?file[\'"]?[ ]*:[ ]*[\'"](http[^"^\']+)[\'"][,}]', m1='sources', m2=']'):
    linksTab = []
    srcData = CParsingHelper.getDataBeetwenMarkers(data, m1, m2, False)[1].split('},')
    for item in srcData:
        item += '},'
        link = CParsingHelper.getSearchGroups(item, linkMarker)[0].replace('\\/', '/')
        label = CParsingHelper.getSearchGroups(item, '[\'"]?label[\'"]?[ ]*:[ ]*[\'"]([^"^\']+)[\'"]')[0]
        if '' != link:
            linksTab.append({'name': '%s %s' % (serverName, label),'url': link})

    if 0 == len(linksTab):
        link = CParsingHelper.getSearchGroups(data, linkMarker)[0].replace('\\/', '/')
        print 'link', link
        if '' != link:
            linksTab.append({'name': serverName,'url': link})
    return linksTab


def _findLinks2(data, baseUrl):
    videoUrl = CParsingHelper.getSearchGroups(data, 'type="video/divx"src="(http[^"]+?)"')[0]
    if '' != videoUrl:
        return strwithmeta(videoUrl, {'Referer': baseUrl})
    videoUrl = CParsingHelper.getSearchGroups(data, '[\'"]?file[\'"]?[ ]*[:,][ ]*[\'"](http[^"^\']+)[\'"][,}\\)]')[0]
    if '' != videoUrl:
        return strwithmeta(videoUrl, {'Referer': baseUrl})
    return False


def _parserUNIVERSAL_A(baseUrl, embedUrl, _findLinks, _preProcessing=None):
    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0','Referer': baseUrl}
    if 'embed' not in baseUrl:
        video_id = CParsingHelper.getSearchGroups(baseUrl + '/', '/([A-Za-z0-9]{12})[/.]')[0]
        url = embedUrl.format(video_id)
    else:
        url = baseUrl
    post_data = None
    sts, data = getPage(url, {'header': HTTP_HEADER}, post_data)
    if not sts:
        return False
    else:
        if _preProcessing != None:
            data = _preProcessing(data)
        sts, tmpData = CParsingHelper.getDataBeetwenMarkers(data, '>eval(', '</script>', False)
        if sts:
            data = tmpData
            tmpData = None
            data = unpackJSPlayerParams(data, VIDUPME_decryptPlayerParams)
        return _findLinks(data)


def _parserUNIVERSAL_B(url):
    printDBG('_parserUNIVERSAL_B url[%s]' % url)
    videoUrl = False
    try:
        sts, data = getPage(url)
        filekey = re.search('flashvars.filekey="([^"]+?)";', data)
        if None == filekey:
            filekey = re.search('flashvars.filekey=([^;]+?);', data)
            filekey = re.search('var {0}="([^"]+?)";'.format(filekey.group(1)), data)
        filekey = filekey.group(1)
        file = re.search('flashvars.file="([^"]+?)";', data).group(1)
        domain = re.search('flashvars.domain="(http[^"]+?)"', data).group(1)
        url = domain + '/api/player.api.php?cid2=undefined&cid3=undefined&cid=undefined&user=undefined&pass=undefined&numOfErrors=0'
        url = url + '&key=' + urllib.quote_plus(filekey) + '&file=' + urllib.quote_plus(file)
        sts, data = getPage(url)
        videoUrl = re.search('url=([^&]+?)&', data).group(1)
        errUrl = domain + '/api/player.api.php?errorCode=404&cid=1&file=%s&cid2=undefined&cid3=undefined&key=%s&numOfErrors=1&user=undefined&errorUrl=%s&pass=undefined' % (urllib.quote_plus(file), urllib.quote_plus(filekey), urllib.quote_plus(videoUrl))
        sts, data = getPage(errUrl)
        errUrl = re.search('url=([^&]+?)&', data).group(1)
        if '' != errUrl:
            url = errUrl
        if '' != url:
            videoUrl = url
    except:
        printExc()

    return videoUrl


def parseJWPLAYER_A(baseUrl, serverName='', customLinksFinder=None):
    HTTP_HEADER = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:21.0) Gecko/20100101 Firefox/21.0','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
       'Content-type': 'application/x-www-form-urlencoded'
       }
    USER_AGENT = 'Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10'
    linkList = []
    tries = 2
    while tries > 0:
        tries -= 1
        HTTP_HEADER = dict(HTTP_HEADER)
        HTTP_HEADER['Referer'] = baseUrl
        sts, data = getPage(baseUrl, {'header': HTTP_HEADER})
        if sts:
            HTTP_HEADER = dict(HTTP_HEADER)
            HTTP_HEADER['Referer'] = baseUrl
            url = CParsingHelper.getSearchGroups(data, 'iframe[ ]+src="(http://embed.[^"]+?)"')[0]
            if serverName in url:
                sts, data = getPage(url, {'header': HTTP_HEADER}, host=serverName)
            else:
                url = baseUrl
        if sts and '' != data:
            if True:
                sts, data2 = CParsingHelper.getDataBeetwenMarkers(data, 'method="POST"', '</Form>', False, False)
                if sts:
                    post_data = dict(re.findall('<input[^>]*name="([^"]*)"[^>]*value="([^"]*)"[^>]*>', data2))
                    print 'post_data,url', post_data, url,
                    if tries == 0:
                        if True:
                            sleep_time = CParsingHelper.getSearchGroups(data2, '>([0-9]+?)</span> seconds<')[0]
                            if '' != sleep_time:
                                time.sleep(int(sleep_time))
                    HTTP_HEADER['Referer'] = url
                    sts, data = getPage(url, {'header': HTTP_HEADER}, post_data, host=serverName)
                if None != customLinksFinder:
                    linkList = customLinksFinder(data)
                if 0 == len(linkList):
                    linkList = _findLinks(data, serverName)
        if len(linkList) > 0:
            break

    print 'linklist', linkList
    return linkList


def getPage(url, addParams={}, post_data=None, host=''):
    """ wraps getURLRequestData """
    if True:
        addParams['url'] = url
        if 'return_data' not in addParams:
            addParams['return_data'] = True
        response = getURLRequestData(addParams, post_data, host=host)
        status = True
    else:
        printExc()
        response = e
        status = False
    return (
     status, response)


def getURLRequestData(params={}, post_data=None, host=None):

    def urlOpen(req, customOpeners):
        if len(customOpeners) > 0:
            opener = urllib2.build_opener(*customOpeners)
            response = opener.open(req)
        else:
            response = urllib2.urlopen(req)
        return response

    HEADER = None
    cj = cookielib.MozillaCookieJar()
    response = None
    req = None
    out_data = None
    opener = None
    try:
        host = params['host']
    except:
        host = host

    if 'header' in params:
        headers = params['header']
    elif None != HEADER:
        headers = HEADER
    else:
        headers = {'User-Agent': host}
    if 'User-Agent' not in headers:
        headers['User-Agent'] = host
    customOpeners = []
    if 'use_cookie' not in params and 'cookiefile' in params and ('load_cookie' in params or 'save_cookie' in params):
        params['use_cookie'] = True
    if params.get('use_cookie', False):
        if params.get('load_cookie', False):
            try:
                cj.load(params['cookiefile'], ignore_discard=True)
            except:
                pass

        try:
            for cookieKey in params.get('cookie_items', {}).keys():
                printDBG('cookie_item[%s=%s]' % (cookieKey, params['cookie_items'][cookieKey]))
                cookieItem = cookielib.Cookie(version=0, name=cookieKey, value=params['cookie_items'][cookieKey], port=None, port_specified=False, domain='', domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={'HttpOnly': None}, rfc2109=False)
                cj.set_cookie(cookieItem)

        except:
            printExc()

        customOpeners.append(urllib2.HTTPCookieProcessor(cj))
    try:
        customOpeners.append(urllib2.HTTPSHandler(context=ssl._create_unverified_context()))
    except:
        pass

    http_proxy = ''
    if 'http_proxy' in params:
        http_proxy = params['http_proxy']
    if '' != http_proxy:
        customOpeners.append(urllib2.ProxyHandler({'http': http_proxy}))
        customOpeners.append(urllib2.ProxyHandler({'https': http_proxy}))
    pageUrl = params['url']
    proxy_gateway = params.get('proxy_gateway', '')
    if proxy_gateway != '':
        pageUrl = proxy_gateway.format(urllib.quote_plus(pageUrl, ''))
    if None != post_data:
        if params.get('raw_post_data', False):
            dataPost = post_data
        elif params.get('multipart_post_data', False):
            customOpeners.append(MultipartPostHandler())
            dataPost = post_data
        else:
            dataPost = urllib.urlencode(post_data)
        req = urllib2.Request(pageUrl, dataPost, headers)
    else:
        req = urllib2.Request(pageUrl, None, headers)
    if not params.get('return_data', False):
        out_data = urlOpen(req, customOpeners)
    else:
        gzip_encoding = False
        try:
            response = urlOpen(req, customOpeners)
            if response.info().get('Content-Encoding') == 'gzip':
                gzip_encoding = True
            data = response.read()
            response.close()
        except urllib2.HTTPError as e:
            if e.code == 404:
                printDBG('!!!!!!!! 404: getURLRequestData - page not found handled')
                if e.fp.info().get('Content-Encoding', '') == 'gzip':
                    gzip_encoding = True
                data = e.fp.read()
            elif e.code == 503:
                if params.get('use_cookie', False):
                    new_cookie = e.fp.info().get('Set-Cookie', '')
                    printDBG('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> new_cookie[%s]' % new_cookie)
                    print 'cookiefile',params['cookiefile']
                    cj.save(params['cookiefile'], ignore_discard=True)
                raise e
            else:
                if e.code in (300, 302, 303, 307) and params.get('use_cookie', False) and params.get('save_cookie', False):
                    new_cookie = e.fp.info().get('Set-Cookie', '')
                    printDBG('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> new_cookie[%s]' % new_cookie)
                    cj.save(params['cookiefile'], ignore_discard=True)
                raise e

        try:
            if gzip_encoding:
                printDBG('Content-Encoding == gzip')
                buf = StringIO(data)
                f = gzip.GzipFile(fileobj=buf)
                out_data = f.read()
            else:
                out_data = data
        except:
            out_data = data

    if params.get('use_cookie', False) and params.get('save_cookie', False):
        cj.save(params['cookiefile'], ignore_discard=True)
    return out_data


class strwithmeta(str):

    def __new__(cls, value, meta={}):
        obj = str.__new__(cls, value)
        obj.meta = {}
        if isinstance(value, strwithmeta):
            obj.meta = value.meta
        else:
            obj.meta = {}
        obj.meta.update(meta)
        return obj


def printDBG(txt=None):
    if txt:
        print txt


def printExc(msg=''):
    printDBG('===============================================')
    printDBG('                   EXCEPTION                   ')
    printDBG('===============================================')
    msg = msg + ': \n%s' % traceback.format_exc()
    printDBG(msg)
    printDBG('===============================================')


def GetCookieDir(file=''):
    cookieDir = '/tmp/'
    tmpDir = 'H:/TSmediaTools' + cookieDir + 'cookies/'
    if os.path.exists('H:/TSmediaTools' + cookieDir + 'cookies/'):
        tmpDir = 'H:/TSmediaTools' + cookieDir + 'cookies/'
    else:
        tmpDir = cookieDir + 'cookies/'
    try:
        if os.path.isdir(tmpDir) or mkdirs(tmpDir):
            cookieDir = tmpDir
    except:
        printExc()

    return cookieDir + file


def MYOBFUSCATECOM_OIO(data, _0lllOI='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=', enc=''):
    i = 0
    while i < len(data):
        h1 = _0lllOI.find(data[i])
        h2 = _0lllOI.find(data[i + 1])
        h3 = _0lllOI.find(data[i + 2])
        h4 = _0lllOI.find(data[i + 3])
        i += 4
        bits = h1 << 18 | h2 << 12 | h3 << 6 | h4
        o1 = bits >> 16 & 255
        o2 = bits >> 8 & 255
        o3 = bits & 255
        if h3 == 64:
            enc += chr(o1)
        elif h4 == 64:
            enc += chr(o1) + chr(o2)
        else:
            enc += chr(o1) + chr(o2) + chr(o3)

    return enc


def MYOBFUSCATECOM_0ll(string, baseRet=''):
    ret = baseRet
    i = len(string) - 1
    while i >= 0:
        ret += string[i]
        i -= 1

    return ret


def int2base(x, base):
    digs = string.digits + string.lowercase
    if x < 0:
        sign = -1
    else:
        if x == 0:
            return '0'
        sign = 1
    x *= sign
    digits = []
    while x:
        digits.append(digs[x % base])
        x /= base

    if sign < 0:
        digits.append('-')
    digits.reverse()
    return ''.join(digits)


def JS_toString(x, base):
    return int2base(x, base)


def JS_DateValueOf():
    return time.time() * 1000


def JS_FromCharCode(*args):
    return ''.join(map(unichr, args))


def unicode_escape(s):
    decoder = codecs.getdecoder('unicode_escape')
    return re.sub('\\\\u[0-9a-fA-F]{4,}', lambda m: decoder(m.group(0))[0], s).encode('utf-8')


def drdX_fx(e):
    t = {}
    n = 0
    r = 0
    i = []
    s = ''
    o = JS_FromCharCode
    u = [[65, 91], [97, 123], [48, 58], [43, 44], [47, 48]]
    for z in range(len(u)):
        n = u[z][0]
        while n < u[z][1]:
            i.append(o(n))
            n += 1

    n = 0
    while n < 64:
        t[i[n]] = n
        n += 1

    n = 0
    while n < len(e):
        a = 0
        f = 0
        l = 0
        c = 0
        h = e[n:n + 72]
        while l < len(h):
            f = t[h[l]]
            a = (a << 6) + f
            c += 6
            while c >= 8:
                c -= 8
                s += o((a >> c) % 256)

            l += 1

        n += 72

    return s


def decorateUrl(url, metaParams={}):
    retUrl = strwithmeta(url)
    retUrl.meta.update(metaParams)
    urlLower = url.lower()
    if 'iptv_proto' not in retUrl.meta:
        if urlLower.split('?')[0].endswith('.m3u8'):
            retUrl.meta['iptv_proto'] = 'm3u8'
        elif urlLower.split('?')[0].endswith('.f4m'):
            retUrl.meta['iptv_proto'] = 'f4m'
        elif urlLower.startswith('rtmp'):
            retUrl.meta['iptv_proto'] = 'rtmp'
        elif urlLower.startswith('https'):
            retUrl.meta['iptv_proto'] = 'https'
        elif urlLower.startswith('http'):
            retUrl.meta['iptv_proto'] = 'http'
        elif urlLower.startswith('file'):
            retUrl.meta['iptv_proto'] = 'file'
        elif urlLower.startswith('rtsp'):
            retUrl.meta['iptv_proto'] = 'rtsp'
        elif urlLower.startswith('mms'):
            retUrl.meta['iptv_proto'] = 'mms'
        elif urlLower.startswith('mmsh'):
            retUrl.meta['iptv_proto'] = 'mmsh'
        elif 'protocol=hls' in url.lower():
            retUrl.meta['iptv_proto'] = 'm3u8'
    return retUrl


def getParamsTouple(code, type=1, r1=False, r2=False):
    mark1 = '}('
    mark2 = '))'
    if r1:
        idx1 = code.rfind(mark1)
    else:
        idx1 = code.find(mark1)
    if -1 == idx1:
        return ''
    idx1 += len(mark1)
    if r2:
        idx2 = code.rfind(mark2, idx1)
    else:
        idx2 = code.find(mark2, idx1)
    if -1 == idx2:
        return ''
    idx2 += type
    return code[idx1:idx2]


def unpackJSPlayerParams(code, decryptionFun, type=1, r1=False, r2=False):
    printDBG('unpackJSPlayerParams')
    code = getParamsTouple(code, type, r1, r2)
    return unpackJS(code, decryptionFun)


def VIDUPME_decryptPlayerParams(p=None, a=None, c=None, k=None, e=None, d=None):
    while c > 0:
        c -= 1
        if k[c]:
            p = re.sub('\\b' + int2base(c, a) + '\\b', k[c], p)

    return p


def unpackJSPlayerParams(code, decryptionFun, type=1, r1=False, r2=False):
    printDBG('unpackJSPlayerParams')
    code = getParamsTouple(code, type, r1, r2)
    return unpackJS(code, decryptionFun)


def unpackJS(data, decryptionFun):
    paramsCode = 'paramsTouple = (' + data + ')'
    try:
        paramsAlgoObj = compile(paramsCode, '', 'exec')
    except:
        printExc('unpackJS compile algo code EXCEPTION')
        return ''

    vGlobals = {'__builtins__': None,'string': string,'decodeURIComponent': urllib.unquote,'unescape': urllib.unquote}
    vLocals = {'paramsTouple': None}
    try:
        exec paramsAlgoObj in vGlobals, vLocals
    except:
        printExc('unpackJS exec code EXCEPTION')
        return ''

    try:
        return decryptionFun(*vLocals['paramsTouple'])
    except:
        printExc('decryptPlayerParams EXCEPTION')

    return ''
try:
    compat_str = unicode # Python 2
except NameError:
    compat_str = str

try:
    compat_chr = unichr # Python 2
except NameError:
    compat_chr = chr

def compat_ord(c):
    if type(c) is int: return c
    else: return ord(c)
def unescapeHTML(s):
    if s is None:
        return None
    assert type(s) == compat_str

    return re.sub(r'&([^;]+);', lambda m: htmlentity_transform(m.group(1)), s)

def VIDUPME_decryptPlayerParams(p=None, a=None, c=None, k=None, e=None, d=None):
    while c > 0:
        c -= 1
        if k[c]:
            p = re.sub('\\b' + int2base(c, a) + '\\b', k[c], p)

    return p


class CParsingHelper:
    print 'mfaraj1'

    @staticmethod
    def getSearchGroups(data, pattern, grupsNum=1, ignoreCase=False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab

    @staticmethod
    def getDataBeetwenReMarkers(data, pattern1, pattern2, withMarkers=True):
        print 'data', pattarn1
        sys.exit(0)
        match1 = pattern1.search(data)
        if None == match1 or -1 == match1.start(0):
            return (False, '')
        else:
            match2 = pattern2.search(data[match1.end(0):])
            if None == match2 or -1 == match2.start(0):
                return (False, '')
            if withMarkers:
                return (True, data[match1.start(0):match1.end(0) + match2.end(0)])
            return (
             True, data[match1.end(0):match1.end(0) + match2.start(0)])
            return

    @staticmethod
    def getDataBeetwenMarkers(data, marker1, marker2, withMarkers=True, caseSensitive=True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return (
         True, data[idx1:idx2])

    @staticmethod
    def getAllItemsBeetwenMarkers(data, marker1, marker2, withMarkers=True, caseSensitive=True):
        itemsTab = []
        if caseSensitive:
            sData = data
        else:
            sData = data.lower()
            marker1 = marker1.lower()
            marker2 = marker2.lower()
        idx1 = 0
        while True:
            idx1 = sData.find(marker1, idx1)
            if -1 == idx1:
                return itemsTab
            idx2 = sData.find(marker2, idx1 + len(marker1))
            if -1 == idx2:
                return itemsTab
            tmpIdx2 = idx2 + len(marker2)
            if withMarkers:
                idx2 = tmpIdx2
            else:
                idx1 = idx1 + len(marker1)
            itemsTab.append(data[idx1:idx2])
            idx1 = tmpIdx2

        return itemsTab

    @staticmethod
    def rgetDataBeetwenMarkers(data, marker1, marker2, withMarkers=True):
        idx1 = data.rfind(marker1)
        if -1 == idx1:
            return (False, '')
        idx2 = data.rfind(marker2, idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return (True, data[idx1:idx2])

    @staticmethod
    def removeDoubles(data, pattern):
        while -1 < data.find(pattern + pattern) and '' != pattern:
            data = data.replace(pattern + pattern, pattern)

        return data

    @staticmethod
    def replaceHtmlTags(s, replacement=''):
        tag = False
        quote = False
        out = ''
        for c in s:
            if c == '<' and not quote:
                tag = True
            elif c == '>' and not quote:
                tag = False
                out += replacement
            elif (c == '"' or c == "'") and tag:
                quote = not quote
            elif not tag:
                out = out + c

        return re.sub('&\\w+;', ' ', out)

    @staticmethod
    def writeToFile(file, data, mode='w'):
        file_path = file
        text_file = open(file_path, mode)
        text_file.write(data)
        text_file.close()

    @staticmethod
    def getNormalizeStr(txt, idx=None):
        POLISH_CHARACTERS = {u'\u0105': u'a',u'\u0107': u'c',u'\u0119': u'\u0119',u'\u0142': u'l',u'\u0144': u'n',u'\xf3': u'o',u'\u015b': u's',u'\u017c': u'z',u'\u017a': u'z',u'\u0104': u'A',
           u'\u0106': u'C',u'\u0118': u'E',u'\u0141': u'L',u'\u0143': u'N',u'\xd3': u'O',u'\u015a': u'S',u'\u017b': u'Z',u'\u0179': u'Z',u'\xe1': u'a',
           u'\xe9': u'e',u'\xed': u'i',u'\xf1': u'n',u'\xf3': u'o',u'\xfa': u'u',u'\xfc': u'u',u'\xc1': u'A',
           u'\xc9': u'E',u'\xcd': u'I',u'\xd1': u'N',u'\xd3': u'O',u'\xda': u'U',u'\xdc': u'U'}
        txt = txt.decode('utf-8')
        if None != idx:
            txt = txt[idx]
        nrmtxt = unicodedata.normalize('NFC', txt)
        ret_str = []
        for item in nrmtxt:
            if ord(item) > 128:
                item = POLISH_CHARACTERS.get(item)
                if item:
                    ret_str.append(item)
            else:
                ret_str.append(item)

        return ''.join(ret_str).encode('utf-8')

    @staticmethod
    def isalpha(txt, idx=None):
        return CParsingHelper.getNormalizeStr(txt, idx).isalpha()

def GetCookieDir(file = ''):
    global gIPTVPlayerTempCookieDir
    if gIPTVPlayerTempCookieDir == None: cookieDir = '/media/hdd/cookies/'
    else: cookieDir = gIPTVPlayerTempCookieDir
    try:
        if not os.path.isdir(cookieDir):
            mkdirs(cookieDir)
    except Exception: printExc()
    return cookieDir + file
    
class captchaParser:
    def __init__(self):
        pass

    def textCaptcha(self, data):
        strTab = []
        valTab = []
        match = re.compile("padding-(.+?):(.+?)px;padding-top:.+?px;'>(.+?)<").findall(data)
        if len(match) > 0:
            for i in range(len(match)):
                value = match[i]
                strTab.append(value[2])
                strTab.append(int(value[1]))
                valTab.append(strTab)
                strTab = []
                if match[i][0] == 'left':
                    valTab.sort(key=lambda x: x[1], reverse=False)
                else:
                    valTab.sort(key=lambda x: x[1], reverse=True)
        return valTab

    def reCaptcha(self, data):
        pass

class common:
    HOST = 'Mozilla/5.0 (Windows NT 6.1; rv:17.0) Gecko/20100101 Firefox/17.0'
    HEADER = None
    ph = CParsingHelper

    @staticmethod
    def getParamsFromUrlWithMeta(url, baseHeaderOutParams=None):
        HANDLED_HTTP_HEADER_PARAMS = ['Host', 'User-Agent', 'Referer', 'Cookie', 'Accept', 'X-Forwarded-For', 'Range']
        outParams = {}
        tmpParams = {}
        postData = None
        if isinstance(url, strwithmeta):
            if None != baseHeaderOutParams:
                tmpParams['header'] = baseHeaderOutParams
            else:
                tmpParams['header'] = {}
            for key in url.meta:
                if key in HANDLED_HTTP_HEADER_PARAMS:
                    tmpParams['header'][key] = url.meta[key]

            if 0 < len(tmpParams['header']):
                outParams = tmpParams
            if 'iptv_proxy_gateway' in url.meta:
                outParams['proxy_gateway'] = url.meta['iptv_proxy_gateway']
        return (
         outParams, postData)

    def __init__(self, proxyURL='', useProxy=False, useMozillaCookieJar=False):
        self.proxyURL = proxyURL
        self.useProxy = useProxy
        self.geolocation = {}
        self.useMozillaCookieJar = useMozillaCookieJar
    def getCookieHeader(self, cookiefile, allowedNames=[]):
        ret = ''
        try:
            if not self.useMozillaCookieJar:
              cj = cookielib.LWPCookieJar()
            #else:
                #cj = cookielib.MozillaCookieJar()
            cj.load(cookiefile, ignore_discard = True)
            for cookie in cj:
                if 0 < len(allowedNames) and cookie.name not in allowedNames: continue
                ret += '%s=%s; ' % (cookie.name, urllib.unquote(cookie.value))
        except Exception:
            printExc()
        return ret
    def getCountryCode(self, lower=True):
        if 'countryCode' not in self.geolocation:
            sts, data = self.getPage('http://ip-api.com/json')
            if sts:
                try:
                    self.geolocation['countryCode'] = byteify(json.loads(data))['countryCode']
                except:
                    printExc()

        return self.geolocation.get('countryCode', '').lower()

    def getCookieItem(self, cookiefile, item):
        ret = ''
        if not self.useMozillaCookieJar:
            cj = cookielib.LWPCookieJar()
        else:
            cj = cookielib.MozillaCookieJar()
        cj.load(cookiefile, ignore_discard=True)
        for cookie in cj:
            if cookie.name == item:
                ret = cookie.value

        return ret

    def html_entity_decode_char(self, m):
        ent = m.group(1)
        if ent.startswith('x'):
            return unichr(int(ent[1:], 16))
        try:
            return unichr(int(ent))
        except:
            if ent in htmlentitydefs.name2codepoint:
                return unichr(htmlentitydefs.name2codepoint[ent])
            else:
                return ent

    def html_entity_decode(self, string):
        string = string.decode('UTF-8')
        s = re.compile('&#?(\\w+?);').sub(self.html_entity_decode_char, string)
        return s.encode('UTF-8')

    def getPage(self, url, addParams={}, post_data=None):
        """ wraps getURLRequestData """
        try:
            addParams['url'] = url
            if 'return_data' not in addParams:
                addParams['return_data'] = True
            response = self.getURLRequestData(addParams, post_data)
            status = True
        except urllib2.HTTPError as e:
            printExc()
            response = e
            status = False
        except:
            printExc()
            response = None
            status = False

        return (status, response)

    def saveWebFile(self, file_path, url, addParams={}, post_data=None):
        bRet = False
        downDataSize = 0
        dictRet = {}
        try:
            if 'header' not in addParams and 'host' not in addParams:
                host = 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.18) Gecko/20110621 Mandriva Linux/1.9.2.18-0.1mdv2010.2 (2010.2) Firefox/3.6.18'
                header = {'User-Agent': host,'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
                addParams['header'] = header
            addParams['return_data'] = False
            sts, downHandler = self.getPage(url, addParams, post_data)
            if addParams.get('ignore_content_length', False):
                meta = downHandler.info()
                contentLength = int(meta.getheaders('Content-Length')[0])
            else:
                contentLength = None
            OK = True
            if 'maintype' in addParams and addParams['maintype'] != downHandler.headers.maintype:
                downHandler.close()
                printDBG('common.getFile wrong maintype! requested[%r], retrieved[%r]' % (addParams['maintype'], downHandler.headers.maintype))
                OK = False
            if 'subtypes' in addParams:
                OK = False
                for item in addParams['subtypes']:
                    if item == downHandler.headers.subtype:
                        OK = True
                        break

            if OK:
                blockSize = addParams.get('block_size', 8192)
                fileHandler = file(file_path, 'wb')
                while True:
                    buffer = downHandler.read(blockSize)
                    if not buffer:
                        break
                    downDataSize += len(buffer)
                    fileHandler.write(buffer)

                fileHandler.close()
                downHandler.close()
                if None != contentLength and contentLength == downDataSize:
                    bRet = True
        except:
            printExc('common.getFile download file exception')

        dictRet.update({'sts': True,'fsize': downDataSize})
        return dictRet

    def getURLRequestData(self, params={}, post_data=None):

        def urlOpen(req, customOpeners):
            if len(customOpeners) > 0:
                opener = urllib2.build_opener(*customOpeners)
                response = opener.open(req)
            else:
                response = urllib2.urlopen(req)
            return response

        if not self.useMozillaCookieJar:
            cj = cookielib.LWPCookieJar()
        else:
            cj = cookielib.MozillaCookieJar()
        response = None
        req = None
        out_data = None
        opener = None
        if 'host' in params:
            host = params['host']
        else:
            host = self.HOST
        if 'header' in params:
            headers = params['header']
        elif None != self.HEADER:
            headers = self.HEADER
        else:
            headers = {'User-Agent': host}
        if 'User-Agent' not in headers:
            headers['User-Agent'] = host
        printDBG('pCommon - getURLRequestData() -> params: ' + str(params))
        printDBG('pCommon - getURLRequestData() -> headers: ' + str(headers))
        customOpeners = []
        if 'use_cookie' not in params and 'cookiefile' in params and ('load_cookie' in params or 'save_cookie' in params):
            params['use_cookie'] = True
        if params.get('use_cookie', False):
            if params.get('load_cookie', False):
                try:
                    cj.load(params['cookiefile'], ignore_discard=True)
                except:
                    printExc()

            try:
                for cookieKey in params.get('cookie_items', {}).keys():
                    printDBG('cookie_item[%s=%s]' % (cookieKey, params['cookie_items'][cookieKey]))
                    cookieItem = cookielib.Cookie(version=0, name=cookieKey, value=params['cookie_items'][cookieKey], port=None, port_specified=False, domain='', domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={'HttpOnly': None}, rfc2109=False)
                    cj.set_cookie(cookieItem)

            except:
                printExc()

            customOpeners.append(urllib2.HTTPCookieProcessor(cj))
        if not IsHttpsCertValidationEnabled():
            try:
                customOpeners.append(urllib2.HTTPSHandler(context=ssl._create_unverified_context()))
            except:
                pass

        if self.useProxy:
            http_proxy = self.proxyURL
        else:
            http_proxy = ''
        if 'http_proxy' in params:
            http_proxy = params['http_proxy']
        if '' != http_proxy:
            printDBG('getURLRequestData USE PROXY')
            customOpeners.append(urllib2.ProxyHandler({'http': http_proxy}))
            customOpeners.append(urllib2.ProxyHandler({'https': http_proxy}))
        pageUrl = params['url']
        proxy_gateway = params.get('proxy_gateway', '')
        if proxy_gateway != '':
            pageUrl = proxy_gateway.format(urllib.quote_plus(pageUrl, ''))
        printDBG('pageUrl: [%s]' % pageUrl)
        if None != post_data:
            printDBG('pCommon - getURLRequestData() -> post data: ' + str(post_data))
            if params.get('raw_post_data', False):
                dataPost = post_data
            elif params.get('multipart_post_data', False):
                customOpeners.append(MultipartPostHandler())
                dataPost = post_data
            else:
                dataPost = urllib.urlencode(post_data)
            req = urllib2.Request(pageUrl, dataPost, headers)
        else:
            req = urllib2.Request(pageUrl, None, headers)
        if not params.get('return_data', False):
            out_data = urlOpen(req, customOpeners)
        else:
            gzip_encoding = False
            try:
                response = urlOpen(req, customOpeners)
                if response.info().get('Content-Encoding') == 'gzip':
                    gzip_encoding = True
                data = response.read()
                response.close()
            except urllib2.HTTPError as e:
                if e.code == 404:
                    printDBG('!!!!!!!! 404: getURLRequestData - page not found handled')
                    if e.fp.info().get('Content-Encoding', '') == 'gzip':
                        gzip_encoding = True
                    data = e.fp.read()
                elif e.code == 503:
                    if params.get('use_cookie', False):
                        new_cookie = e.fp.info().get('Set-Cookie', '')
                        printDBG('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> new_cookie[%s]' % new_cookie)
                        cj.save(params['cookiefile'], ignore_discard=True)
                    raise e
                else:
                    if e.code in (300, 302, 303, 307) and params.get('use_cookie', False) and params.get('save_cookie', False):
                        new_cookie = e.fp.info().get('Set-Cookie', '')
                        printDBG('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> new_cookie[%s]' % new_cookie)
                        cj.save(params['cookiefile'], ignore_discard=True)
                    raise e

            try:
                if gzip_encoding:
                    printDBG('Content-Encoding == gzip')
                    buf = StringIO(data)
                    f = gzip.GzipFile(fileobj=buf)
                    out_data = f.read()
                else:
                    out_data = data
            except:
                out_data = data

        if params.get('use_cookie', False) and params.get('save_cookie', False):
            cj.save(params['cookiefile'], ignore_discard=True)
        return out_data
    def isValidUrl(self, url):
        return url.startswith('http://') or url.startswith('https://')
    
    def makeABCList(self):
        strTab = []
        strTab.append('0 - 9')
        for i in range(65, 91):
            strTab.append(str(unichr(i)))

        return strTab

    def isNumeric(self, s):
        try:
            float(s)
            return True
        except ValueError:
            return False

    def setLinkTable(self, url, host):
        strTab = []
        strTab.append(url)
        strTab.append(host)
        return strTab
