def getData(url, data = {}, host = '', Referer = ''):
    import requests
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.get(url, headers=headers)
    htmldata = r.content
    return htmldata
