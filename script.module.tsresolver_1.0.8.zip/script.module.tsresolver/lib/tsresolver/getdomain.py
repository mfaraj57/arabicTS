
def GetDomain(url):
        import re
        tmp = re.compile('//(.+?)/').findall(url)
        domain = 'Unknown'
        if len(tmp) > 0 :
            domain = tmp[0].replace('www.', '')
        return domain
print GetDomain("http://www.openload.io/4567.html")
