#
import re

def get_video_url(url):
       
        import xbmctools
       
        data= xbmctools.readnet(url)
        regx='''"streamUrl":"(.*?)",'''
        stream_url=re.findall(regx,data, re.M|re.I)[0].split('"')[0]
        return stream_url
       





