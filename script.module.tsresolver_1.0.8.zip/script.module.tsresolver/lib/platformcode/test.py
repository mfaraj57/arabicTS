import os
print os.path.exists('F:\wTSmedia/scripts/script.module.pelisresolver/lib/pelisresolver/servers/openload.py')
