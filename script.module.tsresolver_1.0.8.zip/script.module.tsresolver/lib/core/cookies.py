# Netscape HTTP Cookie File
# http://curl.haxx.se/rfc/cookie_spec.html
# This is a generated file!  Do not edit.

.openload.co	TRUE	/	FALSE	1571977613	__cfduid	dd9f37dbb90d3d0d864644697b086a1e41540441613
openload.co	FALSE	/	FALSE		_olbknd	w4
