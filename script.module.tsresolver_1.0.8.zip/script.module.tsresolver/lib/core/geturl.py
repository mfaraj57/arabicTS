
host='blog.vesload.com'
Referer='https://cera.video/watch-drone-2017-bluray.html'
url='https://vesload.com/reading/22.php'
#url='https://cera.video/play.php?dest=393256'
url='https://blog.vesload.com/?p=17&id=V3MxV1ZQNHZ2RExJOWNqaFM5aTRXd3pKRWVVdlhHb24wSGtKMXdzcS9JaUJFNkVjWnlMR2taUVNYRitLcEdQUFdSOGlrVTdyS01Rd0c0cG1zYW5OZDBsY1NJUGJrVy93R0Y5dmhoWHFHVDlFQ1ZFMEViSkM4aHdHaW5UYkpBand3TVUwcDg2blRmOVpnM3Fsenc4V1BRPT0='
def getData():
    import requests
    #import httptools
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.get(url,data={'id':'393256'}, headers=headers)
    htmldata = r.content
    return htmldata
print getData()
