#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from yttools import *


def infolist():
  list1=[]
 
  list1.append(('الموسم الاول','PLRCzrSHS5u_Gi-FjZbtQ8f003hIqm6-uE',1006,"img/1.png"))#playlist
  list1.append(('الموسم الثاني','PLRCzrSHS5u_EfRA0RbsyWGicIu80vjZDC',1006,"img/2.png"))#playlist
  list1.append(('الموسم الثالث','PLRCzrSHS5u_GzV4ZIiQQQ-jPTKuBNAvB',1006,"img/3.png"))#playlist
  list1.append(('الموسم الرابع','PLRCzrSHS5u_EaxT99Oz6v6g1mPABBva3v',1006,"img/4.png"))#playlist
  ######
  list1.append(('قناة السليط الاخباري','UC-4KnPMmZzwAzW7SbVATUZQ',1001,"img/4.png"))##user channel id
  
  
  #list1.append(('MTV lebanon','mtvlebanon',1005,"img/1.png"))##user channel name
  #list1.append(('الموسم الاول','PLRCzrSHS5u_Gi-FjZbtQ8f003hIqm6-uE',1006,"img/2.png"))#playlist
  #list1.append(('test-video','4jhJaKNsqb0',1007,"img/2.png"))##video
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))

