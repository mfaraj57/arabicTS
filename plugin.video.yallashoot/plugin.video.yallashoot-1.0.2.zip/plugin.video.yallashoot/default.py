# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error,downloadImage
################''
baseurl='http://www.beinsports.com'

##########################################parsing tools


def showmenu():
        
    
        addDir('اهداف','http://www.yalla-shoot.com/live/video.php?type=1',100,'img/1.png','',1)
        addDir('ملخصات','http://www.yalla-shoot.com/live/video.php?type=2',100,'img/2.png','',1)
        addDir('الاشواط','http://www.yalla-shoot.com/live/video.php?type=4',100,'img/3.png','',1)
        addDir('المباريات كامله','http://www.yalla-shoot.com/live/video.php?type=3',100,'img/4.png','',1)
       
                            
def getmovies(namemain,urlmain,page):##movies
                print "page",page
              
                if page>1:
                
                     #http://www.beinsports.com/en/premier-league/videos/2
                     url_page=urlmain+'&page='+str(page)
                        
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
                
                data=readnet(url_page)
              
              
                if data is None:
                    return
              
                blocks=data.split('"col-md-3 col-sm-6 goals-item">')
                i=0
                
                print "blocks",len(blocks)
              
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    block=block.replace(';','')
                    regx='''href="(.*?)"'''
                    href=re.findall(regx,block, re.M|re.I)[0]
                    href='http://www.yalla-shoot.com/live/'+href
                    
                    print "href",href
                    regx='title="(.*?)</h4>'  
                    title=re.findall(regx,block, re.M|re.I)[0]
                             
                    regx='''src="(.*?)"'''
                    
                    try:image=re.findall(regx,block, re.M|re.I)[0]
                    except:image=''
                    image=downloadImage(image)
                    
                    try:title=title.encode("utf-8")
                    except:title=str(title)
                    print "imge",title,image
                    try:addDir(title,href,1,image,'',1)
                    except:pass
                addDir("next page",urlmain,100,'img/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                     




               
            
def get_youtube_link(value):
    """
    Examples:
    - http://youtu.be/SA2iWivDJiE
    - http://www.youtube.com/watch?v=_oPAwA_Udwc&feature=feedu
    - http://www.youtube.com/embed/SA2iWivDJiE
    - http://www.youtube.com/v/SA2iWivDJiE?version=3&amp;hl=en_US
    -'plugin://plugin.video.youtube/?action=play_video&amp;videoid=FBBLhRgrw0o'
    """
    from urlparse import urlparse
    vid=None
    if value is None:
        return None
    else:
        value = value.strip()
        if value.startswith('plugin://'):
           
            try:
                vid = value.split('=')[value.count('=')]
                
            except:
                return None
        else:
            query = urlparse(value)
            if query.hostname == 'youtu.be':
                vid= query.path[1:]
            elif query.hostname in ('www.youtube.com', 'youtube.com'):
                if query.path == '/watch':
                    p = parse_qs(query.query)
                    vid= p['v'][0]
                if query.path[:7] == '/embed/':
                    vid= query.path.split('/')[2]
                if query.path[:3] == '/v/':
                    vid=query.path.split('/')[2]
            
        addDir('play','plugin://plugin.video.youtube/?action=play_video&videoid=%s' % vid,0,'','',1,link=True)    
        #return 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % vid

        
def getservers2(name,url):
         data=readnet(url)
         regx='''source: "(.*?)"'''
         href=finddata(data,'source:',",")
         if not href:
            getservers(name,url)
            return
         print "href",href
         return

def getservers(name,url):##cinema and tv featured

                
                data=readnet(url)
                regx='''<link rel='shortlink' href='(.*?)' />'''
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                try:
                        href=re.findall(regx,data, re.M|re.I)[0]
                        
                except:
                   pass
                   
                        
                
                print "id",href
                
                if href.startswith('http://yalla4.online/goals'):
                        
                   data=readnet(href)
                   regx='''<iframe.*?src="(.*?)".*?></iframe>'''
               
                   href=re.findall(regx,data, re.M|re.I)[0]
                href=href.strip()
                if not href.startswith("http"):
                        href="http:"+href
                if 'youtube' in href:
                        
                      get_youtube_link(href)  
                else:
                        resolvehost(href)
                            
                
                return
               
                 
def resolve_host(url):
        resolve_host(url)    
        
  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        getservers2(name,url)       
elif mode==3:
        print ""+url
        playlink(url)
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
