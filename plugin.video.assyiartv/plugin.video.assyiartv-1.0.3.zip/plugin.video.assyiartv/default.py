# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py


import os, sys
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse


import StringIO

__settings__ = xbmcaddon.Addon(id='plugin.video.assyiartv')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://www.assyriatv.org/'
host='www.assyriatv.org'
####functions
def read_url(url):
            try:  
              req = urllib2.Request(url)
              req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
              req.add_header('Host', host)
              req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
              req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
              response = urllib2.urlopen(req)
              link=response.read()
              return link
            except:
                  addDir("Download failed:"+url,"","",'')
                  return None
def readnet(url):
            from xbmctools import requestsurl
            return requestsurl(url)
            
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content.encode("utf-8")
            return html
      
def decodeHtml(text):
    text = text.replace('&auml;', 'ae').replace('&Auml;', 'Ae').replace('&ouml;', 'oe').replace('&ouml;', 'Oe').replace('&uuml;', 'ue')
    text = text.replace('&Uuml;', 'Ue').replace('&szlig;', 'ss').replace('&amp;', '&').replace('&quot;', '"').replace('&gt;', "'")
    text = text.replace('&#228;', 'ae').replace('&#246;', 'oe').replace('&#252;', 'ue').replace('&#223;', 'ss').replace('&#8230;', '...')
    text = text.replace('&#8222;', ',').replace('&#8220;', "'").replace('&#8216;', "'").replace('&#8217;', "'").replace('&#8211;', '-')
    text = text.replace('&#8230;', '...').replace('&#8217;', "'").replace('&#128513;', ':-)').replace('&#8221;', '"')
    text = text.replace('&#038;', '&').replace('&#039;', "'")
    text = text.replace('\\u00c4', 'Ae').replace('\\u00e4;', 'ae').replace('\\u00d6', 'Oe').replace('\\u00f6', 'oe')
    text = text.replace('\\u00dc', 'Ue').replace('\\u00fc', 'ue').replace('\\u00df', 'ss')
    text = text.replace('&#196;', 'Ae').replace('&#228;', 'ae').replace('&#214;', 'Oe').replace('&#246;', 'oe').replace('&#220;', 'Ue').replace('&#252;', 'ue')
    text = text.replace('<br />\n', '')
    return text 
def removeunicode(data):
             
             
            
              try:
                    type(data)
                    data=data.decode('unicode_escape').encode('ascii','replace').replace("?","").strip()
        
              except:
                    pass
              
              return data
              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

                genreliste=[]
		
		genreliste.append(("Search",'http://www.assyriatv.org/?s=',103))
                genreliste.append(("All videos",'http://www.assyriatv.org/',100))
                genreliste.append(("Sport",'http://www.assyriatv.org/category/sport/',1000))
                genreliste.append(("kultur",'http://www.assyriatv.org/category/kultur/',1000))
                genreliste.append(("politik",'http://www.assyriatv.org/category/politik/',1000))
                
                for title, url, mode in genreliste:
                    addDir(title, url, mode, '', 1)
		return
		genreliste.append(("Action movies",'http://www.hakchouf.com/action_Movies.php',100))
		genreliste.append(("Horror movies",'http://www.hakchouf.com/Horror_Movies.php',100))
		genreliste.append(("Drama movies",'http://www.hakchouf.com/drama_Movies.php',100))
		genreliste.append(("Mystery movies",'http://www.hakchouf.com/Movies_Mystery.php',100))
		genreliste.append(("Romantic movies",'http://www.hakchouf.com/Romantic_Movies.php',100))
		genreliste.append(("Superhero movies",'http://www.hakchouf.com/Superhero_Movies.php',100))
		genreliste.append(("Comedy movies", 'http://www.hakchouf.com/Comedy_Movies.php',100))
		genreliste.append(("adventure movies",'http://www.hakchouf.com/adventure_movies.php',100))
		genreliste.append(("Arabic movies", 'http://www.hakchouf.com/films_ar.php',100))
		genreliste.append(("India Movies", 'http://hakchouf.com/films_hd.php',100))
		genreliste.append(("Anime Movies", 'http://hakchouf.com/anime_films.php',100))
		genreliste.append(("New Series",'http://www.hakchouf.com/new_seri.php',100))
		genreliste.append(("Recent Add", 'http://hakchouf.com/index.php',100))
		
		
		

                    
def getgenre(name='movies'):##cinema and tv featured

                data=read_url(baseurl)
                if data is None:
                    return
		match = re.findall('menu_genre">(.*?)</ul>', data, re.S|re.I)
		if match:
			Cats = re.findall('href=".*?">(.*?)<',match[0], re.S)
			if Cats:
				for Cat in Cats:
					#self.genreliste.append((Cat, True))
                                        if name=='movies':
                                           addDir(Cat,baseurl+"/category/genre="+Cat,100,'')
                                        else:
                                           url=baseurl+"/tv-shows/genre=%s" % Cat   
                                           addDir(Cat,url,200,'')

def getA_Z(name='movies'):
		abc = ["0-9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        if name=='movies':
			  addDir(letter,baseurl+"/category/letter="+letter.lower(),100,'',1)
			else:
                          url = baseurl+"/tv-shows/letter=%s" % letter.lower()    
                          addDir(letter,url,200,'',1)    
###################################movies		 
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   print "mfarajx3",search_entered
                   
        else:
             print "search error"
            
        
        
        
        url= url+search_entered
        
          
        getvideos_search("Search",url,1)
def getvideos_search(name,urlmain,page):##ok
                if page>1:
                  #http://www.assyriatv.org/page/2/
                  url_page=urlmain+'page/'+str(page)+"/"
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url(url_page)
                print "data",data
                
                if data is None:
                    return

                regx='''</div>.*?<a href='(.*?)'>\s\s.*?<img src='(.*?)' class='.*?' onmouseover=".*?"'''
                regx='''<a href="(.*?)"><img class="boximg" width="180" height="270" src="(.*?)" alt="(.*?)" title="(.*?)" /></a>'''
                regx='''<h2 class="post-title typography-title"><a href="(.*?)">(.*?)</a></h2>'''
                regx='''<h2 class="post-title typography-title"><a href="(.*?)">(.*?)</a></h2>'''
                        

		
		
		
		videos = re.findall(regx,data, re.M|re.I)
                #print "Movies",Movies
		print "videos",videos
		
		
                i=0
		if len(videos)>0:
			for href,title in videos:
                               
				
				
				
                                addDir(title,href,1,'')
                        addDir("next page",urlmain,100,'',str(page+1))

                                
                        
                else:
                      
                        addDir("Error:script error",urlmain,1,'',1)

                return                                        
def getvideos(name,urlmain,page):##ok
                print "page",page
               
                if page>1:
                  # http://www.assyriatv.org/page/2/
                  url_page=urlmain+'page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                data=data.split('<div class="video-list clearfix">')[1]
                
               
                if data is None:
                    return
               
                blocks=data.split('<!--Show Title -->')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block
                    block=block.lower()
                    regx='''<a href="(.*?)">(.*?)</a></h2>"'''
                    regx='''<a href="(.*?)">(.*?)</a></h2>'''
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    href=match[0][0]
                    name=match[0][1]
                    
                    
		         
                    regximg='''<iframe src="(.*?)".*?></iframe>'''
		
                    try:img=re.findall(regximg,block, re.M|re.I)[0]
                    except:img=''
                    print "image",img
                    

                    
                    
                                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    print "img",img
                    
                    addDir(name,href,1,img,1)                        
               
                   
                if len(blocks)>19:
                   addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
###############################################tv shows
def getvideos_tvshows(name,urlmain,page):##series
                if page>1:
                  #page-2
                  url_page=urlmain+'/page-'+str(page)+"/"
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url(url_page)
                if data is None:
                    return
		
		shows = re.findall('class="cover".*?<a\shref="(.*?)"\stitle="(.*?)".*?<img\ssrc="(.*?)"', data, re.S)
		
               
		if shows:
			for (Url, Title, Image) in shows:
                           
				Image = baseurl+Image
				
				#if decodeHtml(Title) in self.watched_liste:
					#self.filmliste.append((decodeHtml(Title), Url, Image, True))
				#else:
					#self.filmliste.append((decodeHtml(Title), Url, Image, False))
				Title=decodeHtml(Title.strip())
				if Title.strip()=='':
                                    Title1=os.path.split(Url)[1]
                                    title2=Title1.split("-")[0]
                                    Title=Title1.replace(title2+"-","")
                                addDir(Title,Url,203,Image)
                        addDir("next page",urlmain,201,'',str(page+1))
                else:
                      
                        addDir("Error:script error",urlmain,200,'',1)
                        
                return
def getvideos_seasons(name,urlmain,page):##series
                if page>1:
                  #page-2
                  url_page=urlmain+'/page-'+str(page)+"/"
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url(url_page)
                if data is None:
                    return
		
		series_f= re.findall('seasonoverviewlist.*?option>(.*?)</select>', data, re.S|re.I)
		if series_f:
			series = re.findall('value="(.*?)"\s>(.*?)<', series_f[0], re.S)
			if series:
				for (Url, Title) in series:
					
						
						addDir(decodeHtml(Title),Url,1,'',1)

                        else:
                              addDir("Error:script error",urlmain,1,'',1)
						
		else:				
                        addDir("Error:script error",urlmain,1,'',1)



            

 


#######################################host resolving                                                    
def get_play_link(name, url,page):
   
           
            vurl=url
            if not vurl.startswith("http"):
                vurl="http:"+vurl
            req1 = urllib2.Request(vurl)
            req1.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            req1.add_header('Referer', baseurl)
            try:
                response = urllib2.urlopen(req1)
            except urllib2.HTTPError as e:
                print e.fp.read()
                return None
                #self.session.open(MessageBox, _('Stream is private'), MessageBox.TYPE_INFO, timeout=3)

            link1 = response.read()
            
            #self.session.open(MessageBox, _('Stream is private'), MessageBox.TYPE_INFO, timeout=3)
            regxori='"hd":{"profile"\\:113,"origin"\\:"ns3\\.pdl","url"\\:"(.+?)","height"'
            regx='"profile":116,"origin":"gcs","url":"https://s.vimeocdn.com/vimeo-prod-skyfire-std-us/01/2182/5/135911377/402464149.mp4?token=55d5da48_0x6efa977ec6d931f41c62ee072fce404506b0b1e0","cdn"'
            regx='"profile":116,"origin":"gcs","url":"(.+?)","cdn"'

            regx='"url":"(.+?)",".+?"'
            parts=link1.split('"profile":')
            
            
            for i in range(1,len(parts)):
                
                '''parts 113,"quality":"720p","id":485323268,"fps":25}]},"hls":{"url":"https://skyf
iregce-a.akamaihd.net/exp=1456848965~acl=%2F%2A%2F156286157%2F%2A~hmac=38b653cd5
e5cc311aec0427c95e88dcdd1d60f005299426137f0992d833d9f33/2tierchgci/156286157/vid
eo/485323267,485323270,485323268/master.m3u8","origin":"gcs","cdn":"akfire_inter
connect"},"progressive":[{'''
                quality=re.findall('"quality":"(.+?)"',parts[i], re.M|re.I)[0]
                regx='''"url":"(.+?)"'''
                try:url=re.findall(regx,parts[i], re.M|re.I)[0]
                except:continue
                
               
                
                title=str(name)+"-"+quality
                #createm3u(title,url,"assyriantv.m3u")
                    
                addDir(quality,url,10,"",0)

            return    
def createm3u(title,link,filename=''):

    path=os.path.split(__file__)[0]
    filename=os.path.join(path,filename)
    if not os.path.exists(filename):
       
    
       cfile=open(filename,"w")
       cfile.write('#EXTM3U'+"\n")
       cfile.close()
    txt=open(filename).read()
    if title in txt:
        return
    title='#EXTINF:-1,'+title    
    cfile=open(filename,"a")
    cfile.write("\n"+title)
    cfile.write("\n"+link)
    cfile.close()                                     

def gethosts(name,urlmain):##cinema and tv featured

                
                data=read_url(urlmain)
                if data is None:
                    return
                
                try:data=data.split('class="wp-video">')[1]
                except:pass
                regx1 ='''<iframe.+?src="(.+?)".+?</iframe>'''   
                regx2='''<IFRAME SRC="(.+?)" FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=640 HEIGHT=268></IFRAME>'''
                #regx2=''''class="tabcontent"><iframe .+?src="(.+?)".+?></iframe></div>'''
                regx1='''<source type="video/mp4" src="(.+?)"'''
                if "vimeo" in data:
                    regx1='''<iframe src="(.+?)".+?</iframe>'''
                    url= re.findall(regx1,data, re.M|re.I)[0]
                    #print "link",link
                    #url='https://player.vimeo.com/video/156286157?title=0&byline=0&portrait=0'
                    #from urlresolver import resolve
                    get_play_link(name, url,1)
                    #stream_url=resolve_vimeo(link)
                    return
                    
		link= re.findall(regx1,data, re.M|re.I)[0]
		playlink(link)
                
                
                
                
                
                
            
def gethosts2(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                print data
                if data is None:
                    return
                regx="'http://moshahda.net/cgi-bin/index_dl.cgi(.*?)'"
		host= re.findall(regx,data, re.M|re.I)
		if host:
                        for href in host:
                          href= 'http://moshahda.net/cgi-bin/index_dl.cgi'+href 
			  playlink(href)

	    
def resolve_host1(url):#last good-used with local resolver
 
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(stream_link):
            
            xbmc.Player().play(stream_link)
            sys.exit(0)

def resolve_vimeo(web_url ):
        import json
        import urllib2
        req = urllib2.Request('https://player.vimeo.com/video/156286157?title=0&byline=0&portrait=0')
        req.add_header('Referer', 'http://www.assyriatv.org/')
        r = urllib2.urlopen(req)
        
        data = r.read()
        print "data",data
        regx='''"url":"https
://skyfiregcs-a.akamaihd.net/exp=1456848426~acl=%2A%2F485323268.mp4%2A~hmac=aa35
7b25d3563fcb6c8dede26474d3514564986ae6165ea45228a719e7ce68e3/2tierchgci/vimeo-pr
od-skyfire-std-us/01/1257/6/156286157/485323268.mp4","cdn":"akamai_interconnect"'''
        data = json.loads(data)

        vids = data['request']['files']['progressive']
        vids = [i['url'] for i in vids if 'url' in i]

        if vids:
            vUrlsCount = len(vids)

            if (vUrlsCount > 0):
                q = self.get_setting('quality')
                # Lowest Quality
                i = 0

                if q == '1':
                    # Medium Quality
                    i = (int)(vUrlsCount / 2)
                elif q == '2':
                    # Highest Quality
                    i = vUrlsCount - 1

                vUrl = vids[i]
                return vUrl	            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	


def addDir(name,url,mode,iconimage,page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)


if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        get_play_link(name,url,page)
elif mode==21:
        print ""+url
        gethosts2(url)
        
elif mode==22:
        print ""+url
        playlink(url)          
        
elif mode==100:##need
        print ""+url
        getvideos(name,url,page)
elif mode==1000:##need
        print ""+url
        getvideos_search(name,url,page)        
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
	
	search(url)
elif mode==200:
	print "mfaraj"+url
	getvideos_tvshows(name,url,page)
	#getvideopage(url,page)
elif mode==201:
	getgenre('shows')
elif mode==202:
	print ""+url
	getA_Z('shows')
	
elif mode==203:
	getvideos_seasons(name,url,page)

elif mode==10:

    playlink(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
