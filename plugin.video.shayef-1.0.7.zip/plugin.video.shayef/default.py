
# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import Item,readnet,get_params,getDomain,resolvehost,getsearchtext,logdata,trace_error,extractdata,playlink
item=Item()
addDir=item.addDir
endDir=item.endDir
################''
baseurl='http://cima4u.tv'

##########################################parsing tools


def showmenu():
                addDir("Search", 'http://www.shayef.net/1GetAllseries.asp',103,'img/search.png','',1,searchall=__file__)
                addDir("الاضافات الجديده", 'http://www.shayef.net/Mosalsalat.asp',204,'img/1.png','',1)
                addDir(" جميع المسلسلات", 'http://www.shayef.net/Mosalsalat.asp',104,'img/2.png','',1)
                addDir("مسلسلات عربيه", 'http://www.shayef.net/MosalsalatArab.asp',104,'img/3.png','',1)
                
                addDir("مسلسلات رمضان", 'http://www.shayef.net/MosalsalatRamadan.asp',104,'img/4.png','',1) 
                addDir("مسلسلات تركيه", 'http://www.shayef.net/MosalsalatTurky.asp',104,'img/5.png','',1)
                addDir("مسلسلات عالميه", 'http://www.shayef.net/MosalsalatWorld.asp',104,'img/6.png','',1)
                
                addDir("مواهب ومسابقات", 'http://www.shayef.net/Mwaheb.asp',205,'img/7.png','',1)
                addDir("برامج تلفزيون", 'http://www.shayef.net/BramejTV.asp',200,'img/8.png','',1)
                
                addDir("افلام عربيه", 'http://www.shayef.net/Aflam.asp',105,'img/9.png','',1)

        

# -*- coding: utf8 -*-



def years():###nt active-movies 110,series 210
        list=[]
        for i in range(1950,2019):
             #http://tellymov.com/s/year/2006
             list.append(i)
        list.reverse()     
        for i in list:
                
             addDir(str(i),'http://www.tfarjo.com/films/annee/film-'+str(i)+'-streaming/',100,'','',1)                 
                  
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def series_a_z(mainurl):
    matches = [ ('http://www.shayef.net/Mosalsalat.asp', 'ا'),('http://www.shayef.net/Mosalsalat.asp?Leter=2', '\xd8\xa8'), ('http://www.shayef.net/Mosalsalat.asp?Leter=3', '\xd8\xaa'), ('http://www.shayef.net/Mosalsalat.asp?Leter=4', '\xd8\xab'), ('http://www.shayef.net/Mosalsalat.asp?Leter=5', '\xd8\xac'), ('http://www.shayef.net/Mosalsalat.asp?Leter=6', '\xd8\xad'), ('http://www.shayef.net/Mosalsalat.asp?Leter=7', '\xd8\xae'), ('http://www.shayef.net/Mosalsalat.asp?Leter=8', '\xd8\xaf'), ('http://www.shayef.net/Mosalsalat.asp?Leter=9', '\xd8\xb0'), ('http://www.shayef.net/Mosalsalat.asp?Leter=10', '\xd8\xb1'), ('http://www.shayef.net/Mosalsalat.asp?Leter=11', '\xd8\xb2'), ('http://www.shayef.net/Mosalsalat.asp?Leter=12', '\xd8\xb3'), ('http://www.shayef.net/Mosalsalat.asp?Leter=13', '\xd8\xb4'), ('http://www.shayef.net/Mosalsalat.asp?Leter=14', '\xd8\xb5'), ('http://www.shayef.net/Mosalsalat.asp?Leter=15', '\xd8\xb6'), ('http://www.shayef.net/Mosalsalat.asp?Leter=16', '\xd8\xb7'), ('http://www.shayef.net/shayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netMosalsalat.asp?Leter=17', '\xd8\xb8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=18', '\xd8\xb9'), ('http://www.shayef.com/Mosalsalat.asp?Leter=19', '\xd8\xba'), ('http://www.shayef.com/Mosalsalat.asp?Leter=20', '\xd9\x81'), ('http://www.shayef.com/Mosalsalat.asp?Leter=21', '\xd9\x82'), ('http://www.shayef.com/Mosalsalat.asp?Leter=22', '\xd9\x83'), ('http://www.shayef.com/Mosalsalat.asp?Leter=23', '\xd9\x84'), ('http://www.shayef.com/Mosalsalat.asp?Leter=24', '\xd9\x85'), ('http://www.shayef.com/Mosalsalat.asp?Leter=25', '\xd9\x86'), ('http://www.shayef.com/Mosalsalat.asp?Leter=26', '\xd9\x87'), ('http://www.shayef.com/Mosalsalat.asp?Leter=27', '\xd9\x88'), ('http://www.shayef.com/Mosalsalat.asp?Leter=28', '\xd9\x8a')]
    for item in matches:
        title = item[1]
        url = item[0]
        pic = ''
        try:
            mode = item[2]
        except:
            mode = 3
        print "title",title
        
        if "?" in url:
                url=url.split("?")[1]
                url=mainurl+"?"+url
        else:
                url=mainurl
        addDir(title, url, 200,'img/1.png', '',1)

def movies_a_z(mainurl):
    matches = [ ('http://www.shayef.net/Mosalsalat.asp', 'ا'),('http://www.shayef.net/Mosalsalat.asp?Leter=2', '\xd8\xa8'), ('http://www.shayef.net/Mosalsalat.asp?Leter=3', '\xd8\xaa'), ('http://www.shayef.net/Mosalsalat.asp?Leter=4', '\xd8\xab'), ('http://www.shayef.net/Mosalsalat.asp?Leter=5', '\xd8\xac'), ('http://www.shayef.net/Mosalsalat.asp?Leter=6', '\xd8\xad'), ('http://www.shayef.net/Mosalsalat.asp?Leter=7', '\xd8\xae'), ('http://www.shayef.net/Mosalsalat.asp?Leter=8', '\xd8\xaf'), ('http://www.shayef.net/Mosalsalat.asp?Leter=9', '\xd8\xb0'), ('http://www.shayef.net/Mosalsalat.asp?Leter=10', '\xd8\xb1'), ('http://www.shayef.net/Mosalsalat.asp?Leter=11', '\xd8\xb2'), ('http://www.shayef.net/Mosalsalat.asp?Leter=12', '\xd8\xb3'), ('http://www.shayef.net/Mosalsalat.asp?Leter=13', '\xd8\xb4'), ('http://www.shayef.net/Mosalsalat.asp?Leter=14', '\xd8\xb5'), ('http://www.shayef.net/Mosalsalat.asp?Leter=15', '\xd8\xb6'), ('http://www.shayef.net/Mosalsalat.asp?Leter=16', '\xd8\xb7'), ('http://www.shayef.net/shayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netshayef.netMosalsalat.asp?Leter=17', '\xd8\xb8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=18', '\xd8\xb9'), ('http://www.shayef.com/Mosalsalat.asp?Leter=19', '\xd8\xba'), ('http://www.shayef.com/Mosalsalat.asp?Leter=20', '\xd9\x81'), ('http://www.shayef.com/Mosalsalat.asp?Leter=21', '\xd9\x82'), ('http://www.shayef.com/Mosalsalat.asp?Leter=22', '\xd9\x83'), ('http://www.shayef.com/Mosalsalat.asp?Leter=23', '\xd9\x84'), ('http://www.shayef.com/Mosalsalat.asp?Leter=24', '\xd9\x85'), ('http://www.shayef.com/Mosalsalat.asp?Leter=25', '\xd9\x86'), ('http://www.shayef.com/Mosalsalat.asp?Leter=26', '\xd9\x87'), ('http://www.shayef.com/Mosalsalat.asp?Leter=27', '\xd9\x88'), ('http://www.shayef.com/Mosalsalat.asp?Leter=28', '\xd9\x8a')]
    for item in matches:
        title = item[1]
        url = item[0]
        pic = ''
        try:
            mode = item[2]
        except:
            mode = 3
        print "title",title
        
        if "?" in url:
                url=url.split("?")[1]
                url=mainurl+"?"+url
        else:
                url=mainurl
        addDir(title, url, 100,'img/1.png','',1)   
###################################movies
			  

        
        
          
 
          
       


def search(name,sterm,page):##may pastte code of getmovies here
                surl='http://www.shayef.net/1GetAllseries.asp'


               
                params={'keyword':sterm}

                data=postData(surl,params,'www.shayef.net','http://www.shayef.net/')     
               
                       
                
                
                print 'data1',data
                if data is None:
                    return
               
                
                #regx='''<a href="(.*?)"><li class="s1"><img src="(.*?)" alt=""><span></span>(.*?)<br><span></span></li></a>'''
               # match=re.findall(regx,data, re.M|re.I)
                #print "match",match
                #sys.exit(0)
                
                regx='''<li><a href=(.*?)><img src=(.*?)" />(.*?)<br></a></li>'''
                match=re.findall(regx,data, re.M|re.I)
                for href,image,title in match:
                    print "image",image
                   
                    image=image.split(" ")[0]
                    addDir(title,href,202,image,'',1,maintitle=True) 

                return    
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                    except:
                            trace_error()
                            continue

                    regx='''<h4>(.*?)</h4>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    
                   
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
                
                





               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
                data=readnet(url)           
                print "data",data
                
               
                if data is None:
                    return
               
                
                #regx='''<a href="(.*?)"><li class="s1"><img src="(.*?)" alt=""><span></span>(.*?)<br><span></span></li></a>'''
               # match=re.findall(regx,data, re.M|re.I)
                #print "match",match
                #sys.exit(0)

                blocks=data.split('class="vi-box"')
               
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                    except:
                            trace_error()
                            continue

                    regx='''<h4>(.*?)</h4>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    
                   
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,name,1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                
                









###############################################series
def getseries(name,url,page):##series

                       
                
                data=readnet(url)           
                
                
                print "dataxx",data
                if data is None:
                    return
               
                
                #regx='''<a href="(.*?)"><li class="s1"><img src="(.*?)" alt=""><span></span>(.*?)<br><span></span></li></a>'''
               # match=re.findall(regx,data, re.M|re.I)
                #print "match",match
                #sys.exit(0)

                blocks=data.split('class="vi-box"')
               
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                    except:
                            trace_error()
                            continue

                    regx='''<h4>(.*?)</h4>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    
                   
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,name,1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   

def newseries(name,url,page):##series

                       
                
                data=readnet(url)           
                
                
               
                if data is None:
                    return
               
                
                #regx='''<a href="(.*?)"><li class="s1"><img src="(.*?)" alt=""><span></span>(.*?)<br><span></span></li></a>'''
               # match=re.findall(regx,data, re.M|re.I)
                #print "match",match
                #sys.exit(0)

                blocks=data.split('vi-box-top-Home')
               
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                    except:
                            trace_error()
                            continue

                    regx='''<h4>(.*?)</h4>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    
                   
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,name,1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                

                
def getseries2(name,url,page):##series

                       
                
                data=readnet(url)           
                
                
               
                if data is None:
                    return
               
                
                #regx='''<a href="(.*?)"><li class="s1"><img src="(.*?)" alt=""><span></span>(.*?)<br><span></span></li></a>'''
               # match=re.findall(regx,data, re.M|re.I)
                #print "match",match
                #sys.exit(0)

                blocks=data.split('class="vi-box"')
               
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                    except:
                            trace_error()
                            continue

                    regx='''<h4>(.*?)</h4>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    
                   
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,201,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
                               





                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
               
                
                
               
                if data is None:
                    return
               
                #blocks=data.split('قائمة الحلقات:')
                regx='''<a href="(.+?)"><h4>(.+?)</h4></a>'''
                match=re.findall(regx,data, re.M|re.I)
                print "match",match
                for href,title in match:
                    if not 'ZoneID' in href:
                        continue
                    addDir(title,href,202,'','',1,maintitle=True)    
                i=0
                return 
                                           
                                    


def getepisodes(name,url,page):##series


               
               
                data=readnet(url)
               
                
                
               
                if data is None:
                    return
                regx='''<iframe.+?src="(.+?)".+?></iframe>'''
                try:
                    href3 = re.findall(regx, data, re.M | re.I)[0]
                    print 'href3',href3
                    addDir("mp4",href3, 0 ,"",name,1,link=True)
                    return
                except:
                    pass
                #blocks=data.split('قائمة الحلقات:')
                regx='''<link rel="image_src" href="(.+?)"/>'''
                image=re.findall(regx,data, re.M|re.I)[0]
                print "image",image
               
                regx='''<a href="(.+?)"><h2>(.+?)</h2></a>'''
                match=re.findall(regx,data, re.M|re.I)
                print "match",match
                for href,title in match:
                    addDir(title,href,1,image,name,1,maintitle=True)    
                i=0
                return 


#######################################host resolving                                                    
                    

def getservers(name,url):
                #http://cimaclub.com/%d9%81%d9%8a%d9%84%d9%85-i-kill-giants-2017-web-dl-%d9%85%d8%aa%d8%b1%d8%ac%d9%85//?view=1
        
        data=readnet(url)
        regx='''<iframe.+?src="(.+?)".+?></iframe>'''
        href1= re.findall(regx, data, re.M | re.I)[0]
        print "href1",href1
        
       
       
        data1=readnet(href1)
        regx="hls: '(.+?)'"
        match= re.findall(regx, data1, re.M | re.I)
        #print "href2",href2
        #addDir("m3u8",str(href2),0,"","",1,link=True)
        #return
        for href in match:
            print "href2",href
            addDir("m3u8",href,0,"","",1,link=True)    
        
        regx="mp4:.+?'(.+?)'.+?"
        match2 = re.findall(regx, data1, re.M | re.I)
        print 'match2',match2
        for href in match2:
            addDir("mp4",href,3,"",name,1)


        return
                 
def resolve_host(surl):
       
       return

  
def start():  
        params=get_params()
        url=None
        name=None
        mode=None
        page=1


        name=params.get("name",None)
        url=params.get("url",None)
        try:mode=int(params.get("mode",None))
        except:mode=None
        image=params.get("image",None)
        section=params.get("section",None)
        page=int(params.get("page",1))
        extra=params.get("extra",None)
        show=params.get("show",None)





        print "Mode1: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "Image: "+str(image)
        print "page: "+str(page)
        print "section: "+str(section)
        print "show: "+str(show)
        print "extra: "+str(extra)
        ##menu and tools
        if mode==None==None or url==None or len(url)<1:
                print ""
                showmenu()
        ##hosts        
        elif mode==1:
                print ""+url
                
                getservers(name,url)
        elif mode==2:
                print ""+url
                resolvehost(item,name,url)
        elif mode==3:
                print ""+url
                playlink(item,name,url)
                
        ###movies     
                
        elif mode==100:
                print ""+url
                getmovies(name,url,page)
        
        elif mode==101:
                print ""+url
                years()	
        
        elif mode==104:
            series_a_z(url)
        elif mode==105:
            movies_a_z(url)
            
        elif mode==103:
                sterm = getsearchtext()      
                 
                search("Search",sterm,page)
        
                
        ##extra years 104,genres 105,a-z 106        
        ###series        
        
        
        elif mode==200:
        
        	getseries(name,url,page)
        	
        elif mode==201:
        	getseasons(name,url,page)
        	
        elif mode==202:
        	getepisodes(name,url,page)
        elif mode==204:
        	newseries(name,url,page)
        elif mode==205:
        
        	getseries2(name,url,page)
        	
        	
        elif mode==203:
        	print ""+url
                search_tvshows(url)           
        
        
        return endDir()
start()
