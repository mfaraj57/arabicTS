# -*- coding: utf8 -*-

import sys
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
import urllib2,urllib
import re
import httplib
import time,itertools

__settings__ = xbmcaddon.Addon(id='plugin.video.dramacafe.in')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = (sys.argv[0])

def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.online.dramacafe.in')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link
                        	
def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial

    return inner



def getCategories():


        addDir('SEARCH','http://www.online.dramacafe.in/search.php?keywords=',3,'img/search.png',1) 
        addDir('أخر الاضافات ','http://www.online.dramacafe.in/newvideos.html',8,'img/series.png',1)          
        addDir('أفـــلام أجنبية','http://www.online.dramacafe.in/browse-NonArabicFilms-videos-1-date.html',11,'img/mov.png',1)          
        addDir('سلسلــة أفلام','http://www.online.dramacafe.in/browse-MoviesPacks-videos-1-date.html',11,'img/dubbed.png',1)
        addDir('أفضل الافـــلام','http://www.online.dramacafe.in/topvideos.html?do=recent',8,'img/top.png',1)
	
	addDir('أفـــلام عربية','http://www.online.dramacafe.in/browse-ArabicMovies-videos-1-date.html',11,'img/arabic.png',1)
	
        
        addDir('مســلسلات عربية','url',100,'img/mus.png',1)
        
        addDir('مسلسلات أجنبية','url',111,'img/non.png',1)
        
        addDir('مسلسلات مدبلجة','url',110,'img/dubbed.png',1)
        addDir('درامـــا أسيوية','http://www.online.dramacafe.in/browse-AsianDrama-videos-1-title.html',11,'img/asia.png',1)
        addDir('بــوليود','http://www.online.dramacafe.in/browse-Bollywood-videos-1-date.html',11,'img/bollywod.png',1)
        addDir('أنيمايشن','url',112,'img/cartoon.png',1)
        addDir('مســــرحيات','http://www.online.dramacafe.in/browse-Theatre-videos-1-title.html',11,'img/theater.png',1)
        
               
def GENRES(url):
      	addDir('مسلسلات رمضان 2017','http://www.online.dramacafe.in/browse-Ramadan2017-videos-1-date.html',11,'img/mos.png',1)

      	addDir('مسلسلات رمضان 2016','http://www.online.dramacafe.in/browse-Ramadan2016-videos-1-date.html',11,'img/mos.png',1)
        
        addDir('مسلسلات رمضان 2015','http://www.online.dramacafe.in/browse-Ramadan2015-videos-1-date.html',11,'img/mos.png',1)
        addDir('مسلسلات رمضان 2014','http://www.online.dramacafe.in/browse-Ramadan2014-videos-1-date.html',11,'img/mos.png',1)
        addDir('مسلسلات رمضان 2013','http://www.online.dramacafe.in/browse-Ramadan2013-videos-1-date.html',11,'img/mos.png',1)
        addDir('مسلسلات رمضان 2012','http://www.online.dramacafe.in/browse-Ramadan2012-videos-1-date.html',11,'img/mos.png',1)
        addDir('مسلسلات رمضان 2011','http://www.online.dramacafe.in/browse-Ramadan2011-videos-1-date.html',11,'img/mos.png')

        addDir('درامــا مصرية','http://www.online.dramacafe.in/browse-EgyptianDrama-videos-1-date.html',11,'img/mos.png',1)
         
        addDir('دراما سورية','http://www.online.dramacafe.in/browse-SyrianDrama-videos-1-date.html',11,'img/mos.png',1)

        addDir('دراما لبنانية','http://www.online.dramacafe.in/browse-LebaneseDrama-videos-1-date.html',11,'img/mos.png',1)

        addDir('مسلسلات خليجية','http://www.online.dramacafe.in/browse-Khaleeji-videos-1-date.html',11,'img/mos.png',1)

        addDir('دراما عراقية','http://www.online.dramacafe.in/browse-IraqiDrama-videos-1-date.html',11,'img/mos.png',1)
        
        addDir('مسلسلات بدوية','http://www.online.dramacafe.in/browse-Historical-videos-1-date.html',11,'img/mos.png',1)
        
	    	
        setView('movies', 'MAIN')        
        
def Dubbed(url): 
       addDir('مسلسلات هندية مدبلجة','http://www.online.dramacafe.in/browse-AnimeSeries-videos-1-date.html',11,'img/mos.png',1)
       addDir('مسليلات تركية مدبلجة','http://www.online.dramacafe.in/browse-TurkishDrama-videos-1-date.html',11,'img/mos.png',1)
       addDir('مسلسلات ايرانية مدبلجة','http://www.online.dramacafe.in/browse-IranianDrama-videos-1-date.html',11,'img/mos.png',1)
       addDir('مسلسلات مكسكية مدبلجة','http://www.online.dramacafe.in/browse-MexicanDrama-videos-1-date.html',11,'img/mos.png',1)
       setView('movies', 'MAIN') 
       
       
def series(url):       
       addDir('مسلسلات أجنبية','http://www.online.dramacafe.in/browse-NonArabicSeries-videos-1-date.html',11,'img/non.png',1)
       addDir('افضل المسلسلات مشاهدة','http://www.online.dramacafe.in/browse-NonArabicSeries-videos-1-views.html',11,'img/non.png',1)
       addDir('افضل  المسلسلات المعنونة','http://www.online.dramacafe.in/browse-NonArabicSeries-videos-1-title.html',11,'img/non.png',1)
       setView('movies', 'MAIN') 
       
def anemi(url):  
      addDir('أفلام اينمي','http://www.online.dramacafe.in/browse-AnimeAndCartoon-videos-1-title.html',11,'img/cartoon.png',1)
      addDir('مسلسلات انيمي ','http://www.online.dramacafe.in/browse-AnimeSeries-videos-1-date.html',11,'img/cartoon.png',1)
      addDir('مسلسلات كرتون مدبلجة','http://www.online.dramacafe.in/browse-Cartoons-videos-1-date.html',11,'img/cartoon.png',1)
      addDir('افضل المشاهدات','http://www.online.dramacafe.in/browse-AnimeAndCartoon-videos-1-views.html',11,'img/cartoon.png',1)
      setView('movies', 'MAIN') 
                
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url=url+search_entered
        print "mfarajx4_url",url
          
        getVideos("Search",url,1)         
def getVideos(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                   
                   url_page=urlmain+"/?"+str(page)+".html"
                   url_page=urlmain+"/&page="+str(page)+".html"
                   url_page=urlmain+"page"".html"
                   
                   
                   url_page=urlmain+'&page='+str(page)+".html"
               else:
               
                
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 

               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
       
             
               regx='''<a href="(.*?)" .*?>\s*<span class="pm-thumb-fix-clip">\s*<img src="(.*?)" alt="(.*?)" .*?>'''
             
               
                 
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        img = ''
 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        #title=title.replace("فيلم مترجم بجود عالية","")
                        addDir(name,url,6, image,page)
               
               addDir('next page>',urlmain, 1,'http://cdn.mysitemyway.com/etc-mysitemyway/icons/legacy-previews/icons/glowing-green-neon-icons-media/111646-glowing-green-neon-icon-media-a-media32-forward.png',str(page+1))
              

              

def getSeriese(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                   
                   url_page=urlmain+"/?"+str(page)+".html"
                   url_page=urlmain+"/&page="+str(page)+".html"
                   url_page=urlmain+"page"".html"
                   
                   
                   url_page=urlmain+'&page='+str(page)+".html"
               else:
               
                
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 

               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
       
             
               regx=''' <a href="(.*?)" .*?>\s*<span class="pm-thumb-fix-clip">\s*<img src="(.*?)" alt="(.*?)" .*?>'''
              
               
                 
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        img = ''
 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        #title=title.replace("فيلم مترجم بجود عالية","")
                        addDir(name,url,89, image,page)
               
               addDir('next page>',urlmain, 88,'http://cdn.mysitemyway.com/etc-mysitemyway/icons/legacy-previews/icons/glowing-green-neon-icons-media/111646-glowing-green-neon-icon-media-a-media32-forward.png',str(page+1))
              

def getVideosEpisodes(name1, urlmain,page):  
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                   
                   url_page=urlmain+"/?"+str(page)+".html"
                   url_page=urlmain+"/&page="+str(page)+".html"
                   url_page=urlmain+"page"".html"
                   
                   
                   url_page=urlmain+'&page='+str(page)+".html"
               else:
               
                
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 

               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
       
             
               regx=''' <a href="(.*?)" .*?>\s*<span class="pm-thumb-fix-clip">\s*<img src="(.*?)" alt="(.*?)" .*?>'''
              
               
                 
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        img = ''
 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        #title=title.replace("فيلم مترجم بجود عالية","")
                        addDir(name,url,6, image,page)
               


def getTop(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                   
                   url_page=urlmain+"/?"+str(page)+".html"
                   url_page=urlmain+"/&page="+str(page)+".html"
                   url_page=urlmain+"/""/?&page="+str(page)+".html"
               else:
                
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 

               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
       
             
               regx=''' <a href="(.*?)" .*?>\s*<span class="pm-thumb-fix-clip">\s*<img src="(.*?)" alt="(.*?)" .*?>'''
               #regx=''' <a href="(.*?)" class="pm-thumb-fix pm-thumb-145"><span class="pm-thumb-fix-clip"><img src="(.*?)" alt="(.*?)" .*?>''' 
                 
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        img = ''
 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        title=title.replace("فيلم","")
                        addDir(name,url,6, image,page)
               
               addDir('next page>',urlmain, 8,'http://cdn.mysitemyway.com/etc-mysitemyway/icons/legacy-previews/icons/glowing-green-neon-icons-media/111646-glowing-green-neon-icon-media-a-media32-forward.png',str(page+1))
              

def get_play_link(name, url,page):
    if True:
        print 'now get the player url'
        print "m1",url
        videoid = re.findall('-video_(.*?).html', url)
        print "videoid",videoid
        url = 'http://www.online.dramacafe.in/ajax.php?p=video&do=getplayer&vid=' + videoid[0] + '&aid=4&player=detail'
        print "urlxx",url
        from xbmctools import readnet,finditems,addDir
        links=readnet(url)
        
        #req = urllib2.Request(url)
        #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        #response = urllib2.urlopen(req)
        #link = response.read()
        targets = re.findall('src="(.+?)"', links)
        print "tagrets",targets

        data2=readnet(targets[0])    
        if 'dailymotion.com' in str(targets[0]):
            from urlresolver import resolve
       
            final_urls=resolve(str(targets[0]),True)
           
            for item in final_urls:
               
               addDir(item[0],item[1],10,"","",0)
            return   
       
       
        elif 'type="video/mp4"' in data2:

          regx='''src="(.+?)" type="video/mp4" label="(.+?)" res="(.+?)"'''
          regx="src='(.+?)'"
          mp4links = finditems(data2,'<source','>')
          print "mp4links",mp4links[0]
          for item in mp4links:
                 link = re.findall(regx,item, re.M|re.I)[0]
                 print "linkxx",link
                 if "hd" in link:
                         addDir("hd",link,0,"","",1,link=True)
                 else:
                                
                         addDir("sd",link,0,"","",1,link=True)

          return                                
          
        else:                
                
            from urlresolver import resolve
            stream_link=resolve(targets[0])
            print "stream_link",stream_link
            playlink(stream_link)
            return

           
            print "m12",target[0]
            vurl=target[0]
            if not vurl.startswith("http"):
                vurl="http:"+vurl
            req1 = urllib2.Request(vurl)
            req1.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            req1.add_header('Referer', 'http://www.online.dramacafe.in/')
            try:
                response = urllib2.urlopen(req1)
            except urllib2.HTTPError as e:
                print e.fp.read()
                return None
                #self.session.open(MessageBox, _('Stream is private'), MessageBox.TYPE_INFO, timeout=3)

            link1 = response.read()
            print "link1",link1
           
            #self.session.open(MessageBox, _('Stream is private'), MessageBox.TYPE_INFO, timeout=3)
            regxori='"hd":{"profile"\\:113,"origin"\\:"ns3\\.pdl","url"\\:"(.+?)","height"'
            regx='"profile":116,"origin":"gcs","url":"https://s.vimeocdn.com/vimeo-prod-skyfire-std-us/01/2182/5/135911377/402464149.mp4?token=55d5da48_0x6efa977ec6d931f41c62ee072fce404506b0b1e0","cdn"'
            regx='"profile":116,"origin":"gcs","url":"(.+?)","cdn"'

            regx='"url":"(.+?)",".+?"'
            parts=link1.split('"profile":')
            print "m23",parts
           
            for i in range(1,len(parts)):
                print "parts",parts[i]
                url=parts[i].split(",")[2].replace('"url":','').replace('"','')
                if i==1:
                    quality='Medium resolution'

                elif i==2:
                    quality='High resolution'
                elif i==3:
                    quality='Low resolution'
               
                addDir(quality,url,10,"",0)

            return   
            #regx='"profile"\\:116,"origin"\\:"gcs","url"\\:"(.+?)","cdn"'
            #regx='"hd":{"profile"\\:113,"origin":"ns3\\.pdl-secure","url":"https://pdlvimeocdn-a.akamaihd.net/46586/021/397243300.mp4?token2=1440075943_54f73c4eb063f707d15ef688188ca5c3&aksessionid=28104c656cf8c20f","height"'
            #regx='''"hd":{"profile"\\:113,"origin"\\:"gcs","url"\\:"(.+?)","cdn"'''
            #regx='''"hd":{"profile"\\:113,"origin"\\:"ns3\\.pdl","url":"(.+?)","height"'''
            #regx='''"hd":{"profile":113,"origin"\\:"gcs","url":"https://s.vimeocdn.com/vimeo-prod-skyfire-std-us/01/2165/5/135829560/402147637.mp4?token=55d5d048_0x8bc353e94490ce42f3b9c5f1bddb67f1ef13b4b3","cdn"'''
            hdLink = re.findall(regx, link1,re.S)
           
            final_url = str(hdLink[0])
           
        listItem = xbmcgui.ListItem(path=str(final_url))
        xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)
    else:
            return None
            
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param

def playlink(url):
            print "m2",url
	    listItem = xbmcgui.ListItem(path=str(url))
	    xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)

def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	


def addDir(name,url,mode,iconimage,page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
initial=None
max=None
rating=None
cast=None
year=None
genre=None
duration=None
writer=None
director=None

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
	
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        page=1
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
if mode==None or url==None or len(url)<1:
        print ""
        getCategories()
      
elif mode==1:
        print ""+url
        getVideos(name,url,page)
elif mode==11:
        print ""+url
        getVideos(name,url,page)
elif mode==8:
        print ""+url
        getTop(name,url,page)
        #getVideos(name,url,page)
elif mode==88:
        print ""+url
        
        getSeriese(name,url,page)       
elif mode==89:
        print ""+url
        
        getVideosEpisodes(name,url,page)  
elif mode==3:
        print ""+url
        search(url)		    
elif mode==100:
        print ""+url
        GENRES(url)
        
        
elif mode==110:
        print ""+url        
        Dubbed(url)
elif mode==111:
        print ""+url        
        series(url) 
                
elif mode==112:
        print ""+url         
        anemi(url)
               
elif mode==6:
		print ""+url
		get_play_link(name,url,page)	
elif mode==10:

    playlink(url)
   
    
    
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
