# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import addDir,finditems,findalldata,readnet,supported,get_params,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error,cfresolve,getData,geturlbyreferal,removeunicode,finddata
################''
baseurl = 'http://cera.video'
host='cera.video'

##########################################parsing tools


def showmenu():
        ##main
        addDir('Search',baseurl+'/?s=',103,'img/0.png','',1)    
        
            
        addDir('••افلام أجنبية••','https://cera.video/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html',100,'img/1.png','',1)
        addDir('••مسلسلات أجنبية كاملة••','https://cera.video/tv-series-translated-online.html',200,'img/2.png','',1)
        addDir('••أحدث الحلقات الأسبوعية••',baseurl+"/",100,'img/3.png','',1)
        addDir('••الحلقات الاسبوعية••',baseurl+'/series-download-watch-episodes-aflamhq-egfire-arablionz-translated-myegy.html/',100,'img/4.png','',1)
        addDir('••مسلسلات رمضان 2017••',baseurl+'/mosalsalat-ramadan-2017-moshahda-mbc-net-shahid-nahar-drama-bramij-google-drive.html/',300,'img/10.png','',1)

        addDir('••مسلسلات رمضان 2016••',baseurl+'/mosalsalat-ramadan-2016-watch-shahid-net-mbc-download-dailymotion-online/',300,'img/5.png','',1)

        addDir('••مسلسلات انمي••',baseurl+'/all-full-anime-series.html/',300,'img/6.png','',1)
        addDir('One-Piece',baseurl+'/all-one-piece.html/',100,'img/7.png','',1)
        addDir('Anime-Bleach',baseurl+'/all-anime-bleach-online-translated-online.html',100,'img/8.png','',1)
        addDir('Naruto-Shippuden',baseurl+'/all-naruto-shippuden.html/',100,'img/9.png','',1)
                 
        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        searchkey = getsearchtext()      
         
        url= url+searchkey      
          
        search_results("Search",url,1)


def search_results(namemain,page_url,page):##may pastte code of getmovies here


                if page>1:
                 
                  url_page=url+'/page/'+str(page)
                 
                  
                else:
                
                      url_page=page_url
                print "url_page",url_page
                
                data=cfresolve(url_page)
                                  
                
                if data is None:
                    return
               
                blocks=data.split('class="moviefilm">')
                i=0
             
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''href="(.*?)"'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ")
                    if "all-episodes" in href:
                            mode=202
                    else:
                            mode=1
                    try:addDir(name,href,mode,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",page_url,104,"img/next",'',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))



               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
                page_url=url
                if page>1:
                 
                  url_page=url+'/page/'+str(page)
                 
                  
                else:
                
                      url_page=url
                print 'url_page',url_page
               
                data=cfresolve(url_page)
                import time
                time.sleep(9)
                data=cfresolve(url_page)
                print "data",data
                if data is None:
                    return
               
                blocks=data.split('moviefilm')
                i=0
                print 'blocks',len(blocks)
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''href="(.*?)"'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",page_url,200,"img/next",'',str(page+1))                
               






###############################################series


def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                 #https://cera.video/tv-series-translated-online.html/page/2/ 
                 url_page=urlmain+"/page/"+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=cfresolve(url_page)
              
                
               
                if data is None:
                    return
               
                blocks=data.split('class="moviefilm">')
                i=0
               
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue

                    regx='''<div class="movief"><a href="(.*?)">(.*?)</a></div>'''
                    match=re.findall(regx,block, re.M|re.I)
                    href=match[0][0]
                    name=match[0][1]
                 

                        
                    regx='''src="(.*?)"'''
                    
                    img=re.findall(regx,block, re.M|re.I)[0]
                    print "match",match
                    
                    
                   
                    
                    name=name.replace('Watch','').replace( 'online free.','').strip()
  
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    try:addDir(name,href,201,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,200,'img/next.png','',str(page+1))
               
                    
def getseasons(name,urlmain,page):##series

                 
                if page>1:
                  
                  url_page=urlmain+'/page/'+str(page)
                  
                  
                else:
                
                      url_page=urlmain
                data=cfresolve(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('class="moviefilm">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,202,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,300,'img/next.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                                           
                                    


def getepisodes(name,urlmain,page):##series

                print "page",page
               
                if page>1:
                  # http://cera.online/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html/page/2/
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=cfresolve(url_page)
                
                
               
                if data is None:
                    return
               
                blocks=data.split('class="moviefilm">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*?src="(.*?)"'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regx='''<div class="movief"><a href="(.*?)">(.*?)</a></div>'''
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
               #addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    
                    
def getanime(name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=cfresolve(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('class="moviefilm">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,100,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,300,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

#######################################host resolving                                                    
def getData(url, data = {}, host = '', Referer = ''):
    import requests
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.get(url, headers=headers)
    htmldata = r.content
    return htmldata

#url='https://blog.vesload.com/?p=1018&cer=T1ZXbXBLK1N4b1JUYXRHUUIyekpSdEZjbTBpQ1Jzak10aVA4TmZNUExkN3lLdVRsRVFUL3NVV3dTVTAzSEpnNTQ0QW1FMWtnRVJwT0h5Q0NhZmwwejVIZTBkTXNqQlhlTFJPcHV6MElxamV1Q000UW1aR0V0eTZEbWtpaTZPaFM='
url='https://blog.vesload.com/?p=26&cer=T1ZXbXBLK1N4b1JUYXRHUUIyekpSdEZjbTBpQ1Jzak10aVA4TmZNUExkN3lLdVRsRVFUL3NVV3dTVTAzSEpnNTQ0QW1FMWtnRVJwT0h5Q0NhZmwwejVIZTBkTXNqQlhlTFJPcHV6MElxamV1Q000UW1aR0V0eTZEbWtpaTZPaFM='
datad={}
host='blog.vesload.com'
Referer='https://cera.video/%d9%81%d9%8a%d9%84%d9%85-death-2017-%d9%85%d8%aa%d8%b1%d8%ac%d9%85.html'
      
#print "getdata",getData(url,data,host,Referer)                    
#url='https://blog.vesload.com/?p=1018&cer=T1ZXbXBLK1N4b1JUYXRHUUIyekpSdEZjbTBpQ1Jzak10aVA4TmZNUExkN3lLdVRsRVFUL3NVV3dTVTAzSEpnNTQ0QW1FMWtnRVJwT0h5Q0NhZmwwejVIZTBkTXNqQlhlTFJPcHV6MElxamV1Q000UW1aR0V0eTZEbWtpaTZPaFM='
datad={}
#host='blog.vesload.com'
#Referer='https://cera.video/%d9%81%d9%8a%d9%84%d9%85-death-2017-%d9%85%d8%aa%d8%b1%d8%ac%d9%85.html'
#url='https://cera.video/cdn-cgi/l/chk_jschl?jschl_vc=e3d6cab3ae44c9960b3e000519e8c5f7&pass=1517566086.449-CBixcL%2BHWo&jschl_answer=-474'

host='blog.vesload.com'

#print "getdata",getData(url,data,host,Referer)

#datam=getData(url,datad,host,Referer)

#if "keeload" in datam:
       # print "result1","ok"
#else:
        #print "result1","False"
def getservers(name,urlmain):
                host='blog.vesload.com'
                data=cfresolve(urlmain)
                if data is None:
                    return
               
                
                regx='''<a href="(.*?)" target=".*?">'''
                href=re.findall(regx,data, re.M|re.I)[0]
                print "href",href
                print "urlmain",urlmain
                datam=getData(href,datad,host,Referer)                    

                                #print 'daa2',data2
                if "keeload" in datam:
                        print "result1","ok"
                else:
                        print "result1","False"
                #sys.exit(0)
                regx='''iframe.*?src="(.*?)".*></iframe>'''
                match=re.findall(regx,datam.lower(), re.M|re.I)
                print "match",match
                
                
                for href in match:
                        if not href.startswith("http:") and not href.startswith("https") :
                           href="http:"+href
                           
                        host=getDomain(href)
                        if host=='player' or host=='server':
                                continue
                        addDir(host,href,2,"img/"+host+".png","",1)

               
                   

                 
def resolve_host(urlmain):
                link=urlmain
                
                if 'filescdn' in link:
                    data=readnet(link)
                    regx='file: "(.*?)"'
                    link= re.findall(regx,data, re.M|re.I)[0]
                    playlink(link)
                    return


                if 'ayamov' in link:
                        regx='''window.top.location.href = 'http://ayamov.com/e28oziyjz520/Allied_2016_DvDScr_[cera].mp4';'''
                        link='http://ayamov.com/e28oziyjz520/Allied_2016_DvDScr_[cera].mp4'
                        playlink(link)
                        return
                if 'raptu' in link.lower():
                        regx='''file":"(.*?)"'''
                        data=readnet(link)
                        regx='''"file":"(.*?)","label":"(.*?)"'''
                        
                        data=finddata(data,'"sources"',']')
                        links= re.findall(regx,data, re.M|re.I)
                        for link,label in links:
                            addDir(label,link,22,'img/server.png','',1)    
                        return
                        
                if 'vidlox' in link:
                        print link
                        data=readnet(link)
                        regx='''<source src="(.*?)" type='video/mp4'>'''
                        regx='''sources:(.*?)'''
                       
                        data=finddata(data,"sources:",']')
                        links=data.split('","')
                        
                        print "link0",links[0]
                        print "link1",links[1]
                        link0=links[0].replace("[",'').replace('"','').strip()
                        link1=links[1].replace("[",'').replace('"','').strip()
                        addDir("m3u8",link0,22,'img/server.png','',1)
                        addDir("mp4",link1,2,'img/server.png','',1)  
                        
                        return
                if 'googlevideo' in link:
                        
                        
                        addDir('googlevideo',link,9,'','',1,link=True)
                        
                        return                
                

                from tsresolver import resolve
                stream_url=resolve(link)
                playlink(stream_url) 

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)
elif mode==104:
	print ""+url
        search_results(url)
        
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           
elif mode==300:
	print ""+url
        getanime(name,url,page)  
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
