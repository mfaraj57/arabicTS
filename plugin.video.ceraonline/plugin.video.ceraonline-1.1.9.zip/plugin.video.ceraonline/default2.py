# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py




try:import sys, syspath
except:pass
import os, sys
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
from addon.common.net import Net
from urlresolver import resolve
import StringIO

__settings__ = xbmcaddon.Addon(id='plugin.video.ceraonline')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://cera.online'
host='cera.online'
####functions
def read_url2(url,host):
        import mechanize
        br = mechanize.Browser()
        br.set_handle_robots(False)  #add this line to your code
def read_url(url):
     
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	print "response",response.geturl
	sys.exit(0)
	link=response.read()
        return link
def readnet(url):
        import requests
        data=requests.get(url, verify=False)
        return data.content
def readnet2(url):
            return getrequest(url)
            #sys.exit(0)
            from t0mm0.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      
def decodeHtml(text):
    text = text.replace('&auml;', 'ae').replace('&Auml;', 'Ae').replace('&ouml;', 'oe').replace('&ouml;', 'Oe').replace('&uuml;', 'ue')
    text = text.replace('&Uuml;', 'Ue').replace('&szlig;', 'ss').replace('&amp;', '&').replace('&quot;', '"').replace('&gt;', "'")
    text = text.replace('&#228;', 'ae').replace('&#246;', 'oe').replace('&#252;', 'ue').replace('&#223;', 'ss').replace('&#8230;', '...')
    text = text.replace('&#8222;', ',').replace('&#8220;', "'").replace('&#8216;', "'").replace('&#8217;', "'").replace('&#8211;', '-')
    text = text.replace('&#8230;', '...').replace('&#8217;', "'").replace('&#128513;', ':-)').replace('&#8221;', '"')
    text = text.replace('&#038;', '&').replace('&#039;', "'")
    text = text.replace('\\u00c4', 'Ae').replace('\\u00e4;', 'ae').replace('\\u00d6', 'Oe').replace('\\u00f6', 'oe')
    text = text.replace('\\u00dc', 'Ue').replace('\\u00fc', 'ue').replace('\\u00df', 'ss')
    text = text.replace('&#196;', 'Ae').replace('&#228;', 'ae').replace('&#214;', 'Oe').replace('&#246;', 'oe').replace('&#220;', 'Ue').replace('&#252;', 'ue')
    text = text.replace('<br />\n', '')
    return text 
def removeunicode(data):
             
             
            
              try:
                    type(data)
                    data=data.decode('unicode_escape').encode('ascii','replace').replace("?","").strip()
        
              except:
                    pass
              
              return data
              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

        addDir('Search','http://cera.online/?s=',103,'img/0.png','',1)    
        
            
        addDir('••افلام أجنبية••','http://cera.online/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html/',100,'img/1.png','',1)
        addDir('••مسلسلات أجنبية كاملة••','http://cera.online/tv-series-translated-online.html/',120,'img/2.png','',1)
        addDir('••أحدث الحلقات الأسبوعية••','http://cera.online/',100,'img/3.png','',1)
        addDir('••الحلقات الاسبوعية••','http://cera.online/series-download-watch-episodes-aflamhq-egfire-arablionz-translated-myegy.html/',100,'img/4.png','',1)
        addDir('••مسلسلات رمضان 2016••','http://cera.online/mosalsalat-ramadan-2016-watch-shahid-net-mbc-download-dailymotion-online/',300,'img/5.png','',1)
        addDir('••مسلسلات انمي••','http://cera.online/all-full-anime-series.html/',300,'img/6.png','',1)
        addDir('One-Piece','http://cera.online/all-one-piece.html/',100,'img/7.png','',1)
        addDir('Anime-Bleach','http://cera.online/all-anime-bleach-online-translated-online.html',100,'img/8.png','',1)
        addDir('Naruto-Shippuden','http://cera.online/all-naruto-shippuden.html/',100,'img/9.png','',1)
                 
		
              
def years(url):
        for i in range(2002,2016):
             addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                    
def getgenre(url):
        #http://www.vidics.ch/Category-Movies/Genre-comedy/Letter-Any/ByPopularity/1.htm
        genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
        for item in genrelist:
                
      	  addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-Movies'),100,'http://i45.tinypic.com/2d9u26c.jpg',1)
	
def getgenre_series():
        #http://www.vidics.ch/Category-Movies/Genre-comedy/Letter-Any/ByPopularity/1.htm
        genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
        for item in genrelist:
                
      	  addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-TvShows'),200,'http://i45.tinypic.com/2d9u26c.jpg',1)
	
        
                            
                    


def getA_Z(name,mode):
        AZ_DIRECTORIES = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z']
        for character in AZ_DIRECTORIES:
                #http://www.vidics.ch/Category-Movies/Genre-Any/
                addDir(character,"http://www.vidics.ch/"+name+"/Genre-Any/Letter-"+character+"/ByPopularity/1.htm",mode,"")
			
###################################movies
def SearchResult(searchType,Searchtext):
	Searchtext=urllib.quote_plus(Searchtext)
	if searchType=="movie":
			INDEX("http://www.vidics.ch/Category-Movies/Genre-Any/Letter-Any/Relevancy/1/Search-"+urllib.quote_plus(Searchtext)+".htm",4,26,"movie")
	elif searchType=="actor":
			INDEX("http://www.vidics.ch/Category-People/Genre-Any/Letter-Any/Relevancy/1/Search-"+urllib.quote_plus(Searchtext)+".htm",11,12,"")
	else:
			INDEX("http://www.vidics.ch/Category-TvShows/Genre-Any/Letter-Any/Relevancy/1/Search-"+urllib.quote_plus(Searchtext)+".htm",7,27,"tv")
						  
def searchmov(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   Searchtext = keyboard.getText() 
                   
                   
        else:
             print "search error"
            
        
        
         
        
        #url=;http://www.vidics.ch/Category-FilmsAndTV/Genre-Any/Letter-Any/ByPopularity/1/Search-titanic.htm
        url=url+urllib.quote_plus(Searchtext)
        print "url",url
        #sys.exit(0)
        getmovies("Search",url,0)
        #No results

def searchactors():
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search movies')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText()
                   
                   
        
            
        
        
         
       
        url='http://www.vidics.ch/Category-People/Genre-Any/Letter-Any/Relevancy/1/Search-'+urllib.quote_plus(search_entered)+".htm"
        
        getactors("Search",url,0)
def getactors(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # www.vidics.ch/Category-Movies/Genre-Any/Letter-Any/LatestFirst/1.htm
                  url1=os.path.split(urlmain)[0]
                  url_page=url1+"/"+str(page)+".htm"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split('id="searchResults"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="searchResult">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''class="blue" href="(.*?)" title=".*?"><span itemprop="name">(.*?)</span>'''    
                    #regx='''<a title="(.*?)" href="(.*?)">'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    href=baseurl+match[0][0]
                    name=match[0][1]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    
                   
                    regximg='''><img itemprop="image" src="(.*?)"'''
                    img=re.findall(regximg,block, re.M|re.I)[0]

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    
                    try:addDir(name,href,400,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,304,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def getmovies_actor(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # www.vidics.ch/Category-Movies/Genre-Any/Letter-Any/LatestFirst/1.htm
                  url1=os.path.split(urlmain)[0]
                  url_page=url1+"/"+str(page)+".htm"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split('class="filmo_table">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="filmo_film')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a class="green" href="(.*?)" '''    
                    #regx='''<a title="(.*?)" href="(.*?)">'''
                    
                    match=re.findall(regx,block, re.M|re.I)[0]
                    href=baseurl+match
                    regx='''<h4.*?>(.*?)</h4>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    
                   
                    #regximg='''><img itemprop="image" src="(.*?)"'''
                    img=''#e.findall(regximg,block, re.M|re.I)[0]

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    if 'Film' in href:
                            mode=1
                    else:
                            mode=2001
                    try:addDir(name,href,mode,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,400,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))        
def getall_search(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # http://www.vidics.ch/Category-FilmsAndTV/Genre-Any/Letter-Any/ByPopularity/2/Search-titanic.htm
                  parts=os.path.split(urlmain)
                  
                  url_page='http://www.vidics.ch/Category-FilmsAndTV/Genre-Any/Letter-Any/ByPopularity/'+str(page)+"/"+parts[1]
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
                
                data=readnet(url_page)
                data=data.split('<td id="searchResults"')[1]
                
               
                if data is None:
                    return
               
                blocks=data.split('class="searchResult"')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a title="(.*?)" href="(.*?)">'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    href=baseurl+match[0][1]
                    name=match[0][0]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    regxyear='''<span itemprop="copyrightYear">(.*?)</span>'''
                    try:year=re.findall(regxyear,block, re.M|re.I)[0]
                    except:year=''
                    regximg='''<img itemprop="image" src="(.*?)"'''
                    img=re.findall(regximg,block, re.M|re.I)[0]

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:name=str(name)+"("+year+")"
                    except:name=str(name)
                    
                    if "Film" in href:
                            mode=1
                            name='Movie_'+name
                    else:
                            mode=2001
                            name='Serie_'+name
                    try:addDir(name,href,mode,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,1000,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                        
               
                   
def getmovies(name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="moviefilm">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def getanime(name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="moviefilm">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,100,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,300,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def getmovies_search(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # http://cera.online/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html/page/2/
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="moviefilm">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*? src="(.*?)" class="attachment-col wp-post-image" alt=(.*?)".*?/>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regxname='''class="attachment-col wp-post-image" alt="(.*?)"'''
                    name=re.findall(regxname,block, re.M|re.I)[0]
                    
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    regxhref='''<a href="(.*?)">'''
                    href=re.findall(regxhref,block, re.M|re.I)[0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    if 'series' in href:
                            mode=2001
                    else:
                            mode=1
                    
                    try:addDir(name,href,mode,img,'',1)
                    except:pass
                    
                   
               
                   
                if len(blocks)>10:
                   addDir("next page",urlmain,104,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def getmovies2(name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="moviefilm">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,300,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,120,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                    
###############################################tv shows
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getseries("Search",url,0)
                    

               
def getseasons_search(name,urlmain,page):##series
                
                data=readnet(urlmain)

                        
                try:data=data.split('<h2>Search results')[1]
                except:pass
               
              
                if data is None:
                    return
                regx='<a href="(.*?)"  rel="nofollow">(.*?)</a>'
                seasons=getgroups(data,regx,2)
               
                
                seasons=re.findall(regx,data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                                           
                                    
def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://cera.online/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html/page/2/
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split('</center>')[4]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="moviefilm">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*? src="(.*?)" class="attachment-col wp-post-image" alt=(.*?)".*?/>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regxname='''class="attachment-col wp-post-image" alt="(.*?)"'''
                    name=re.findall(regxname,block, re.M|re.I)[0]
                    
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    regxhref='''<a href="(.*?)">'''
                    href=re.findall(regxhref,block, re.M|re.I)[0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    try:addDir(name,href,2001,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))                
def getseries2(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # www.vidics.ch/Category-Movies/Genre-Any/Letter-Any/LatestFirst/1.htm
                  url1=os.path.split(urlmain)[0]
                  url_page=url1+"/"+str(page)+".htm"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split(" <option value='none'")[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<option')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)" title="(.*?)">'''
                    regx='''value='(.*?)'>(.*?)</option>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    href=match[0][0]
                    name=match[0][1]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    year=''
                    img=''

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:name=str(name)+"("+year+")"
                    except:name=str(name)
                    
                    
                    try:addDir(name,href,2001,img,'',1)
                    except:pass
               
                   
                
                
                                                            

def getseasons(name,urlmain,page):##series
                print "page",page
            
                if page>1:
                  # http://cera.online/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html/page/2/
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                print "data",data
                
                if not "<option value='none' selected>=" in data:
                        gethosts(urlmain)
                        return                   
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="moviefilm">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*?src="(.*?)"'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regx='''<div class="movief"><a href="(.*?)">(.*?)</a></div>'''
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    #name=removeunicode(name)
                    try:addDir(name,href,201,img,'',1)
                    except:pass
               
                   
                
               #addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    

               
                   
                
               
                

def getepisodes(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://cera.online/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html/page/2/
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="moviefilm">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*?src="(.*?)"'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regx='''<div class="movief"><a href="(.*?)">(.*?)</a></div>'''
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
               #addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    
                    

               
                   
                
               
               

 


#######################################host resolving                                                    
def creatertmp(host,urlmain):
     #rtmp://streaming.hayyes.com/vod/<playpath>mp4:29/29303/29303_1_400k.mp4 <swfUrl>http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf <pageUrl>http://www.hayyes.com/vod/aflam/7alawet-roo7
     url=host+'  swfUrl=http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf pageUrl='+ urlmain
     return url

def gethosts(urlmain):##cinema and tv featured
                
                data=readnet(urlmain)
                if data is None:
                    return
                #data=data.split('<ul class="serversUl">')
                
                regxid='''<link rel='shortlink' href='(.*?)'/>'''
                id=re.findall(regxid,data, re.M|re.I)[0].split("=")[1]
                i=0
                regx='''<li onClick="(.*?)".*?class=".*?">(.*?)</li>'''
               
                #match=re.findall(regx,data, re.M|re.I)
                print "id",id
             
                i==0
                regx2='''<li onClick=".*?".*?class="(.*?)".*?>(.*?)</li'''
                #regx2='''<li onClick=".*?"   class="(.*?)">Drive</li>'''
                match2=re.findall(regx2,data, re.M|re.I)
                print "match2",match2
                
                for server,name in match2:
                        i=i+1
                        #number=number.replace('server(','').replace(")","").strip()
                        print "server",name
                        serverlink='http://cera.online/wp-content/themes/Theme/servers/server.php?q='+id+'&i='+server.replace('server','')
                                      
                    
                    
                    
                  
                    
                        addDir(name,serverlink,2,'img/server.png','',1)
                #serverlink='http://cera.online/wp-content/themes/Theme/servers/server.php?q='+id+'&i='+str(7)        
                #addDir("server"+ str(7),serverlink,2,'img/server.png','',1)
                #serverlink='http://cera.online/wp-content/themes/Theme/servers/server.php?q='+id+'&i='+str(11)        
                #addDir("server"+ str(11),serverlink,2,'img/server.png','',1)                   
                #if len(match)>0:
                  #addDir("next page",urlmain,200,'','',str(page+1))
                
		
		
                #playlink(link)
def gethosts_movies(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                try:data=data.split("<div class='panel-container'>")[1]
                except:pass
               
                
              
                if data is None:
                    return
                
                blocks=data.split('class="tab-buttons-panel"')
               
                i=0
               
                for block in blocks:
                    i=i+1
                    
                    block=block.lower()
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx2='''<iframe.*?src='(.*?)'.*?></iframe'''
                    #regx3='''<iframe width="600" height="330" scrolling="no" frameborder="0" src="http://videomega.tv/iframe.php?ref=Kjp0m2ECo44oCE2m0pjK&width=600&height=330" allowFullScreen></iframe>'''
                    match=re.findall(regx1,block, re.M|re.I)
                    match2=re.findall(regx2,block, re.M|re.I)
                   
                    
                     
                    print 'match',match
                    for href in match:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)
                    for href in match2:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)                              
def gethosts2(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                
                if data is None:
                    return
                
                
                regx='<a rel="nofollow" href="(.*?)"><input type='
                regx='''<iframe src="(.*?)" scrolling="no"'''
                regx='''<iframe.*?src="(.*?)"'''
                if 'ok.ru' in data:
                        link=data.split('src="')[1].split('"')[0]
                        link="http:"+link 
                else:        
                   regx='<iframe.*?src="(.*?)"'
                   data=data.replace("\n","")
                   #regx='''IFRAME SRC="(.*?)" allowfullscreen FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=850 HEIGHT=520></IFRAME>'''
                   link= re.findall(regx,data.lower(), re.M|re.I)[0]
                print "link",link
                #if "url=" in link:
                        #link=link.split("url=")[1]
                if 'keeload' in link:
                        print link
                        data=readnet(link)
                        regx='''<source src="(.*?)" type='video/mp4'>'''
                        link= re.findall(regx,data, re.M|re.I)[0]
                        playlink(link)
                        return
                if 'ayamov' in link:
                        regx='''window.top.location.href = 'http://ayamov.com/e28oziyjz520/Allied_2016_DvDScr_[cera].mp4';'''
                        link='http://ayamov.com/e28oziyjz520/Allied_2016_DvDScr_[cera].mp4'
                        playlink(link)
                        return
                if 'raptu' in link.lower():
                        regx='''file":"(.*?)"'''
                        data=readnet(link)
                        regx='''"file":"(.*?)","label":"(.*?)"'''
                        from xbmctools import finddata
                        data=finddata(data,'"sources"',']')
                        links= re.findall(regx,data, re.M|re.I)
                        for link,label in links:
                            addDir(label,link,22,'img/server.png','',1)    
                        return
                        
                if 'vidlox' in link:
                        print link
                        data=readnet(link)
                        regx='''<source src="(.*?)" type='video/mp4'>'''
                        regx='''sources:(.*?)'''
                        from xbmctools import finddata
                        data=finddata(data,"sources:",']')
                        links=data.split('","')
                        
                        print "link0",links[0]
                        print "link1",links[1]
                        link0=links[0].replace("[",'').replace('"','').strip()
                        link1=links[1].replace("[",'').replace('"','').strip()
                        addDir("m3u8",link0,22,'img/server.png','',1)
                        addDir("mp4",link1,2,'img/server.png','',1)  
                        
                        return
                
                stream_url=resolve(link)
                playlink(stream_url)
def CheckRedirect(url):
    try:
       from t0mm0.common.net import Net     
       net = Net()
       second_response = net.http_GET(url)
       cj = net.get_cookies()
       return (second_response,cj)
    except:
       
       print "Can't Connect to site",'Try again in a moment'
def GetParts(vicontent,vidname):
      
        titles = []
        urlcontent=re.compile('<div class="movie_link1">(.+?)</div>').findall(vicontent)
        urllist=[]
        for ucontent in urlcontent:
            titletext=re.compile('<h4>(.+?)</h4>').findall(ucontent)[0]
            url=re.compile('<a [^>]*href=["\']?([^>^"^\']+)["\']?[^>]*>').findall(ucontent)[0]
            titles.append(titletext)
            urllist.append(url)
        
        win.setProperty('1ch.playing.episode', str(index))
        return CheckRedirect(urllist[0])
                
def ParseVideoLink(url):

    (respon,cj) = CheckRedirect(url)
    link=respon.content
    tmpcontent=link
    redirlink = respon.get_url().lower()
    link = ''.join(link.splitlines()).replace('\'','"')
    # borrow from 1channel requires you to have 1channel
    
    if(redirlink.find("vidics") >-1):
            (respon,cj) = GetParts(link,name)
            link=respon.content
            tmpcontent=link
            redirlink = respon.get_url().lower()
            link = ''.join(link.splitlines()).replace('\'','"')
    # end 1channel code
    return redirlink	    
def resolve_host(url):#last good-used with local resolver
        turl=ParseVideoLink(url)
        from urlresolver import resolve
   
        stream_link=str(resolve(turl))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(url):
            print "m2",url
	    listItem = xbmcgui.ListItem(path=str(url))
	    xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)

            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==11:
        print ""+url
        gethosts_movies(url)        
elif mode==2:
        print ""+url
        gethosts2(url)
elif mode==21:
        print ""+url
        gethosts2(url)
        
elif mode==22:
        print ""+url
        playlink(url)          
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==120:
        print ""+url
        getmovies2(name,url,page)        
elif mode==1000:
        print ""+url
        getall_search(name,url,page)        
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	name='Category-Movies'
	getA_Z(name,100)
	
elif mode==103:
	print ""+url
        searchmov(url)
        
        
elif mode==5:
	print ""+url	
        genres(url)   	
elif mode==51:
	print ""+url	
        years(url)  	
	
elif mode==104:
	print ""+url
	
	getmovies_search(url)
elif mode==105:
        print ""+url
        getmovies2(name,url,page)
elif mode==200:
	print "mfaraj"+url
	getseries(name,url,page)
	#getvideopage(url,page)
        #getmovies2(name,url,page)
elif mode==205:
	print "mfaraj"+url
	getseries2(name,url,page)
	#getvideopage(url,page)
        #getmovies2(name,url,page)
	
elif mode==2001:
	print "mfaraj"+url
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==201:
	getepisodes(name,url,page)
elif mode==202:

	print ""+url
	name='Category-TvShows'
	getA_Z(name,200)
elif mode==204:

	print ""+url
	name='Category-TvShows'
	getgenre_series()
elif mode==203:
	print ""+url
        search_series(url)
elif mode==303:
     searchactors()
elif mode==304:
     getactors(name,url,page)        
elif mode==400:
     getmovies_actor(name,url,page)
elif mode==300:
     getanime(name,url,page)             
