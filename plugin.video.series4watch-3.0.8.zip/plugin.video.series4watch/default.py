# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import Item,readnet,get_params,getnet,finddata,playlink,getDomain,resolvehost,getsearchtext,resolvehost,finddata,trace_error,removeunicode,downloadImage,playlink
item=Item()
addDir=item.addDir
endDir=item.endDir
################''
baseurl='https://www.series4watch.online'

##########################################parsing tools


def showmenu():
        addDir('Search ','https://www.series4watch.online',103,'img/search.png','',1,searchall=__file__)        
        
        addDir('أخر الاضافات','https://www.series4watch.online/release-year/2018/',100,'img/1.png','',1)
        addDir('افلام اجنبيه','https://www.series4watch.online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/',100,'img/2.png','',1)

        addDir('مسلسلات اجنبيه','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/',200,'img/3.png','',1)

        addDir('افلام عربيه','https://www.series4watch.online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%B9%D8%B1%D8%A8%D9%8A/',100,'img/4.png','',1)

        addDir('مسلسلات عربيه','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A/',200,'img/5.png','',1)
        addDir('مسلسلات رمضان 2018','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2018/',200,'img/6.png','',1)
        addDir('مسلسلات رمضان 2017','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2017-%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A/',200,'img/7.png','',1)
        addDir('مسلسلات رمضات 2016','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2016/',200,'img/8.png','',1)

        addDir('مسلسلات رمضات 2016','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2016/',200,'img/9.png','',1)

        
        addDir('افلام هنديه','https://www.series4watch.online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%87%D9%86%D8%AF%D9%8A/',100,'img/10.png','',1)

        addDir('افلام اسيويه','https://www.series4watch.online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%B3%D9%8A%D9%88%D9%8A%D8%A9/',100,'img/11.png','',1)

        addDir('مسلسلات كوريه','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D9%83%D9%88%D8%B1%D9%8A/',200,'img/12.png','',1)


        addDir('افلام انيمي','https://www.series4watch.online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%86%D9%8A%D9%85%D9%8A/',100,'img/13.png','',1)

        addDir('مسلسلات انيمي','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%86%D9%8A%D9%85%D9%8A/',200,'img/14.png','',1)


        addDir('افلام تركي','https://www.series4watch.online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%AA%D8%B1%D9%83%D9%8A/',100,'img/15.png','',1)

        addDir('مسلسلات تركي','https://www.series4watch.online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%AA%D8%B1%D9%83%D9%8A/',200,'img/16.png','',1)


        #addDir('جميع المسلسلات','https://www.series4watch.online/%D8%AC%D9%85%D9%8A%D8%B9-%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA//',200,'img/17.png','',1)

        addDir('مصارعه','https://www.series4watch.online/category/%D8%B9%D8%B1%D9%88%D8%B6-%D9%85%D8%B5%D8%A7%D8%B1%D8%B9%D8%A9/',100,'img/18.png','',1)








        





def years():###nt active-movies 110,series 210
        list=[]
        for i in range(1950,2019):
             #https://tellymov.com/s/year/2006
             list.append(i)
        list.reverse()     
        for i in list:
                
             addDir(str(i),'https://www.tfarjo.com/films/annee/film-'+str(i)+'-streaming/',100,'','',1)                 
                  
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["1" ,"2", "3" ,"4" ,"5" ,"6" ,"7" ,"9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'https://www.tfarjo.com/films/alphabet/'+letter.lower()+"/",100,'','',1)
###################################movies
			  

        
        
          
 
          
       


def search_103(main_name,sterm,page):##may pastte code of getmovies here
                surl='https://www.series4watch.online/?s='

                if page>1:
                        page_url='https://www.series4watch.online/page/'+str(page)+'/?s='+sterm


                else:
                        page_url=surl+sterm
                print "url_page",page_url
                data=readnet(page_url)           
                

               
                if data is None:
                    return
               
                
                try:
                        sdata=finddata(data,'class="MoviesBlocks"','id="FilterCatsFooter"')
                        if sdata=='':
                                sdata=data
                except:
                        sdata=data
                data=sdata
                
                blocks=data.split('class="MovieBlock"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace('&#8211;',' ')
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0][:-1]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''<div class="TitleBlock">(.*?)</div>''' 
                    regx='''alt="(.*?)"'''    					
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''data-src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''<span class="quality">(.*?)</span>'''
                    try:quality=re.findall(regx,block, re.M|re.I)[0]
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                    
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:

                      addDir(title,href,1,image,main_name,1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>29:
                    
                   addDir("next page",url,103,'img/next.png','',str(page+1))

                
                





               
                   
                
               
                   
                
        
def getmovies_100(main_name,url,page):##movies
               
               
                if page>1:
                    #https://www.series4watch.online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/page/2/
                    page_url=url+'page/'+str(page)
                    
                  
                else:
                
                     page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                

               
                if data is None:
                    return
               
                
                try:
                        sdata=finddata(data,'class="MoviesBlocks"','id="FilterCatsFooter"')
                        if sdata=='':
                                sdata=data
                except:
                        sdata=data
                data=sdata
                
                blocks=data.split('class="MovieBlock"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace('&#8211;',' ')                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0][:-1]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''data-src="(.*?)" '''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''<span class="quality">(.*?)</span>'''
                    try:quality=re.findall(regx,block, re.M|re.I)[0]
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                    title=title.replace('&#038;',' ')
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,main_name,1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>29:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                









###############################################series


def getseries_200(main_name,url,page):##series
                if page>1:
                    #https://www.series4watch.online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/page/2/
                    page_url=url+'page/'+str(page)
                    
                  
                else:
                
                     page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                

               
                if data is None:
                    return
               
                
                try:
                        sdata=finddata(data,'class="MoviesBlocks"','id="FilterCatsFooter"')
                        if sdata=='':
                                sdata=data
                except:
                        sdata=data
                data=sdata
                
                blocks=data.split('class="MovieBlock"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace('&#8211;',' ')                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0][:-1]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''data-src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''<span class="quality">(.*?)</span>'''
                    try:quality=re.findall(regx,block, re.M|re.I)[0]
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                    title=title.replace('&#038;',' ')
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,main_name,1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>29:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))

                
                





                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return
                regx='''<div class="panel-body"> <a href="(.*?)"><span class="glyphicon glyphicon-triangle-right"></span>(.*?)</a>'''
                                                                           
                seasons=re.findall(regx,data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,1,'','',1)
                        

                                           
                                    


def getepisodes_202(main_name,url,page):##series


                data=readnet(url)           
                
                regx='''<a href="(.*?)" class="WatchButton">'''
                href=re.findall(regx,data, re.M|re.I)[0]
                data=readnet(href) 
                if data is None:
                    return
               
                
                try:
                        sdata=finddata(data,'class="MoviesBlocks"','id="FilterCatsFooter"')
                        if sdata=='':
                                sdata=data
                except:
                        sdata=data
                data=sdata
                
                blocks=data.split('class="MovieBlock"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace('&#8211;',' ')                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''data-src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''<span class="quality">(.*?)</span>'''
                    try:quality=re.findall(regx,block, re.M|re.I)[0]
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                    title=title.replace('&#038;',' ')
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,main_name,1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
               

#######################################host resolving                                                    
                    

def getservers_1(name,url,img):
                data=readnet(url)
                regx="rel='shortlink' href='(.*?)'"
                pid=re.findall(regx,data, re.M|re.I)[0].split("=")[1]
                print "pid",pid
                for i in range(1,6):
                   newurl='https://www.series4watch.online/wp-content/themes/New/Interface/Ajax/single/server.php?q='+pid+"&i="+str(i)
                   try:data=readnet(newurl)
                   except:break
                   regx='''src="(.*?)"'''
                   href=re.findall(regx,data, re.M|re.I)[0]
                   server,image,issupported=getDomain(href)
                   if issupported:
                      addDir(server,href,2,img,'',1)

                   

                 
def resolve_host(url):
       
       return

def start():  
        params=get_params()
        print "params",params
        url=None
        name=None
        mode=None
        page=1


        name=params.get("name",None)
        url=params.get("url",None)
        try:mode=int(params.get("mode",None))
        except:mode=None
        image=params.get("image",None)
        section=params.get("section",None)
        page=int(params.get("page",1))
        extra=params.get("extra",None)
        show=params.get("show",None)





        print "Mode1: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "Image: "+str(image)
        print "page: "+str(page)
        print "section: "+str(section)
        print "show: "+str(show)
        print "extra: "+str(extra)
        ##menu and tools
        if mode==None or url==None or len(url)<1:
                print ""
                showmenu()
                ##hosts        
        elif mode==1:
                print ""+url

                getservers_1(name,url,image)
        elif mode==2:
                print ""+url
                resolvehost(item,name,url)        
        elif mode==3:
                print ""+url
                getservers_2(name,url)
        elif mode==11:
                print ""+url
                playlink(item,name,url)

                
        elif mode==103:
                sterm = getsearchtext()      
                 
                search_103("Search",sterm,page)         
                ###movies     

        elif mode==100:
                print ""+url
                getmovies_100(name,url,page)

        elif mode==101:
                print ""+url
                years_101()	

        elif mode==102:
                print ""+url
                getA_Z_102('movies')



        ###series        


        elif mode==200:

                getseries_200(name,url,page)

        elif mode==201:
                getseasons(name,url,page)

        elif mode==202:
                getepisodes_202(name,url,page)



        return endDir()                        
start()
