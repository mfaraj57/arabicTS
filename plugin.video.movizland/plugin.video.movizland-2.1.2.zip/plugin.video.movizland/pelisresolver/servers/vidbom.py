#
import re

def get_video_url(url):
        regx='''file:"(.+?)",label:"(.+?)"'''
       
        import xbmctools
        data=xbmctools.requestsurl(url)
        match = re.findall(regx,data, re.M|re.I)
       
             
        print "match",match
        for href,label in match:
            xbmctools.addDir(label,href,9,"","",1,link=True) 
 
        return match[0][0]