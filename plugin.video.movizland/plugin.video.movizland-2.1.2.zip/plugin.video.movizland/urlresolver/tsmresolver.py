
import os, sys, urllib
from xbmctools import addDir,getDomain,finddata

import os
module_path=os.path.split(os.path.realpath(__file__))[0]
default_mainserver='urlresolver'
forceresolve=True
def isvalidlink(link):
    if link is None:
        return False
    if  link.startswith("http") or  link.startswith("rtmp"):
        return True
    return False
def getmainserver(host):
       
       mainserver=''
       servers=open(module_path+"/servers.txt").readlines()
      
       #if os.name=='nt':
             #plugin_path=module_path.split("scripts")[0]
             #txt=open(plugin_path+"tmp/resolver.txt").read()
             #assigned_mainserver=txt.strip()
             #print 'assigned_mainserver',assigned_mainserver
             
             #if assigned_mainserver=='urlresolver':
                 #classname=getclass(host)
                 #return "urlresolver",host,classname
             #elif assigned_mainserver=='pelisresolver':
                  #return "pelisresolver",host,"get_url"
             #else:
                # pass
       for line in servers:

           
           
           mainserver=None
           
           classname=None

             
           print "host",line
           if host in line:
              
              
              mainserver,hostname,classname,update=line.split(";")
              if host.lower()==hostname.strip().lower():
                 
                
                 return mainserver,host,classname
               
       return None,host,None



    
def logdata(label_name='', data=None):

    if os.name=="nt":
                logfile='TSmedia_log2'
    else:
                logfile='/tmp/TSmedia/TSmedia_log2'        
    try:

        caller_name=getcaller_name()
        fp = open(logfile, 'a')
        fp.write('\n' +caller_name+":"+ str(label_name) + ': ' + str(data))
        fp.close()
    except:
        try:
            data = 'error in writing data to the log'
            fp = open(logfile, 'a')
            fp.write('\n' + label_name + ': ' + str(data))
            fp.close()
        except:
            print 'error in loging data'
def getcaller_name():
    try:
        import inspect,os
        frame=inspect.currentframe()
        frame=frame.f_back.f_back
        code=frame.f_code
        calling_module=os.path.basename(code.co_filename)
        return calling_module
    except:
        return ""
            
def trace_error():
                  import sys,traceback
                  if os.name=="nt":
                                logfile='TSmedia_log'
                  else:
                                logfile='/tmp/TSmedia/TSmedia_log'   
                  
                  traceback.print_exc(file = sys.stdout)
                 
                 
                  traceback.print_exc(file=open(logfile,"a"))   

import urlresolver

def getclass(host):

        hostfile=module_path + "/plugins/" + host + ".py"
        if not os.path.exists(hostfile):
                return None
        lines =open(hostfile).readlines()
        for  line  in lines:
            if line.startswith("class") and "Resolver" in line:
                classname = line.split("(")[0].replace("class", "").strip()
                return classname
                
            
        return None
def get_host_id(host,url):

    import re
    
    hostfile=module_path + "/plugins/" + host + ".py"
    if not os.path.exists(hostfile):
                return None,None
    txt =open(hostfile).read()
    pattern =finddata(txt,"pattern = '","'")
    print "pattern",pattern
                   
    
    #pattern = '(?://|\.)(o(?:pen)??load\.(?:io|co|tv))/(?:embed|f)/([0-9a-zA-Z-_]+)'
    try:
        host,id = re.search(pattern, url).groups()
        
       
        return host,id
    except:
         return None,None
    


def get_linkid(web_url):
    parts = web_url.split('/')
    if parts:
        web_url = web_url.split('/')[len(parts) - 1]
    return web_url


def resolve(web_url = None, host = None, media_id = None, urllist = False,resolver=None):
    if host is None and web_url is not None:
        host = getDomain(web_url)
    else:
        print "No enough data"
        addDir("Error:Error: -err1-no data supplied by the addon",9,"")
        return
    if 'player.vimeo.com' in web_url:
        host="vimeo"
    if 'googledrive' in web_url or 'google' in web_url:
            host= "googlevideo"              
    if 'nowvideo' in web_url:
            web_url=web_url.replace(".sx",".li")
            host= "nowvideo"    
        
    if 'streamin' in web_url:
            host= "streaminto"
    if 'ok.ru' in web_url:
            host= "yasokru"            
            
    if 'vimple' in web_url:
            host= "vimple"
    if 'docs' in web_url:
            host='googlevideo'
    if "uptostream" in web_url:
            host="uptobox"
    if "dailymotion" in web_url:
            host="dailymotion"
    if '9xplay' in web_url:
        host='ninexplay'
    print "host",host
    
    stream_url = None
    done = True
    ###for debug

       
    ######
    try:
        host = host.lower()
    except:
        pass

    
    logdata("web_url",web_url)
    logdata("host",host)
    sys.argv.append(web_url)
    debug = True
   
    mainserver,host,classname=getmainserver(host)
    print " mainserver", mainserver
   

    
    host_module_urlresolver=module_path + "/plugins/" + host + ".py"
    host_module_pelisresolver=module_path + "/servers" + host + ".py"
    if mainserver is None and forceresolve==True:
       if os.path.exists(host_module_urlresolver) and default_mainserver=='urlresolver':
          mainserver='urlresolver'
          classname=getclass(host)
       elif os.path.exists(host_module_pelisresolver) and default_mainserver=='pelisresolver': 
            mainserver='urlresolver'
            classname='get-URL'
       elif default_mainserver=='auto':
            if os.path.exists(host_module_urlresolver):
                      mainserver='urlresolver'
                      classname=getclass(host)
            elif os.path.exists(host_module_pelisresolver) : 
                     mainserver='urlresolver'
                     classname='get-URL'
       if classname is None or mainserver is None:
            print "No resolving module for given host"
            addDir("Error:Error: -err2-No resolving module for given host",9,"")
            return           
    elif forceresolve==False:
            print "Host is not supported"
            addDir("Error:Error: -err3-Host is not supported,forceresolve disbaled",9,"")
            return      
    else:
        pass
    print 'mainserver,host,classname',mainserver,host,classname       
    if mainserver=='urlresolver':                             
                        
                        
                        txt='from plugins.'+host.strip()+" import " +classname.strip()+' as Resolver'
                        print "import text",txt
                        exec(txt)                 
                       
                        resolver = Resolver()
                        host,media_id=get_host_id(host,web_url)
                        print 'host,media_id',host,media_id
                        stream_url = resolver.get_media_url(host, media_id)

    if mainserver=='pelisresolver':
         
            import pelisresolver      
            exec('from pelisresolver.servers.'+host.strip()+" import get_video_url")
            print 'imprt statment','from pelisresolver.servers.'+host.strip()+" import get_video_url"
            try:stream_url = get_video_url(web_url)
            except:stream_link="Error:"
            if stream_url and type(stream_url)==type([]):
                stream_url=stream_url[0][1]
           
            if stream_url is None or not stream_url.startswith("http"):   
             if 'openload' in host :
                mainserver='urlresolver'
                classname=getclass(host)

                txt='from plugins.'+host.strip()+" import " +classname.strip()+' as Resolver'
                print "import text",txt
                exec(txt)                 
               
                resolver = Resolver()
                host,media_id=get_host_id(host,web_url)
                print 'host,media_id',host,media_id
                try:
                  stream_url = resolver.get_media_url(host, media_id)
                except Exception, e:
                    print "error",e
                    if "formatting" in str(e):
                        print "error2",e
                        addDir("Error:do pairing on olpair.com in your pc browser and try again","Message:do pairing on olpair.com in your pc browser and try again",1,"","",1)
                        return "Error:do pairing on olpair.com in your pc browser and try again"
                    else:
                        return "Error:invalid1 stream link"
                  
   
       
    print "stream_url",stream_url                   
    if  type(stream_url)==type([]):
        stream_url=stream_url[0][1]
        
    
    if  isvalidlink(stream_url)==False:
                   stream_url = 'Error:Invalid stream link'         
    if '|' in stream_url:
        stream_url=stream_url.split("|")[0]
    if os.name=='nt':
        if stream_url and isvalidlink(stream_url):
           saveasexample(web_url,mainserver,success=True)
        else:
           saveasexample(web_url,mainserver,success=False) 
    return stream_url                 

def saveasexample(web_url,servername,success=True):
                     
               if True:
                           try:lines=open(module_path+"/examples").readlines()
                           except:lines=[]
                           exists=False
                           for line in lines:
                               parts=line.split(";")
                               if web_url==parts[0] and servername==parts[1]:
                                  exists=True
                                  break
                           if exists==False:
                               afile=open(module_path+"/examples","a")
                               afile.write("\n"+web_url+";"+servername+";"+str(success))
                               afile.close()
               else:
                           pass      
