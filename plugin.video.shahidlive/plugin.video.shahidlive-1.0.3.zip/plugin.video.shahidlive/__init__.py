# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSTube/resources/tube_resolver/__init__.py
pass