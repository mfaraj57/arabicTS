# -*- coding: utf8 -*-


import urllib,urllib2,re,os,sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re



############################################

####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools


def showmenu():
        
	
        addDir('••Search••','http://shahidlive.com/Cat-46',103,'img/search.png','',1)	
	addDir('••أفـــلام أجنبية••','http://shahidlive.co/Cat-46',100,'img/1.png','',1)
	addDir('••أفــلام عربية••','http://shahidlive.com/Cat-100',100,'img/2.png','',1)
        addDir('••افلام تركيه••','http://shahidlive.com/Cat-48',100,'img/3.png','',1)
	addDir('••بوليود••','http://shahidlive.com/Cat-132',100,'img/4.png','',1)
	
        addDir('••افلام فلسطينيه••','http://shahidlive.com/Cat-18',100,'img/6.png','',1)
        addDir('••افلام وثائقيه••','http://shahidlive.com/Cat-23',100,'img/7.png','',1)
        addDir('••افلام قديمه••','http://shahidlive.com/Cat-51',100,'img/8.png','',1)
        addDir('••افلام اطفال••','http://shahidlive.com/Cat-57',100,'img/9.png','',1)
       
        addDir('••مسلسلات 2017••','http://shahidlive.co/Cat-135-1',200,'img/10.png','',1)
        addDir('••مسلسلات رمضان 2016••','http://shahidlive.com/Cat-134',200,'img/11.png','',1)
        addDir('••مسلسلات عربيه••','http://shahidlive.com/Cat-98',200,'img/13.png','',1)
        addDir('••مسلسلات مصريه••','http://shahidlive.com/Cat-26',200,'img/10.png','',1)
        addDir('••مسلسلات سوريه••','http://shahidlive.com/Cat-25',200,'img/14.png','',1)
        addDir('••مسلسلات لبنانيه••','http://shahidlive.com/Cat-28',200,'img/14.png','',1)
        addDir('••مسلسلات اردنيه••','http://shahidlive.com/Cat-30',200,'img/15.png','',1)
        addDir('••مسلسلات خليجيه••','http://shahidlive.com/Cat-111',200,'img/16.png','',1)



        addDir('••مسلسلات تركيه••','http://shahidlive.com/Cat-27',200,'img/17.png','',1)
        addDir('••مسلسلات تركيه مدبلجه••','http://shahidlive.com/Cat-129',200,'img/18.png','',1)
        addDir('••مسلسلات تركيه مترجمه••','http://shahidlive.com/Cat-128',200,'img/19.png','',1)
        addDir('••مسلسلات هنديه••','http://shahidlive.com/Cat-130',200,'img/20.png','',1)
        addDir('••مسلسلات اجنبيه••','http://shahidlive.com/Cat-93',200,'img/21.png','',1)
        addDir('••مسلسلات كرتون••','http://shahidlive.com/Cat-56',200,'img/22.png','',1)
        addDir('••كليبات••','http://shahidlive.com/Album-380',100,'img/23.png','',1)
        addDir('••حفلات••','http://shahidlive.com/Cat-121',100,'img/24.png','',1) 

def years(url):
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
                    
def genres(urlmain):

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):
		abc = ['#','0','1','2','3','4','5','6','7','8','9',"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://projectfreetv.so/watch-tv-series/#mctm-'+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= 'http://shahidlive.com/Search/'+search_entered
        #http://shahidlive.com/Search/%D9%88%D9%86%D9%88%D8%B3
          
        getmovies("Search",url,0)


                        
               
                   
                
        
def getmovies(namemain,urlmain,page):##movies
                print "page",page
               
                if not namemain=='Search':
                   url_page=urlmain+'-'+str(page)
                else:
                    url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class=" subcats">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('col-xxs-6')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)">'''
                    href=re.findall(regx,block,re.M|re.I)[0]
                    href='http://shahidlive.com'+href
                    regx='''<div class="title"><h4>(.*?)</h4></div>'''
                    name=re.findall(regx,block,re.M|re.I)[0]                   
                    regx='''<img src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]                  
                    try:img=img.encode("utf-8")
                    except:img=str(img)
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,1,img,'',1)
                    
               
                   
                
                
                addDir("next page",urlmain,100,'img/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
###############################################tv shows
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getseries("Search",url,0)
def getseries(name,urlmain,page):##series
                print "page",page
               

                url_page=urlmain+'-'+str(page)      
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class=" subcats">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('col-xxs-6')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)">'''
                    href=re.findall(regx,block,re.M|re.I)[0]
                    href='http://shahidlive.com'+href
                    regx='''<div class="title"><h4>(.*?)</h4></div>'''
                    name=re.findall(regx,block,re.M|re.I)[0]                   
                    regx='''<img src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]                  
                    try:img=img.encode("utf-8")
                    except:img=str(img)
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,202,img,'',1)
                    
               
                   
                
                
                addDir("next page",urlmain,200,'img/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                                        
                    
def getseasons(name,urlmain,page):##series

                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,urlmain,page):##series

                print "page",page
               

                url_page=urlmain+'-'+str(page)      
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class=" subcats">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('col-xxs-6')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)">'''
                    href=re.findall(regx,block,re.M|re.I)[0]
                    href='http://shahidlive.com'+href
                    regx='''<div class="title"><h4>(.*?)</h4></div>'''
                    name=re.findall(regx,block,re.M|re.I)[0]                   
                    regx='''<img src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]                  
                    try:img=img.encode("utf-8")
                    except:img=str(img)
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,1,img,'',1)
                    
               
                   
                
                
                addDir("next page",urlmain,202,'img/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

 


#######################################host resolving                                                    




def gethosts(name,urlmain):##cinema and tv featured
                url = 'http://shahidlive.com/Play/'+urlmain.split('vid_')[1]+'-681-382'
                print "url",url
                #sys.exit(0)
              
                
                data=readnet(url)
                if 'youtube' in data:
                    regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx='src="http://www.youtube.com/embed/(.*?)"'
                    videoid=re.findall(regx,data, re.M|re.I)[0]
                    stream_link = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                    from tube_resolver import getvideo
                    stream_link=getvideo(stream_link)
                    playlink(stream_link)
                    return
                regx='''<iframe src="(.*?)".*?></iframe>'''
                link=re.findall(regx,data, re.M|re.I)[0]
                data=data=readnet(link)
                regx='''<source src="(.*?)".*?type='.*?'>'''
                if 'rtmp' in data:
                    rtmpdata=re.findall(regx,data, re.M|re.I)[0]
                else:
                    http=re.findall(regx,data, re.M|re.I)[0]
                    playlink(http)
                    return
                    
                print "rtmp",rtmpdata
                
                rtmp=rtmpdata.split('/vod&')[0]+'/vod'
                playpath=rtmpdata.split('/vod&')[1]
                swfUrl='http://vjs.zencdn.net/swf/5.0.1/video-js.swf'
                pageUrl=link
                stream_url=rtmp+ ' playpath='+playpath+' swfUrl='+swfUrl+' pageUrl='+pageUrl
                playlink(stream_url)
                ##rtmp://62.90.177.112:80/<playpath>mp4:12/01/120129.mp4 <swfUrl>http://vjs.zencdn.net/swf/5.0.1/video-js.swf <pageUrl>http://nadstream.shahidlive.com/?ID=120129&server=112&width=681&height=382
    #link_file= link_file[1]
                               
                    
                     
                    
                    
                                          

	    
def resolve_host(url):#last good-used with local resolver
       
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"") 	    

def playlink(url):
            print "url",url
            if '"' in url:
                url=url.split('"')[0]
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param


	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
