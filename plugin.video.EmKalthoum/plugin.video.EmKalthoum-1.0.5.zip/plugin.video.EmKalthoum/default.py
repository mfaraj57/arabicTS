#!/usr/bin/python
# -*- coding: utf-8 -*-
try:import sys,syspath
except:pass
from yttools import *


def infolist():
  list1=[]
 
  list1.append((' Official OmKalthoum','UC3sKOTz5mWAdQyLQBp-Weaw'))
  list1.append(('Omkalthoum','UCUz6CXO5XIYD_7wmlK8mZsA'))
  list1.append(('Omkalthoum series','UC9jQxEQNbYEHR4QgAl0ilPA'))
  list1.append(('محمد غبد الوهاب','UCY0JzWvCYtvw-mtp9Y9HBZg'))
  
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))


