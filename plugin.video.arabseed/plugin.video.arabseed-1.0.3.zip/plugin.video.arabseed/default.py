# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
from xbmctools import addDir,readnet,supported,get_params,readtrueurl,getDomain,parsedata,requestsurl,resolvehost,getData,postData
################''
baseurl='http://arabseed.tv'
#import arabseed
##########################################parsing tools



        

def showmenu():
        
        
        addDir('search',baseurl+"/?s=",103,'img/0.png',1)
        addDir('••أفـــلام أجنبية••',baseurl+'/cat_film/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a/',100,'img/1.png','',1)
        addDir('••أفلام عربية••',baseurl+'/cat_film/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%b9%d8%b1%d8%a8%d9%8a/',100,'img/2.png','',1)

        addDir('••أفلام هندية••',baseurl+'/cat_film/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%87%D9%86%D8%AF%D9%8A/',100,'img/4.png','',1)
        addDir('••أنمــــي••',baseurl+'/cat_film/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%86%d9%8a%d9%85%d9%8a%d8%b4%d9%86/',100,'img/5.png','',1)


        return
         

def years(url):
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
                    
def genres(urlmain):

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','-')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getmovies("Search",url,0)


def search_results(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                    
                        #http://arabseed.tv/cat_film/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/page/2/
                        url_page=urlmain+"page/"+str(page)
                  
                else:
                
                       url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="main_title"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="sub_data"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                   
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    href=re.findall(regx,block, re.M|re.I)[0]                    
                    #name,image
                    regx='''src="(.*?)"'''                    
                    image=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''<h1>(.*?)</h1>'''                    
                    try:title=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    regx='''<div class="quality">(.*?)</div>'''                    
                    try:quality=re.findall(regx,block, re.M|re.I)[0]
                    except:quality=''
                    regx='''<div class="year col-md-6">(.*?)</div>'''                    
                    try:year=re.findall(regx,block, re.M|re.I)[0]
                    except:year=''
                    
                                     
                    extra="("+year+ " "+quality+")"
                    
                    
                                                
                               
                    title=title+extra
                    try:title=title.encode("utf-8")
                    except:title=str(title)
                    
                    try:href=href.encode("utf-8")
                    except:href=str(href)
                    
                    try:addDir(title,href,1,image,'',1)
                    except:pass
               
               
                if len(blocks)>15:
                    
                   addDir("next page",urlmain,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))


               
                   
                
               
                   
                
        
def getmovies(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                    
                        #http://arabseed.tv/cat_film/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/page/2/
                        url_page=urlmain+"page/"+str(page)
                  
                else:
                
                       url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                #try:data=data.split('class="main_title"')[1]
                #except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="wrap">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    href=re.findall(regx,block, re.M|re.I)[0]                    
                    #name,image
                    regx='''src="(.*?)"'''                    
                    image=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''<h3>(.*?)</h3>'''                    
                    try:title=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    regx='''<div class="quality">(.*?)</div>'''                    
                    try:quality=re.findall(regx,block, re.M|re.I)[0]
                    except:quality=''
                    regx='''<div class="year col-md-6">(.*?)</div>'''                    
                    try:year=re.findall(regx,block, re.M|re.I)[0]
                    except:year=''
                    
                                     
                    extra="("+year+ " "+quality+")"
                    
                    
                                                
                               
                    title=title+extra
                    try:title=title.encode("utf-8")
                    except:title=str(title)
                    
                    try:href=href.encode("utf-8")
                    except:href=str(href)
                    
                    try:addDir(title,href,1,image,'',1)
                    except:pass
               
               
                if len(blocks)>15:
                    
                   addDir("next page",urlmain,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))











def getcollection(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                    
                        #http://www.movs4u.com/movie/page/2/
                        url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                       url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('id="archive-content"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="poster"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''<a href="(.*?)">.*?</a>'''                    
                    href=re.findall(regx,block, re.M|re.I)[0]                    
                    #name,image
                    regx='''<img src="(.*?)" alt="(.*?)">'''                    
                    match=re.findall(regx,block, re.M|re.I)[0]
                    image=match[0]
                    name=match[1]
                    
                    
                    #extra
                    regx='''<span class="imdb">IMDb:(.*?)</span>'''
                    try:rating=re.findall(regx,block, re.M|re.I)[0]
                    except:rating=''
                    regx='''<span class="quality">(.*?)</span>'''
                    try:qual=re.findall(regx,block, re.M|re.I)[0].replace("-","").strip()
                    except:qual=''

                    print "qual",qual
                                     
                    extra=qual+"_"+rating
                    
                                                
                               
                    name=name+"("+qual+"-"+rating+")"
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    try:href=href.encode("utf-8")
                    except:href=str(href)
                    print "name",name,href,image
                    addDir(name,href,100,image,'',1)
                    #except:pass
               
                   
                
                if len(blocks)>50:
                    
                   addDir("next page",urlmain,400,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                    
###############################################series


def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                    
                        #http://arabseed.tv/cat_film/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/page/2/
                        url_page=urlmain+"page/"+str(page)
                  
                else:
                
                       url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="main_title"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="sub_data"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    href=re.findall(regx,block, re.M|re.I)[0]                    
                    #name,image
                    regx='''src="(.*?)"'''                    
                    image=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''<h1>(.*?)</h1>'''                    
                    try:title=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    regx='''<div class="quality">(.*?)</div>'''                    
                    try:quality=re.findall(regx,block, re.M|re.I)[0]
                    except:quality=''
                    regx='''<div class="year col-md-6">(.*?)</div>'''                    
                    try:year=re.findall(regx,block, re.M|re.I)[0]
                    except:year=''
                    
                                     
                    extra="("+year+ " "+quality+")"
                    
                    
                                                
                               
                    title=title+extra
                    try:title=title.encode("utf-8")
                    except:title=str(title)
                    
                    try:href=href.encode("utf-8")
                    except:href=str(href)
                    
                    try:addDir(title,href,201,image,'',1)
                    except:pass
               
               
                if len(blocks)>15:
                    
                   addDir("next page",urlmain,200,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))




                    
def getseasons(name,urlmain,page):##series

                 
                data=requestsurl(urlmain)
                regx='''<link rel='shortlink' href='(.*?)' />'''
                id=re.findall(regx,data, re.M|re.I)[0].split("=")[1]
                print "id",id
               
                url=baseurl+'/wp-content/themes/asd-takweed/functions/inc/single/series/season.php'
                data={'id':id}
                host='arabseed.tv'
                Referer=urlmain
                data=getPage(url,data,host,Referer)
                regx='''<a href="(.*?)">'''
                
                match=re.findall(regx,data, re.M|re.I)
                for href in match:
                        name=os.path.split(href[:-1])[1]
                        addDir(name,href,202,'','',1)

                                           
                                    


def getepisodes(name,urlmain,page):##series

                data=requestsurl(urlmain)
                regx='''<link rel='shortlink' href='(.*?)' />'''
                id=re.findall(regx,data, re.M|re.I)[0].split("=")[1]
                print "id",id
               
                url=baseurl+'/wp-content/themes/asd-takweed/functions/inc/single/season/episode.php'
                data={'id':id}
                host='arabseed.tv'
                Referer=urlmain
                data=getPage(url,data,host,Referer)
                regx='''<a href="(.*?)">'''
                print "data",data
                sys.exit(0)
                match=re.findall(regx,data, re.M|re.I)
                for href in match:
                        name=os.path.split(href[:-1])[1]
                        addDir(name,href,1,'','',id)



#######################################host resolving                                                    


def getservers(title,mainurl,page=1):
                #baseurl+'/wp-content/themes/asd-takweed/functions/inc/single/movies/server.php&id=7383
                if not page==1:
                        movie_id=str(page)
                        url=baseurl+'/wp-content/themes/asd-takweed/functions/inc/single/episode/server.php'
                else:   
                        data=requestsurl(mainurl)
                        movie_id      = re.search('single-movies postid-(.*)"', data)
                        movie_id     = str(movie_id.group(1))
                        print "movie_id",movie_id
                
                        url=baseurl+'/wp-content/themes/asd-takweed/functions/inc/single/movies/server.php'
                data={'id':movie_id}
                host='arabseed.tv'
                Referer=mainurl
                data=postData(url,data,host,Referer)
                print "data",data
                regx='<div class=".*?" data-type="(.*?)" data-id="(.*?)" data-key="(.*?)">'
                match=re.findall(regx,data, re.M|re.I)
                for type,id,key in match:
                    url=baseurl+'/wp-content/themes/asd-takweed/functions/inc/single/server/film.php'
                    data={'id':id,'key':key,'type':type}
                    data=postData(url,data,host,Referer)
                    
                    regx='<iframe.*?src="(.*?)".*?</iframe>'
                    match=re.findall(regx,data, re.M|re.I)
                    for href in match:
                            server=getDomain(href)
                            addDir(server,href,2,'img/server.png','',1)
                           


                return


                 

    
  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        
        getservers(name,url,page)
elif mode==2:
        print ""+url
        resolvehost(url)        
elif mode==3:
        print ""+url
        playlink(url)
     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==400:
        print ""+url
        getcollection(name,url,page)
elif mode==110:
        print ""+url        
        gethd(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)    
elif mode==104:
	print ""+url
        search_tvshows(url)           


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
