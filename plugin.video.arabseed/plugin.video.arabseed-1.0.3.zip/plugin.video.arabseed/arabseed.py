import requests
import re
#Example Link For ArabSeed Host####################################################
#Parse Your Movies Sections After that Call directly the Movie Main Page Exp :
s = requests.Session()
r = s.get('http://arabseed.tv/movies/the-lego-ninjago-movie/') #Exp Movie : american-made
htmldata = r.content
movie_id      = re.search('single-movies postid-(.*)"', htmldata)
movie_id     = str(movie_id.group(1))
#Movie ID is a unique identifier for each movie wee call it later in The Post URL Request
print ('Movie ID:'+movie_id)
headers = {
    'Host': 'arabseed.tv',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
    'Accept': '*/*',
    'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'http://arabseed.tv/movies',
    'Connection': 'keep-alive'}

#data-type="normal" data-id="10234" data-key="0">
payload = {
'id':'10234',
'key':'0',
'type':'normal',
}
#id='+9299+'
#payload = {'id':'+9299+'}
r=s.post('http://arabseed.tv/wp-content/themes/asd-takweed/functions/inc/single/server/film.php', headers=headers, data=payload)
htmldata = r.content
#You got Your End Target Page With Servers Download/Watch URLs Ready To Parse !
print htmldata
