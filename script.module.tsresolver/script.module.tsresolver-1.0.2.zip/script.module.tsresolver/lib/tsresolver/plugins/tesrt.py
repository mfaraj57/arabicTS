data='''<?xml version='1.0' encoding='UTF-8'?><feed xmlns='http://www.w3.org/2005/Atom'
xmlns:openSearch='http://a9.com/-/spec/opensearchrss/1.0/' xmlns:yt='http://gdat
a.youtube.com/schemas/2007' xmlns:gd='http://schemas.google.com/g/2005' xmlns:me
dia='http://search.yahoo.com/mrss/'><id>http://gdata.youtube.com/feeds/api/users
/tvjKHnvzDDpCi0zKhaXwhA/playlists</id><updated>2015-05-14T05:59:28.971Z</updated
><category scheme='http://schemas.google.com/g/2005#kind' term='http://gdata.you
tube.com/schemas/2007#playlistLink'/><title type='text'>Playlists of user</title
><logo>http://www.gstatic.com/youtube/img/logo.png</logo><link rel='related' typ
e='application/atom+xml' href='https://gdata.youtube.com/feeds/api/users/tvjKHnv
zDDpCi0zKhaXwhA'/><link rel='alternate' type='text/html' href='https://www.youtu
be.com'/><link rel='hub' href='http://pubsubhubbub.appspot.com'/><link rel='http
://schemas.google.com/g/2005#feed' type='application/atom+xml' href='https://gda
ta.youtube.com/feeds/api/users/tvjKHnvzDDpCi0zKhaXwhA/playlists'/><link rel='htt
p://schemas.google.com/g/2005#batch' type='application/atom+xml' href='https://g
data.youtube.com/feeds/api/users/tvjKHnvzDDpCi0zKhaXwhA/playlists/batch'/><link
rel='self' type='application/atom+xml' href='https://gdata.youtube.com/feeds/api
/users/tvjKHnvzDDpCi0zKhaXwhA/playlists?start-index=1&amp;max-results=25'/><auth
or><name>M Faraj</name><uri>https://gdata.youtube.com/feeds/api/users/tvjKHnvzDD
pCi0zKhaXwhA</uri></author><generator version='2.1' uri='http://gdata.youtube.co
m'>YouTube data API</generator><openSearch:totalResults>1</openSearch:totalResul
ts><openSearch:startIndex>1</openSearch:startIndex><openSearch:itemsPerPage>25</
openSearch:itemsPerPage><entry><id>http://gdata.youtube.com/feeds/api/users/tvjK
HnvzDDpCi0zKhaXwhA/playlists/PLb-P_GNQh8GkSjCuggy2tMmQkXbVcS2-r</id><published>2
014-04-19T07:29:47.000Z</published><updated>2015-05-13T06:53:40.000Z</updated><c
ategory scheme='http://schemas.google.com/g/2005#kind' term='http://gdata.youtub
e.com/schemas/2007#playlistLink'/><title type='text'>mfaraj</title><content type
='text'/><link rel='related' type='application/atom+xml' href='https://gdata.you
tube.com/feeds/api/users/tvjKHnvzDDpCi0zKhaXwhA'/><link rel='alternate' type='te
xt/html' href='https://www.youtube.com/playlist?list=PLb-P_GNQh8GkSjCuggy2tMmQkX
bVcS2-r'/><link rel='self' type='application/atom+xml' href='https://gdata.youtu
be.com/feeds/api/users/tvjKHnvzDDpCi0zKhaXwhA/playlists/PLb-P_GNQh8GkSjCuggy2tMm
QkXbVcS2-r'/><link rel='edit' type='application/atom+xml' href='https://gdata.yo
utube.com/feeds/api/users/tvjKHnvzDDpCi0zKhaXwhA/playlists/PLb-P_GNQh8GkSjCuggy2
tMmQkXbVcS2-r'/><author><name>M Faraj</name><uri>https://gdata.youtube.com/feeds
/api/users/tvjKHnvzDDpCi0zKhaXwhA</uri></author><yt:description/><gd:feedLink re
l='http://gdata.youtube.com/schemas/2007#playlist' href='https://gdata.youtube.c
om/feeds/api/playlists/PLb-P_GNQh8GkSjCuggy2tMmQkXbVcS2-r' countHint='4'/><media
:group><media:thumbnail url='https://i.ytimg.com/vi/ZRuSS0iiFyo/default.jpg' hei
ght='90' width='120' yt:name='default'/><media:thumbnail url='https://i.ytimg.co
m/vi/ZRuSS0iiFyo/mqdefault.jpg' height='180' width='320' yt:name='mqdefault'/><m
edia:thumbnail url='https://i.ytimg.com/vi/ZRuSS0iiFyo/hqdefault.jpg' height='36
0' width='480' yt:name='hqdefault'/><yt:duration seconds='0'/></media:group><yt:
playlistId>PLb-P_GNQh8GkSjCuggy2tMmQkXbVcS2-r</yt:playlistId><yt:private/></entr
y></feed>'''
data=data.replace('\n','')
print data
