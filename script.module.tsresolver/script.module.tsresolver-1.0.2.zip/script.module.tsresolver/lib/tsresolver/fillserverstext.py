import os,re
servers_path=os.path.split(os.path.realpath(__file__))[0]+"/plugins"
servers_txt=os.path.split(os.path.realpath(__file__))[0]+"/servers.txt"

def listdirs(mypath):
    return [f for f in os.listdir(mypath) if os.path.isfile(os.path.join(mypath, f))]
def finddata(data, marker1, marker2, withMarkers=False, caseSensitive=True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1: return ''
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2: return ''
        
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)

        return data[idx1:idx2]         

servers=listdirs(servers_path)
afile=open(servers_txt,"w")
for server in servers:
    lines=open(servers_path+"/"+server).readlines()
    for line in lines:
        if line.startswith('class') and 'Resolver' in line:
            
            classname=line.split('(')[0].replace('class','').strip()
    
            nline='tsresolver'+';'+server.replace(".py","")+';'+server.replace(".py","")+';'+classname
            afile.write(nline+"\n")
afile.close()            
            
