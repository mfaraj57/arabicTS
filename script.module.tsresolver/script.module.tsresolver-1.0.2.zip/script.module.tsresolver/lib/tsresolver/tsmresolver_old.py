
import os, sys, urllib
from xbmctools import addDir

import os
module_path=os.path.split(os.path.realpath(__file__))[0]
#from xbmctools import logdata
  
def logdata(label_name='', data=None):

    if os.name=="nt":
                logfile='TSmedia_log2'
    else:
                logfile='/tmp/TSmedia/TSmedia_log2'        
    try:

        caller_name=getcaller_name()
        fp = open(logfile, 'a')
        fp.write('\n' +caller_name+":"+ str(label_name) + ': ' + str(data))
        fp.close()
    except:
        try:
            data = 'error in writing data to the log'
            fp = open(logfile, 'a')
            fp.write('\n' + label_name + ': ' + str(data))
            fp.close()
        except:
            print 'error in loging data'
def getcaller_name():
    try:
        import inspect,os
        frame=inspect.currentframe()
        frame=frame.f_back.f_back
        code=frame.f_code
        calling_module=os.path.basename(code.co_filename)
        return calling_module
    except:
        return ""
            
def trace_error():
                  import sys,traceback
                  if os.name=="nt":
                                logfile='TSmedia_log'
                  else:
                                logfile='/tmp/TSmedia/TSmedia_log'   
                  
                  traceback.print_exc(file = sys.stdout)
                 
                 
                  traceback.print_exc(file=open(logfile,"a"))   

import tsresolver
#from plugins.openload import OpenloadResolver as Resolver
def getclass(host):

        hostfile=module_path + "/plugins/" + host + ".py"
        if not os.path.exists(hostfile):
                return None
        lines =open(hostfile).readlines()
        for  line  in lines:
            if line.startswith("class") and "Resolver" in line:
                classname = line.split("(")[0].replace("class", "").strip()
                return classname
                
            
        return None
def get_host_id(host,url):
    hostname=host
    import re
    from xbmctools import finddata
    hostfile=module_path + "/plugins/" + host + ".py"
    print "hostfile",hostfile
    
    if not os.path.exists(hostfile):
                print "hostfile not exists"
                return None,None
    txt =open(hostfile).read()
    pattern =finddata(txt,"pattern = '","'")
    print "pattern",pattern
                   
    
    #pattern = '(?://|\.)(o(?:pen)??load\.(?:io|co|tv))/(?:embed|f)/([0-9a-zA-Z-_]+)'
    try:
        host,id = re.search(pattern, url).groups()
        print 'host,id',host,id
        
        if host is None:
            host=hostname
        
        return host,id
    except:
         return None,None
    
def gethostname(url):
    try:

        return url.split('/')[2].replace('www.', '').replace('embed.', '').split('.')[0]
    except:
        return url


def get_linkid(web_url):
    parts = web_url.split('/')
    if parts:
        web_url = web_url.split('/')[len(parts) - 1]
    return web_url


def resolve(web_url = None, host = None, media_id = None, urllist = False,resolver=None):
    if host and  "." in host:
        host=host.split(".")[1]
    if host is None and web_url is not None:
        host = gethostname(web_url)

    if 'googledrive' in web_url or 'google' in web_url:
            host= "googlevideo"              
    if 'nowvideo' in web_url:
            web_url=web_url.replace(".sx",".li")
            host= "nowvideo"    
        
    if 'streamin' in web_url:
            host= "streaminto"
    if 'ok.ru' in web_url:
            host= "ok"            
            
    if 'vimple' in web_url:
            host= "vimple"
    if 'docs' in web_url:
            host='googlevideo'
    if "uptostream" in web_url:
            host="uptobox"
    if "dailymotion" in web_url:
            host="dailymotion"

            
    stream_url = None
    done = True
    
    if resolver is None and os.name=='nt':
         plugin_path=module_path.split("TSmediaTools")[0]+"TSmediaTools"
         txt=open(plugin_path+"/tmp/resolver.txt").read()
         resolver=txt.strip()
       
   
    try:
        host = host.lower()
    except:
        pass
  
    
    logdata("web_url",web_url)
    logdata("host",host)
    sys.argv.append(web_url)
    debug = True
    if web_url is not None and media_id is None:
        media_id = get_linkid(web_url)
        if '.' in media_id:
            media_id = media_id.split('.')[0]
         
    if True:
       servername=''
       servers=open(module_path+"/servers.txt").readlines()
       
       
       for line in servers:

           
           servername='None'
           hostname='None'
           classname='None'
           if host in line:
              servername,hostname,classname,update=line.split(";")
              if host.lower()==hostname.strip().lower():
                 break
              classname='None'  
       
       logdata("resolver",resolver)
       if resolver=='auto':
           resolver=None
       if resolver is not None :
           servername=resolver
           hostname=host
           print " servername", servername
           #sys.exit(0)
           if servername=='tsresolver':
              if classname=='None':
                      
                 classname=getclass(hostname)
                 
              if classname is None:
                      
                 stream_url = 'Error: -err1-unresolvable:unable to resolve link-no supported host'
             
           else:
              classname='pelisresolver'
       print 'main********servername,hostname,classname',host,servername,hostname,classname        
       if servername=='pelisresolver':
          hostexists=False
          try:
            import pelisresolver      
            exec('from pelisresolver.servers.'+hostname.strip()+" import get_video_url")
            hostexists=True
          except:
                  trace_error()
                  stream_url = 'Error: -err2-import error, unresolvable:unable to resolve link-no supported host'
          if hostexists==True:         
                  host=hostname
                  stream_url = get_video_url(web_url)
                  print "stream_url",stream_url
                  try:
                      if type(stream_url) == type([]) :
                         #3for item in stream_url:
                                #try:addDir(item[0],item[1],9,"","",1,link=True)
                                 #except:pass
                         try:
                             stream_url=stream_url[0][1]
                         except:
                             try:stream_url=stream_url[0][0]
                             except:stream_url = 'Error: -err3-unresolvable:unable to resolve link-no supported host'
                  except:
                      pass
                  try:  
                      if 'openload' in host and not stream_url.startswith("http"):
                          servername='tsresolver'
                          classname=getclass(hostname)
                      
                  except:
                      pass
                             
       if servername=='tsresolver':
                
                
                print 'servername,hostname,classname',host,servername,hostname,classname
                if classname is None:
                   stream_url = 'Error: -err4-unresolvable:unable to resolve link-no supported host'
                else:   

                        classname=getclass(hostname)
                        print "hostname,classname",hostname,classname
                        txt='from plugins.'+hostname.strip()+" import " +classname.strip()+' as Resolver'
                        print "txtxxx",txt
                        exec(txt)
                        
                        host = hostname
                        resolver = Resolver()
                        print "web_url",web_url
                        host,media_id=get_host_id(host,web_url)
                        print "host,media_id",host,media_id
                       
                        stream_url = resolver.get_media_url(host, media_id)
                                 
       elif not servername=='tsresolver' and not servername=='pelisresolver' :
           print 'host,servername,hostname,classname',host,servername,hostname,classname
           hostfile=module_path + "/plugins/" + host + ".py"
           servername_default='tsresolver'
           print "tsresolver hostfile",hostfile
           pelis_hostfile=hostfile.replace("tsresolver/plugins/","pelisresolver/servers/")
           if os.path.exists(hostfile) :
                        print "tsresolver hostfile exists" 
                        classname=getclass(hostname)
                        
                        txt='from plugins.'+hostname.strip()+" import " +classname.strip()+' as Resolver'
                        print "txtxxx",txt
                        exec(txt)
                        servername=='tsresolver'
                        host = hostname
                        resolver = Resolver()
                        print "web_url",web_url
                        host,media_id=get_host_id(host,web_url)
                        stream_url = resolver.get_media_url(host, media_id)

           elif os.path.exists(pelis_hostfile):
              
               
               
               print 'pelis_hostfile',pelis_hostfile
               hostexists=False
               if True:
                      print "pelis hostfile exists"      
                      try:               
                        import pelisresolver      
                        exec('from pelisresolver.servers.'+hostname.strip()+" import get_video_url")
                        hostexists=True
                      except:
                              trace_error()
                              stream_url = 'Error: -err2-import error, unresolvable:unable to resolve link-no supported host'
                      if hostexists==True:         
                              host=hostname
                              stream_url = get_video_url(web_url)
                              print "stream_url",stream_url
                              try:
                                  if type(stream_url) == type([]) :
                                     #3for item in stream_url:
                                            #try:addDir(item[0],item[1],9,"","",1,link=True)
                                             #except:pass
                                     try:
                                         stream_url=stream_url[0][1]
                                     except:
                                         try:stream_url=stream_url[0][0]
                                         except:stream_url = 'Error: -err3-unresolvable:unable to resolve link-no supported host'
                              except:
                                  pass
                           
           else:
               print "url-hostfile,pelis_hostfile", hostfile,pelis_hostfile
               print "no tsresolveror or pelisresolver files for host"
               stream_url = 'Error: -err5-unresolvable:unable to resolve link-no supported host'
               print "web_url",web_url
               logdata("web_url",web_url)
               addDir("Error:Error: -err5-unresolvable:unable to resolve link-no supported host","Error:Error: -err5-unresolvable:unable to resolve link-no supported host",9,"")
               return stream_url
               print "stream_url1",stream_url,os.name
               
               if os.name=='nt':
                    saveasexample(web_url,servername,success=False)
               return stream_url
       print "stream_url2",stream_url
         
       if stream_url is  None or 'unresolvable' in stream_url or 'None' in stream_url:
                            stream_url = 'Error:unresolvable:unable to resolve link'
                            if os.name=='nt':
                                    saveasexample(web_url,servername,success=False)
                            
       if "|" in stream_url:
           stream_url=stream_url.split("|")[0]
       if os.name=='nt':
           saveasexample(web_url,servername,success=True)
       logdata("Final url",stream_url)  
       return stream_url                 

def saveasexample(web_url,servername,success=True):
                     
               try:
                           lines=open(module_path+"/examples").readlines()
                           exists=False
                           for line in lines:
                               parts=line.split(";")
                               if web_url==parts[0] and servername==parts[1]:
                                  exists=True
                                  break
                           if exists==False:
                               afile=open(module_path+"/examples","a")
                               afile.write("\n"+web_url+";"+servername+";"+str(success))
                               afile.close()
               except:
                           pass      
