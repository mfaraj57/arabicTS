url="http:\/\/content.veoh.com\/flash\/p\/2\/v132257534fw8f4Qz7\/h132257534.mp4?ct=8472bec2f814025c1006c9c95641bdca522b021fa259d9f6"
url=url.replace('\/','/')
print url
