#
import re
import jsbeautifier.unpackers.packer as packer
def get_video_url(url):
       
        import xbmctools
       
        data=xbmctools.readnet(url)
        
        unpack = packer.unpack(data)
        #Pre_Stream_URL = re.search('file:"(.*)"', unpack).group(1)
        Pre_Stream_URL = re.search('file:"(.*)",label', unpack).group(1)
        return Pre_Stream_URL        
       





