# -*- coding: utf-8 -*-

import re

from core import scrapertools
#from platformcode import logger


# Returns an array of possible video url's from the page_url
def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    #logger.info("(page_url='%s')" % page_url)
    page_url='http://www.veoh.com/watch/v44762371sYcP4mcW'
    video_urls = []

    # Lo extrae a partir de flashvideodownloader.org
    if page_url.startswith("http://"):
        url = 'http://www.flashvideodownloader.org/download.php?u=' + page_url
    else:
        url = 'http://www.flashvideodownloader.org/download.php?u=http://www.veoh.com/watch/' + page_url
    print "url",url
    sys.exit(0)
    data = scrapertools.cachePage(url)

    # Extrae el vídeo
    patronvideos = '<a href="(http://content.veoh.com.*?)"'
    matches = re.compile(patronvideos, re.DOTALL).findall(data)
    if len(matches) > 0:
        video_urls.append(["[veoh]", matches[0]])

    for video_url in video_urls:
        print (video_url[0], video_url[1])
        #logger.info("%s - %s" % (video_url[0], video_url[1]))

    return video_urls
