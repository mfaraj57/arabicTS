#

def get_video_url(url):
        import re
        import jsbeautifier.unpackers.packer as packer       
        import xbmctools
       
        data=xbmctools.readnet(url)
        
        unpack = packer.unpack(data)
        #Pre_Stream_URL = re.search('file:"(.*)"', unpack).group(1)
        regx='''"file":"(.*)"}]'''
        #Pre_Stream_URL = re.search('file:"(.*)"', unpack).group(1)
        stream_url=re.findall(regx,unpack, re.M|re.I)[0].split('"')[0]
        return stream_url
       





