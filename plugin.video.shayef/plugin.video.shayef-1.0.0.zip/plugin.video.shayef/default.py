# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py




try:import sys, syspath
except:pass
import os, sys
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
from addon.common.net import Net
from urlresolver import resolve
import StringIO
#url='http%3A%2F%2Fvgrp1.viewstream.co.il%2Fviewstream%2F34%2F13%2F299%2F13299.flv%3Fvtraffid%3D13299%26ctraffid%3D34'
#print urllib.unquote_plus(url)
#sys.exit(0)
__settings__ = xbmcaddon.Addon(id='plugin.video.shayef')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://www.shayef.com/'

####functions

def read_url(url):
     
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
    
def readnet2(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

                genreliste=[]
               
                #genreliste.append(("Genres", 'genre',5,'img/6.png','',1))
                genreliste.append(("الاضافات الجديده", 'http://www.shayef.com/Mosalsalat.asp',222,'img/1.png','',1))
                genreliste.append((" جميع المسلسلات", 'http://www.shayef.com/Mosalsalat.asp',3,'img/2.png','',1))
                genreliste.append(("مسلسلات عربيه", 'http://www.shayef.com/MosalsalatArab.asp',3,'img/3.png','',1))
                
                genreliste.append(("مسلسلات رمضان", 'http://www.shayef.com/MosalsalatRamadan.asp',3,'img/4.png','',1)) 
                genreliste.append(("مسلسلات تركيه", 'http://www.shayef.com/MosalsalatTurky.asp',3,'img/5.png','',1))
                genreliste.append(("مسلسلات عالميه", 'http://www.shayef.com/MosalsalatWorld.asp',3,'img/6.png','',1))
                
                genreliste.append(("مواهب ومسابقات", 'http://www.shayef.com/Mwaheb.asp',2001,'img/7.png','',1))
                genreliste.append(("برامج تلفزيون", 'http://www.shayef.com/BramejTV.asp',20011,'img/9.png','',1))
                
                genreliste.append(("افلام عربيه", 'http://www.shayef.com/Aflam.asp',4,'img/10.png','',1)) 

                
                
		
                for title, url, mode,pic,desc,page in genreliste:
                    addDir(title, url, mode, pic,desc,1)

###############################################tv shows
def series_a_z(mainurl):
    matches = [ ('http://www.shayef.com/Mosalsalat.asp', 'ا'),('http://www.shayef.com/Mosalsalat.asp?Leter=2', '\xd8\xa8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=3', '\xd8\xaa'), ('http://www.shayef.com/Mosalsalat.asp?Leter=4', '\xd8\xab'), ('http://www.shayef.com/Mosalsalat.asp?Leter=5', '\xd8\xac'), ('http://www.shayef.com/Mosalsalat.asp?Leter=6', '\xd8\xad'), ('http://www.shayef.com/Mosalsalat.asp?Leter=7', '\xd8\xae'), ('http://www.shayef.com/Mosalsalat.asp?Leter=8', '\xd8\xaf'), ('http://www.shayef.com/Mosalsalat.asp?Leter=9', '\xd8\xb0'), ('http://www.shayef.com/Mosalsalat.asp?Leter=10', '\xd8\xb1'), ('http://www.shayef.com/Mosalsalat.asp?Leter=11', '\xd8\xb2'), ('http://www.shayef.com/Mosalsalat.asp?Leter=12', '\xd8\xb3'), ('http://www.shayef.com/Mosalsalat.asp?Leter=13', '\xd8\xb4'), ('http://www.shayef.com/Mosalsalat.asp?Leter=14', '\xd8\xb5'), ('http://www.shayef.com/Mosalsalat.asp?Leter=15', '\xd8\xb6'), ('http://www.shayef.com/Mosalsalat.asp?Leter=16', '\xd8\xb7'), ('http://www.shayef.com/Mosalsalat.asp?Leter=17', '\xd8\xb8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=18', '\xd8\xb9'), ('http://www.shayef.com/Mosalsalat.asp?Leter=19', '\xd8\xba'), ('http://www.shayef.com/Mosalsalat.asp?Leter=20', '\xd9\x81'), ('http://www.shayef.com/Mosalsalat.asp?Leter=21', '\xd9\x82'), ('http://www.shayef.com/Mosalsalat.asp?Leter=22', '\xd9\x83'), ('http://www.shayef.com/Mosalsalat.asp?Leter=23', '\xd9\x84'), ('http://www.shayef.com/Mosalsalat.asp?Leter=24', '\xd9\x85'), ('http://www.shayef.com/Mosalsalat.asp?Leter=25', '\xd9\x86'), ('http://www.shayef.com/Mosalsalat.asp?Leter=26', '\xd9\x87'), ('http://www.shayef.com/Mosalsalat.asp?Leter=27', '\xd9\x88'), ('http://www.shayef.com/Mosalsalat.asp?Leter=28', '\xd9\x8a')]
    for item in matches:
        title = item[1]
        url = item[0]
        pic = ''
        try:
            mode = item[2]
        except:
            mode = 3
        print "title",title
        
        if "?" in url:
                url=url.split("?")[1]
                url=mainurl+"?"+url
        else:
                url=mainurl
        addDir(title, url, 200, pic)

def movies_a_z(mainurl):
    matches = [ ('http://www.shayef.com/Mosalsalat.asp', 'ا'),('http://www.shayef.com/Mosalsalat.asp?Leter=2', '\xd8\xa8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=3', '\xd8\xaa'), ('http://www.shayef.com/Mosalsalat.asp?Leter=4', '\xd8\xab'), ('http://www.shayef.com/Mosalsalat.asp?Leter=5', '\xd8\xac'), ('http://www.shayef.com/Mosalsalat.asp?Leter=6', '\xd8\xad'), ('http://www.shayef.com/Mosalsalat.asp?Leter=7', '\xd8\xae'), ('http://www.shayef.com/Mosalsalat.asp?Leter=8', '\xd8\xaf'), ('http://www.shayef.com/Mosalsalat.asp?Leter=9', '\xd8\xb0'), ('http://www.shayef.com/Mosalsalat.asp?Leter=10', '\xd8\xb1'), ('http://www.shayef.com/Mosalsalat.asp?Leter=11', '\xd8\xb2'), ('http://www.shayef.com/Mosalsalat.asp?Leter=12', '\xd8\xb3'), ('http://www.shayef.com/Mosalsalat.asp?Leter=13', '\xd8\xb4'), ('http://www.shayef.com/Mosalsalat.asp?Leter=14', '\xd8\xb5'), ('http://www.shayef.com/Mosalsalat.asp?Leter=15', '\xd8\xb6'), ('http://www.shayef.com/Mosalsalat.asp?Leter=16', '\xd8\xb7'), ('http://www.shayef.com/Mosalsalat.asp?Leter=17', '\xd8\xb8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=18', '\xd8\xb9'), ('http://www.shayef.com/Mosalsalat.asp?Leter=19', '\xd8\xba'), ('http://www.shayef.com/Mosalsalat.asp?Leter=20', '\xd9\x81'), ('http://www.shayef.com/Mosalsalat.asp?Leter=21', '\xd9\x82'), ('http://www.shayef.com/Mosalsalat.asp?Leter=22', '\xd9\x83'), ('http://www.shayef.com/Mosalsalat.asp?Leter=23', '\xd9\x84'), ('http://www.shayef.com/Mosalsalat.asp?Leter=24', '\xd9\x85'), ('http://www.shayef.com/Mosalsalat.asp?Leter=25', '\xd9\x86'), ('http://www.shayef.com/Mosalsalat.asp?Leter=26', '\xd9\x87'), ('http://www.shayef.com/Mosalsalat.asp?Leter=27', '\xd9\x88'), ('http://www.shayef.com/Mosalsalat.asp?Leter=28', '\xd9\x8a')]
    for item in matches:
        title = item[1]
        url = item[0]
        pic = ''
        try:
            mode = item[2]
        except:
            mode = 3
        print "title",title
        
        if "?" in url:
                url=url.split("?")[1]
                url=mainurl+"?"+url
        else:
                url=mainurl
        addDir(title, url, 100, pic)        
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url.replace("query",search_entered)

        getseries("Search",url,0)

                    
def getseasons(name,urlmain,page):##series
                if page>1:
                  #/page/2/
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                        
               
def getseasons_search(name,urlmain,page):##series
                
                data=readnet(urlmain)
                try:data=data.split('<h2>Search results')[1]
                except:pass
               
              
                if data is None:
                    return
                regx='<a href="(.*?)"  rel="nofollow">(.*?)</a>'
                seasons=getgroups(data,regx,2)
               
                
                seasons=re.findall(regx,data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                                           
def getmovies(tname,urlmain,page):##series

                data=readnet2(urlmain)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="vi-box">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    block=block.lower()
                    regx='''<a href="(.*?)"><img src="(.*?)" /></a>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match,block.encode("utf-8")
                    href=match[0][0]
                    img=match[0][1]  
                    regx='''<h4>(.*?)</h4>'''
                    name=re.findall(regx,block, re.M|re.I)[0]

                   
                                             
                               
                    
                    name=name.encode("utf-8")
                    
                    try:addDir(name,href,21,img,'',1)
                    except:continue
               
                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def newseries(tname,urlmain,page):##series

                data=readnet2(urlmain)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('class="vi-box-top-Home"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    block=block.lower()
                    regx='''<a href="(.*?)"><img src="(.*?)" /></a>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match,block.encode("utf-8")
                    href=match[0][0]
                    img=match[0][1]  
                    regx='''<h4>(.*?)</h4>'''
                    name=re.findall(regx,block, re.M|re.I)[0]

                   
                                             
                               
                    
                    name=name.encode("utf-8")
                    zoneid=href.split("zoneid=")[1].split("&")[0]
                    #href='http://www.shayef.com/series_page.asp?ZoneID='+zoneid
                    try:addDir(name,href,21,img,'',1)
                    except:continue
               
                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))                    
def getseries(tname,urlmain,page):##series

                data=readnet2(urlmain)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="vi-box">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    block=block.lower()
                    regx='''<a href="(.*?)"><img src="(.*?)" /></a>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match,block.encode("utf-8")
                    href=match[0][0]
                    img=match[0][1]  
                    regx='''<h4>(.*?)</h4>'''
                    name=re.findall(regx,block, re.M|re.I)[0]

                   
                                             
                               
                    
                    name=name.encode("utf-8")
                    zoneid=href.split("zoneid=")[1].split("&")[0]
                    href='http://www.shayef.com/series_page.asp?ZoneID='+zoneid
                    try:addDir(name,href,201,img,'',1)
                    except:continue
               
                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def getepisodes21(name,urlmain,page):##series
                print "page",page
               

               
                data=readnet2(urlmain)

                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    blocks=data.split('class="vi-box-top"')
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                                                
                       regx='href="(.*?)"><h4>(.*?)</h4>'
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       href=match[0][0]
                       name=match[0][1]
                       print "match",match
                       
                       regx='<a href=".*?"><img src="(.*?)" /></a>'
                       img=match=re.findall(regx,block, re.M|re.I)[0]
                    
                       if img:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,201,img,'',1)       
def getepisodes2(name,urlmain,page):##series
                print "page",page
               

               
                data=readnet2(urlmain)

                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    blocks=data.split('class="vi-box-top"')
                    
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='href="(.*?)"><h4>(.*?)</h4>'
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       href=match[0][0]
                       name=match[0][1]
                       print "match",match
                       
                       regx='<a href=".*?"><img src="(.*?)" /></a>'
                       img=match=re.findall(regx,block, re.M|re.I)[0]
                    
                       if img:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,20001,img,'',1)                                            
def getepisodes3(name,urlmain,page):##series
                print "page",page
               

               
                data=readnet2(urlmain)

                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    blocks=data.split('class="vi-box-top"')
                    
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='href="(.*?)"><h4>(.*?)</h4>'
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       href=match[0][0]
                       name=match[0][1]
                       print "match",match
                       
                       regx='<a href=".*?"><img src="(.*?)" /></a>'
                       img=match=re.findall(regx,block, re.M|re.I)[0]
                    
                       if img:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,201,img,'',1)   
def getepisodes(name,urlmain,page):##series
                print "page",page
               

               
                data=readnet2(urlmain)

                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    blocks=data.split('<div class="box-bottom">')
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='<a href="(.*?)"><h2>(.*?)</h2></a>'
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       print "match",match
                
                    
                       for href,name in match:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,21,'','',1)                        
               
                   
                


#######################################host resolving                                                    
def creatertmp(host,urlmain):
     #rtmp://streaming.hayyes.com/vod/<playpath>mp4:29/29303/29303_1_400k.mp4 <swfUrl>http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf <pageUrl>http://www.hayyes.com/vod/aflam/7alawet-roo7
     url=host+'  swfUrl=http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf pageUrl='+ urlmain
     return url

def gethosts(urlmain):##cinema and tv featured
#href="http://www.arabshow.tv/the-forest/2/">
        
        for i in range(1,5):
           href=urlmain+str(i)+"/"     
           addDir("server"+" "+str(i),href,21,'','',1)
        

		
		
                #playlink(link)
def gethosts_movies(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                try:data=data.split("<div class='panel-container'>")[1]
                except:pass
               
                
              
                if data is None:
                    return
                
                blocks=data.split('class="tab-buttons-panel"')
               
                i=0
               
                for block in blocks:
                    i=i+1
                    
                    block=block.lower()
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx2='''<iframe.*?src='(.*?)'.*?></iframe'''
                    #regx3='''<iframe width="600" height="330" scrolling="no" frameborder="0" src="http://videomega.tv/iframe.php?ref=Kjp0m2ECo44oCE2m0pjK&width=600&height=330" allowFullScreen></iframe>'''
                    match=re.findall(regx1,block, re.M|re.I)
                    match2=re.findall(regx2,block, re.M|re.I)
                   
                    
                     
                   
                    
                    for href in match:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)
                    for href in match2:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)
def get_servers(url):
    data = readnet2(url)
    regx = '<a href="(.+?)" target="_blank"><img alt'
    regx='file: "(.+?)"'
    #print "data",data
    match = re.findall(regx, data, re.M | re.I)
    print 'match', match
    i = 0
    if len(match)==0:
            regx='<IFRAME src="(.+?)".+?></IFRAME>'
            href = re.findall(regx, data, re.M | re.I)[0]
            data = readnet2(href)
            regx='"url":"(.+?)"'
            match = re.findall(regx, data, re.M | re.I)
    for href in match:

        i = i + 1
        debug = True

        server = 'link' + str(i)
        if 'viewstream' in href:
            href=url=urllib.unquote_plus(href)
            playlink(href)
            return
           
        if "mp4" in href or 'm3u' in href:    
           addLink(server, href, 2, '')                      
def gethosts2(urlmain):##cinema and tv featured
                data=readnet(urlmain)
                if data is None:
                    return
               
                i=0
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                regx='''<iframe.*?src="(.*?)".*?></iframe></p>'''
                link=re.findall(regx,data, re.M|re.I)[0]
               
                stream_url=resolve(link)
                playlink(stream_url)
	    
def resolve_host(url):#last good-used with local resolver
        if 'jacvideo' in url:
               regx='''"file":"(.*?)"'''
               data=readnet2(url)
               links=re.findall(regx,data, re.M|re.I)
               print "links",links
               
               i=0
               for link in links:
                   i=i+1
                   addDir("quality" +str(i),link,22,"")
               return     
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(url):
            print "m2",url
	    listItem = xbmcgui.ListItem(path=str(url))
	    xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)

            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==3:
        series_a_z(url)
elif mode==4:
        movies_a_z(url)        
elif mode==11:
        print ""+url
        gethosts_movies(url)        
elif mode==2:
        print ""+url
        playlink(url)
elif mode==21:
        print ""+url
        get_servers(url)
        
elif mode==22:
        print ""+url
        playlink(url)          
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)
        
        
elif mode==5:
	print ""+url	
        genres(url)   	
elif mode==51:
	print ""+url	
        years(url)  	
	
elif mode==104:
	print ""+url
	
	searchmovies(url)
elif mode==105:
        print ""+url
        getmovies2(name,url,page)
elif mode==200:
	print "mfaraj"+url
	
	getseries(name,url,page)
	#getvideopage(url,page)
        #getmovies2(name,url,page)
elif mode==222:
	print "mfaraj"+url
	
	newseries(name,url,page)
	#getvideopage(url,page)
        #getmovies2(name,url,page)	
elif mode==2001:
	print "mfaraj"+url
	getepisodes2(name,url,page)
	#getvideopage(url,page)
elif mode==20011:
	print "mfaraj"+url
	getepisodes21(name,url,page)
	#getvideopage(url,page)	
elif mode==20001:
	print "mfaraj"+url
	getepisodes3(name,url,page)
	#getvideopage(url,page)		
elif mode==201:
	getepisodes(name,url,page)
elif mode==202:
	print ""+url
	getA_Z('shows')
	
elif mode==203:
	print ""+url
        search_series(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
