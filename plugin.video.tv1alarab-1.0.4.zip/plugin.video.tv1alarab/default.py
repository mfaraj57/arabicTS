# -*- coding: utf8 -*-


try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,os
from xbmctools import Item,readnet,get_params,playlink,getDomain,resolvehost,getsearchtext,resolvehost,finddata,trace_error,getitems
item=Item()
addDir=item.addDir
endDir=item.endDir
baseurl='http://tv.alarab.com'

##########################################parsing tools


def showmenu():
        ##main
	addDir('search','http://tv.alarab.com/q/',103,'img/0.png','',1,searchall=__file__)
        addDir('اخرالاضافات','http://tv.alarab.com/',100,'img/7.png','',1)

        addDir('الافلام الاجنبيه','http://tv.alarab.com/view-5553/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',100,'img/1.png','',1)
        addDir('أفلام عربية','http://tv.alarab.com/view-1/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9',100,'img/2.png','',1)
        addDir('أفلام هندية','http://tv.alarab.com/view-297/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%87%D9%86%D8%AF%D9%8A%D8%A9',100,'img/6.png','',1)
        addDir('أفلام كرتون','http://tv.alarab.com/view-295/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%83%D8%B1%D8%AA%D9%88%D9%86',200,'img/9.png','',1)
        addDir('افلام مصرية قديمة','http://tv.alarab.com/view-6181/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%85%D8%B5%D8%B1%D9%8A%D8%A9-%D9%82%D8%AF%D9%8A%D9%85%D8%A9',100,'img/11.png','',1)
        addDir('مسلسلات اجنبية','http://tv.alarab.com/view-1951/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',200,'img/7.png','',1)

        addDir('مسلسلات عربيه','http://tv.alarab.com/view-8/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9',200,'img/10.png','',1)
       
       
        addDir('مسلسلات تركية','http://tv.alarab.com/view-299/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%AA%D8%B1%D9%83%D9%8A%D8%A9',200,'img/10.png','',1)
        addDir('مسلسلات كرتون','http://tv.alarab.com/view-4/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D9%83%D8%B1%D8%AA%D9%88%D9%86',200,'img/9.png','',1)
        addDir('مقاطع مضحكة','http://tv.alarab.com/view-309/%D9%85%D9%82%D8%A7%D8%B7%D8%B9-%D9%85%D8%B6%D8%AD%D9%83%D8%A9',100,'img/14.png','',1)
        #addDir('ملخصات المباريات','http://www.alarab.com/tag/%D9%85%D8%A8%D8%A7%D8%B1%D8%A7%D8%A9',100,'img/8.png','',1)
        addDir('فيديو كليب','http://tv.alarab.com/view-10/%D9%81%D9%8A%D8%AF%D9%8A%D9%88-%D9%83%D9%84%D9%8A%D8%A8',100,'img/12.png','',1)
        addDir('مسرحيات','http://tv.alarab.com/view-313/%D9%85%D8%B3%D8%B1%D8%AD%D9%8A%D8%A7%D8%AA',100,'img/13.png','',1)
        addDir('برامج تلفزيون','http://tv.alarab.com/view-311/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%AA%D9%84%D9%81%D8%B2%D9%8A%D9%88%D9%86',100,'img/12.png','',1)
        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        searchkey = getsearchtext("-")      
        print "searchkey",searchkey 
        url= url+searchkey      
          
        search_results("Search",url,1)


def search_results(namemain,page_url,page):##may pastte code of getmovies here
                if page>1:
                        page_url=page_url+"/"+str(page)
                        #https://www.almstba.tv/video/category.php?cat=english-movies&page=2&order=DESC
                        #http://tv.alarab.com/view-5553_3/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9
                        #http://tv.alarab.com/series-5553_%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9_2
                        
                  
                else:
                
                       page_url=page_url
                print "page_url",page_url
               
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
                
                blocks=data.split('javascript:savelist')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=getitems(regx,block)[0]
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=getitems(regx,block)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=getitems(regx,block)[0]
                           

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    href='http://tv.alarab.com'+href
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>9:
                    
                   addDir("next page",url,4,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,4,'','',str(page+1))



               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                        parts=os.path.split(url)
                        basename=parts[1]
                        path=parts[0]
                        page_url=path.replace("view","series")+"_"+basename+"_"+str(page)
                        page_url=str(page_url)
                        #http://tv.alarab.com/series-6686_%D9%83%D8%A3%D9%86%D9%87-%D8%A5%D9%85%D8%A8%D8%A7%D8%B1%D8%AD_2
                        page_url=url+"_"+str(page)
                        
                        
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
                try:data.split('swiper-wrapper')
                except:pass
                if data is None:
                    return
               
                
               
                blocks=data.split('video-box')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=getitems(regx,block)[0]
                    except:
                            trace_error()
                            continue
                    href='http://tv.alarab.com'+href
                    regx='''alt="(.*?)"'''                    
                    try:
                            title=getitems(regx,block)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=getitems(regx,block)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>19:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))












###############################################series


def getseries(name,url,page):##series
               
               
                if page>1:
                        #http://tv.alarab.com/view-1951/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9
                        #http://tv.alarab.com/view-2_%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9_1951
                        parts=os.path.split(url)
                        basename=parts[1]
                        
                        
                        path=parts[0]
                        id=path.split("-")[1]
                        pathnoid=path.split("-")[0]
                        page_url=pathnoid+"-"+str(page)+"_"+basename+"_"+id
                        #page_url=path.replace("view-","view-"+str(page))+"_"+basename+"_"+id
                        
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                #print "data",data
                
                
                if data is None:
                    return
               
                
               
                blocks=data.split('video-box')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=getitems(regx,block)[0]
                    except:
                            trace_error()
                            continue
                    href='http://tv.alarab.com'+href
                    regx='''alt="(.*?)"'''                    
                    try:
                            title=getitems(regx,block)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=getitems(regx,block)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,100,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>15:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))










                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,url,page):##series

                print "page",page
               
                if page>1:
                    
                        #http://www.movs4u.com/movie/page/2/
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=readnet(page_url)
               
                
                
               
                if data is None:
                    return
               
                blocks=data.split('class="imagen"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    tblock=block.split('class="episodiotitle"')[1]    
                    regx='''<a href="(.*?)">(.*?)</a>'''                    
                    match=re.findall(regx,tblock, re.M|re.I)[0]                   
                    
                    href=match[0]
                    title=os.path.basename(href[:-1])
                    name=match[1]
                    name=title+"-"+name
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    try:href=href.encode("utf-8")
                    except:href=str(href)
                    name=name.replace("مترجمه","")
                    addDir(name,href,1,'img/2.jpg','',1,maintitle=True)
                    #except:pass
               
                   
                
                
                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                


#######################################host resolving                                                    
                    

def getservers(name,url):
                data=readnet(url)
                
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                href=re.findall(regx,data, re.M|re.I)[0]
                href=href.split("&height")[0]
                print "href",href
                data=readnet(href)
                
                regx='''file: "(.*?)"'''
                regx='''file: "(.*?)"'''
                match=re.findall(regx,data, re.M|re.I)
                print "match",match
                for href in match:

                        
                   
                    

                    
                    
                    if "iphone" in href:
                            title="480"
                    else:
                            title='1080'
                    if not ".mp4" in href:
                            continue                   
                    if True:
                            try:addDir(title,href,1,"img/server.png",'',1,link=True)
                            except:pass

                 
def resolve_host(name,url):
        resolvehost(item,name,url)    
        
        
def start():
  
        params=get_params()
        url=params.get('url','')
        name=params.get('name','')
        try:mode=int(params.get('mode',None))
        except:mode=None
        page=int(params.get('page',1))
        section=params.get('section','')
        extra=params.get('extra','')
        show=params.get('show','')
        image=params.get('image','')

        print "Mode: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "page: "+str(page)
        print "section: "+str(section)
        print "extra: "+str(extra)
        print "show: "+str(show)
        print "image: "+str(image)
        ##menu and tools
        if mode==None or url==None or len(url)<1:
                print ""
                showmenu()
        ##hosts        
        elif mode==1:
                print ""+url
                
                getservers(name,url)
        elif mode==2:
                print ""+url
                resolve_host(name,url)        
        elif mode==3:
                print ""+url
                playlink(url)
        elif mode==4:
                print ""+url
                search_results(name,url,page)        
        ###movies     
                
        elif mode==100:
                print ""+url
                getmovies(name,url,page)

        elif mode==101:
                print ""+url
                getgenre('movies')	

        elif mode==102:
                print ""+url
                getA_Z('movies')
                
        elif mode==103:
                print ""+url
                search(url)
        ##extra years 104,genres 105,a-z 106        
        ###series        


        elif mode==200:

                getseries(name,url,page)
                
        elif mode==201:
                getseasons(name,url,page)
                
        elif mode==202:
                getepisodes(name,url,page)

        elif mode==203:
                print ""+url
                search_tvshows(url)           

        return endDir()
start()
