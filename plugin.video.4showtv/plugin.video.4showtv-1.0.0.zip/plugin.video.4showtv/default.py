# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,getnet,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error,removeunicode
################''
baseurl='http://www.4show.me'

##########################################parsing tools


def showmenu():
        addDir('ٍSearch','http://www.4show.me/search?q=love',103,'img/1.png','',1)

        addDir('الافلام الاجنبيه','http://www.4show.me/search/label/%D8%A3%D9%81%D9%84%D8%A7%D9%85%20%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9%20%2F%20Non-Arabic%20Movies?&max-results=24',100,'img/1.png','',1)
        addDir('المسلسلات الاجنبيه','http://www.4show.me/search/label/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA%20%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9%20%2F%20Non-Arabic%20TV%20Shows?&max-results=24',200,'img/2.png','',1)


	addDir('الافلام العربيه','http://www.4show.me/search/label/%D8%A3%D9%81%D9%84%D8%A7%D9%85%20%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9%20%2F%20Arabic%20Movies?&max-results=24',100,'img/3.png','',1)
        addDir('مسلسلات عربيه','http://www.4show.me/search/label/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA%20%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9%20%2F%20Arabic%20TV%20Shows?&max-results=24',300,'img/4.png','',1)

        addDir('مسلسلت تركيه','http://www.4show.me/search/label/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA%20%D8%AA%D8%B1%D9%83%D9%8A%D8%A9%20%2F%20Turkish%20TV%20Shows?&max-results=24',200,'img/5.png','',1)

        addDir('مسلسلات اسيويه','http://www.4show.me/search/label/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA%20%D8%A2%D8%B3%D9%8A%D9%88%D9%8A%D9%87%20%2F%20Asian%20TV%20Shows?&max-results=24',300,'img/6.png','',1)

        addDir('افلام هندي','http://www.4show.me/search/label/%D8%A3%D9%81%D9%84%D8%A7%D9%85%20%D9%87%D9%86%D8%AF%D9%8A%D8%A9%20%2F%20Indian%20Movies?&max-results=24',100,'img/7.png','',1)        
        addDir('Animation','http://www.4show.me/search/label/%D8%A3%D9%86%D9%8A%D9%85%D9%8A%D8%B4%D9%86%20%2F%20Animation?&max-results=24',200,'img/8.png','',1)

        return



        addDir('المسلسلات العربيه','http://www.gdedak.com/series/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A/',200,'img/4.png','',1)	
        addDir('مسلسلات رمضان 2017','http://www.gdedak.com/series/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2017/',200,'img/5.png','',1)


        addDir('افلام تركيه','http://www.gdedak.com/movies/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%AA%D8%B1%D9%83%D9%8A%D8%A9/',100,'img/6.png','',1)        
        addDir('افلام كوريه','http://www.gdedak.com/movies/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%83%D9%88%D8%B1%D9%8A%D8%A9/',100,'img/7.png','',1)        
        addDir('افلام انيمي','http://www.gdedak.com/movies/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%86%D9%85%D9%8A/',100,'img/8.png','',1)        
        addDir('افلام هندي','http://www.4show.me/search/label/%D8%A3%D9%81%D9%84%D8%A7%D9%85%20%D9%87%D9%86%D8%AF%D9%8A%D8%A9%20%2F%20Indian%20Movies?&max-results=24',100,'img/9.png','',1)        

       
        addDir('مسلسلات انيمي','http://www.gdedak.com/series/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%86%D9%85%D9%8A/',200,'img/10.png','',1)
        addDir('مسلسلات تركيه','http://www.gdedak.com/series/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%AA%D8%B1%D9%83%D9%8A%D8%A9/',200,'img/11.png','',1)
        addDir('مسلسلات كوريه','http://www.gdedak.com/series/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D9%83%D9%88%D8%B1%D9%8A%D8%A9/',200,'img/12.png','',1)
        addDir('مسلسلات هنديه','http://www.gdedak.com/series/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D9%87%D9%86%D8%AF%D9%8A%D8%A9/',200,'img/13.png','',1)

        addDir('برامج تلفزيونيه','http://www.gdedak.com/series/category/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%AA%D9%84%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D8%A9/',200,'img/14.png','',1)

        addDir('مصارعه حره','http://www.gdedak.com/movies/category/%D9%85%D8%B5%D8%A7%D8%B1%D8%B9%D8%A9-%D8%AD%D8%B1%D9%87/',100,'img/15.png','',1)        

        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  

        
        
         
 
          
       


def search(name,sterm,page):##may pastte code of getmovies here
                surl='http://www.4show.me/search?q='+sterm


                data=readnet(surl)           
##################################################################                
                
               
                
                
                
                
                if data is None:
                    return
                regx='''<a class='blog-pager-older-link' href='(.*?)' id='.*?' title='''               
                try:
                    nextpage=re.findall(regx,data, re.M|re.I)[0]
                except:
                    nextpage=None
                               
                print "nextpage",nextpage
                
                blocks=data.split("itemscope='itemscope'")
                i=0
                
               
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                   
                    regx="<a href='(.*?)'><div"                  
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            print "href",href
                            
                            
                    except:
                            trace_error()
                            continue

                    regx="title='(.*?)'"                   
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''content="(.*?)"'''
                    image=finddata(block,"content='","'")
                    
                                              
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                  
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if nextpage:
                   addDir("next page",nextpage,103,'img/next.png','',str(page+1))





               
                   
                
               
                   
                
        
def getmovies(name,page_url,page):##movies
               
               
              
                
                data=readnet(page_url)           
                
                
                
                if data is None:
                    return
                regx='''<a class='blog-pager-older-link' href='(.*?)' id='.*?' title='''               
                try:
                    nextpage=re.findall(regx,data, re.M|re.I)[0]
                except:
                    nextpage=None
                               
                print "nextpage",nextpage
                
                blocks=data.split("itemscope='itemscope'")
                i=0
                
               
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                   
                    regx="<a href='(.*?)'><div"                  
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            print "href",href
                            
                            
                    except:
                            trace_error()
                            continue

                    regx="title='(.*?)'"                   
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''content="(.*?)"'''
                    image=finddata(block,"content='","'")
                    
                                              
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                  
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if nextpage:
                   addDir("next page",nextpage,100,'img/next.png','',str(page+1))

                
                









###############################################series


def getseries(name,url,page):##series
               
              
                
                data=readnet(url)           
                
                
                
                if data is None:
                    return
                regx='''<a class='blog-pager-older-link' href='(.*?)' id='.*?' title='''               
                try:
                    nextpage=re.findall(regx,data, re.M|re.I)[0]
                except:
                    nextpage=None
                               
                print "nextpage",nextpage
                
                blocks=data.split("itemscope='itemscope'")
                i=0
                
               
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                   
                    regx="<a href='(.*?)'><div"                  
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            print "href",href
                            
                            
                    except:
                            trace_error()
                            continue

                    regx="title='(.*?)'"                   
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''content="(.*?)"'''
                    image=finddata(block,"content='","'")
                    
                                              
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                  
                    try:
                      addDir(title,href,201,image,'',1)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if nextpage:
                   addDir("next page",nextpage,200,'img/next.png','',str(page+1))

                
                



def getseries300(name,url,page):##series
               
              
                
                data=readnet(url)           
                
                
                
                if data is None:
                    return
                regx='''<a class='blog-pager-older-link' href='(.*?)' id='.*?' title='''               
                try:
                    nextpage=re.findall(regx,data, re.M|re.I)[0]
                except:
                    nextpage=None
                               
                print "nextpage",nextpage
                
                blocks=data.split("itemscope='itemscope'")
                i=0
                
               
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                   
                    regx="<a href='(.*?)'><div"                  
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            print "href",href
                            
                            
                    except:
                            trace_error()
                            continue

                    regx="title='(.*?)'"                   
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''content="(.*?)"'''
                    image=finddata(block,"content='","'")
                    
                                              
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                  
                    try:
                      addDir(title,href,202,image,'',1)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if nextpage:
                   addDir("next page",nextpage,300,'img/next.png','',str(page+1))

                
                


                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:blocks=data.split('data-toggle="drop2down" type="button"')
                except:pass
              
                print "block",blocks[1]
                i=0
                for block in blocks:
                    if i==1:
                            continue
                    season=block.split('<span class="caret"')[0]
                    season=removeunicode(season)
                    regx='''<li onclick="tab.location.href='(.*?)'" style="text-align: center;"><b>(.*?)</b></li>'''
                    match=re.findall(regx,block, re.M|re.I)
                    list=[]
                    for href,name in match:
                      print "name",name
                      
                      title=str(season)+"_"+name
                      
                      server=getDomain(href)
                      addDir(str(title)+"-"+server,href,2,'','',1)
                    
                     
                                           
                                    


def getepisodes(name,url,page):##series

                data=readnet(url)
                #try:blocks=data.split('data-toggle="drop2down">')
                #except:pass
                from xbmctools import finditems
                blocks=data.split('سيرفر')
                print "block",len(blocks)
                
               
                i=0
                k=1
                for block in blocks:
                    i=i+1    
                    if i==1:
                            continue
                    
                    server="server "+str(k)
                    regx='''<li onclick="tab.location.href='(.*?)'" style="text-align: center;"><b>(.*?)</b></li>'''
                    match=re.findall(regx,block, re.M|re.I)
                    list=[]
                    k=k+1
                    for href,name in match:
                      print "name",name
                      
                      title=server+"_"+name
                      
                      server=getDomain(href)
                      addDir(str(title)+"-"+server,href,2,'','',1)
                      


#######################################host resolving                                                    
                    

def getservers(name,url):
                data=readnet(url)
                regx='''<li onclick="tab.location.href='(.*?)'".*?><b>(.*?)</b></li>'''
                match=re.findall(regx,data, re.M|re.I)
                for href,name in match:
                        addDir(name,href,2,'img/server.png','',1)
                
                #http://aflam06.com/wp-content/themes/YourColor/servers/server.php?q=11878&i=1
                
                 
def resolve_host(url):
        resolve_host(url)    

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        resolvehost(url)        
elif mode==3:
        print ""+url
        playlink(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
        sterm = getsearchtext()      
         
        search("Search",sterm,page) 
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
elif mode==300:

	getseries300(name,url,page)	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
