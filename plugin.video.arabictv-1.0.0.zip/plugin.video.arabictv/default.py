
# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os,requests
from xbmctools import Item,readnet,supported,get_params,getDomain,finddata,getserver_image,resolvehost,playlink,getsearchtext
item=Item()
addDir=item.addDir
endDir=item.endDir
################''
baseurl='https://www.awaan.ae'

##########################################parsing tools
def savedata(txt=None):
        cfile=open(__file__.replace("default.py","data.log"),"w")
        cfile.write(txt)
        cfile.close()

def showmenu():

        addDir('قنوات عربية','URL',11,'img/arab.png',1)

        addDir('قنوات خليجية','URL',14,'img/gulf.png',1)
        addDir('قنوات اخبارية','URL',13,'img/news.png',1)
        addDir('قنوات رياضية','URL',15,'img/sport.png',1)
        addDir('قنوات دينية','URL',12,'img/rel.png',1)

 

def SPORTTV():
        addDir('AD Sports 1 HD','http://adtv.ercdn.net/adsport1/adsport1_720p.m3u8',2,'http://shooftv.org/images/adsport/AD-Sports1.png',1)
        addDir('AD Sports 2 HD','http://adtv.ercdn.net/adsport2/adsport2_720p.m3u8',2,'http://shooftv.org/images/adsport/AD-Sports2.png',1)

        addDir('Dubai sports 1','http://dmiftvll.mangomolo.com/dubaisports/smil:dubaisports.smil/chunklist_b1750000.m3u8',2,'http://picon.space/dubaisport1.png',1)

        addDir('Dubai sports 2','http://dmiftvll.mangomolo.com/dubaisportshd/smil:dubaisportshd.smil/chunklist_b2000000.m3u8',2,'http://picon.space/dubaisport1.png',1)

        addDir('Dubai racing live','http://dmisvthvll.cdn.mangomolo.com/events/smil:events.smil/chunklist_b1600000.m3u8',2,'http://3.bp.blogspot.com/-nUAi5doBzLA/VWyWTNx-F3I/AAAAAAAADI4/kBxmX2YpyWc/s1600/Dubai-Racing-2_o.jpg',1)
        addDir('Dubai racing 2 live','http://dmithrvll.cdn.mangomolo.com/dubairacing/smil:dubairacing.smil/chunklist_b1600000.m3u8',2,'http://3.bp.blogspot.com/-nUAi5doBzLA/VWyWTNx-F3I/AAAAAAAADI4/kBxmX2YpyWc/s1600/Dubai-Racing-2_o.jpg',1)
        addDir('ALKASS 1 HD','http://alkass-i.akamaihd.net/hls/live/205534/kass1AYXB/live_1s20.m3u8',2,'https://2.bp.blogspot.com/-fdf7MvCP7qQ/V-NALqpTSTI/AAAAAAAALB8/OE7ECAeYg-QNdVvX5Q0Qa0Znrs-e_UCfACLcB/s1600/%25D8%25AA%25D8%25B1%25D8%25AF%25D8%25AF%2B%25D8%25A7%25D9%2584%25D9%2583%25D8%25A7%25D8%25B3.jpg',1)
        addDir('ALKASS 2 HD','http://alkass-i.akamaihd.net/hls/live/205534/kass2AYXB/live_20s20.m3u8',2,'https://2.bp.blogspot.com/-fdf7MvCP7qQ/V-NALqpTSTI/AAAAAAAALB8/OE7ECAeYg-QNdVvX5Q0Qa0Znrs-e_UCfACLcB/s1600/%25D8%25AA%25D8%25B1%25D8%25AF%25D8%25AF%2B%25D8%25A7%25D9%2584%25D9%2583%25D8%25A7%25D8%25B3.jpg',1)
        addDir('ALKASS 4 HD live','http://alkasslive.streaming.mediaservices.windows.net/10f0885f-4103-4b2b-8dc1-3bc22c09702c/a70e3d26-a79e-40b3-9e29-1ac92ec14abf.ism/QualityLevels(2200000)/Manifest(video,format=m3u8-aapl-v3,audiotrack=audio)',2,'https://2.bp.blogspot.com/-fdf7MvCP7qQ/V-NALqpTSTI/AAAAAAAALB8/OE7ECAeYg-QNdVvX5Q0Qa0Znrs-e_UCfACLcB/s1600/%25D8%25AA%25D8%25B1%25D8%25AF%25D8%25AF%2B%25D8%25A7%25D9%2584%25D9%2583%25D8%25A7%25D8%25B3.jpg',1)


def ARABTV():


        addDir('Alaantv','http://alaan.cdn.mangomolo.com/alaantv/smil:switch.smil/chunklist_b800000_t64NTc2cA==.m3u8',2,'http://seevii.com//stb/item//tv_live1/252.png',1)
        addDir('FutureTV live','http://futuretv.cdn.mangomolo.com/futuretv/smil:futuretv.smil/chunklist_b240000.m3u8',2,'http://livefuturetv.com/futurelogo.png',1)
        addDir('Makan','http://82.80.192.27/ipbc_IPBCmakantvLVMRepeat/_definst_/smil:IPBCmakantvLVM.smil/chunklist_w649441245_b1928000.m3u8',2,'https://upload.wikimedia.org/wikipedia/en/5/56/MeKan_33_logo_2017.png',1)
		
        addDir('Jordan_TV live','http://stream.joinvisions.net:1935/Jordantv/Jordan_TV/gmswf.m3u8',2,'https://cdn.sat.tv/wp-content/uploads/2016/05/JordanTV.png',1)
		
        addDir('libya live','http://starmena.ercdn.net/libyaschannel/libyaschannel_480p.m3u8',2,'http://www.tv-logo.com/pt-data/uploads/images/logo/libya_one_tv.jpg',1)
        addDir('MTV','https://svs.itworkscdn.net/mtvlebanonlive/smil:mtvlive.smil/chunklist_b3225000.m3u8',2,'https://cdn.sat.tv/wp-content/uploads/2017/03/MTVLebanon.png',1)
		
        addDir('ANN','http://ns8.indexforce.com:1935/ann/ann/playlist.m3u8',2,'http://ik.imagekit.io/ulangotv/image/upload/3780278_logo_ann_tv.png',1)
        addDir('Iraq','http://ns8.indexforce.com:1935/home/mystream/playlist.m3u8',2,'http://www.tv-logo.com/pt-data/uploads/images/logo/al_iraqya.jpg',1)
		



def NEWS():
        addDir('Sky News arabia','https://stream.skynewsarabia.com/hls/sna_720.m3u8',2,'https://www.jo24.net/assets/2017-11-08/images/245111_21_1510147439.jpg',1)
        addDir('Alarabiya','http://live.alarabiya.net/alarabiya/myStream_720p/chunklist.m3u8',2,'http://picon.space/alarabiya.png',1)
		
        addDir('Aljazeera','http://aljazeera-ara-hd-live.hls.adaptive.level3.net/aljazeera/arabic2/index2073.m3u8',2,'http://picon.space/aljazeerainternational.png',1)
        addDir('DW','http://dwstream2-lh.akamaihd.net/i/dwstream2_live@124400/index_2_av-b.m3u8',2,'http://referenceur-tv.com/wp-content/uploads/2011/06/dw-arabic-television-arabe-gratuite-en-direct-streaming.png',1)		
        addDir('BBC','http://bbcwshdlive01-lh.akamaihd.net/i/atv_1@61433/index_800_av-p.m3u8',2,'http://picon.space/bbcone.png',1)
        addDir('RT HD','https://rt-arab.secure.footprint.net/1104-inadv-qidx-1k_v3.m3u8',2,'https://upload.wikimedia.org/wikipedia/en/thumb/a/ae/RTD-TV-logo.png/220px-RTD-TV-logo.png',1)
		
        addDir('National Geographic HD','http://adtv.ercdn.net/adnatgeo/adnatgeo_720p.m3u8',2,'https://cdn.sat.tv/wp-content/uploads/2017/03/AbuDhabiNatGeo.png',1)
        addDir('ALJAZEERA DOC','http://aljazeera-doc-apple-live.adaptive.level3.net/apple/aljazeera/hq-doc/1600kStream.m3u8',2,'http://picon.space/aljazeeradocumentaryarb.png',1)
		
 		
		
		
		
		


def GULFTV():
		
        addDir('Dubai live','http://dmisxthvll.cdn.mangomolo.com/dubaitv/smil:dubaitv.smil/chunklist_b1800000.m3u8',2,'http://picon.space/dubaitv.png',1)
        addDir('One-Tv live','http://dmithrvll.cdn.mangomolo.com/dubaione/smil:dubaione.smil/chunklist_b1800000.m3u8',2,'http://picon.space/dubaione.png',1)
        addDir('Noor Dubai live','http://dmiffthvll.cdn.mangomolo.com/noordubaitv/smil:noordubaitv.smil/chunklist_b1500000.m3u8',2,'http://webtvonlive.com/wp-content/uploads/Noor-Dubai-webtvonlive-com.jpg',1)
        addDir('Sama Dubai live','http://dmieigthvll.cdn.mangomolo.com/samadubai/smil:samadubai.smil/chunklist_b125000.m3u8',2,'https://s3-eu-west-1.amazonaws.com/photo.elcinema.com/tvguide/1177_1.png',1)
        addDir('Dubai Zaman live','http://dmiffthvll.cdn.mangomolo.com/dubaizaman/smil:dubaizaman.smil/chunklist_b1500000.m3u8',2,'http://picon.space/dubaizamanarb.png',1)
		
        addDir('ktv plus live','https://svs.itworkscdn.net/ktvpluslive/kplus.smil/chunklist_b2400000.m3u8?nimblesessionid=232608818',2,'http://3.bp.blogspot.com/-nYPyDv-GZw8/VZKxyjr1H_I/AAAAAAAAAGQ/222G4Q9AP4g/s1600/ktv_plus.png',1)
        addDir('ktv live','https://svs.itworkscdn.net/ktvarabelive/karabe.smil/chunklist_b2400000.m3u8?nimblesessionid=232608196',2,'http://picon.space/ktv1arb.png',1)

        addDir('AD DRAMA HD','http://adtv.ercdn.net/addrama/addrama_720p.m3u8',2,'http://abudhabiliving.net/sites/default/files/logodrama.png',1)
        addDir('SHARJAH HD','http://livestreaming.itworkscdn.net/smc1live/smc1tv/playlist.m3u8',2,'http://picon.space/sharjahtvarb.png',1)
		
		
        addDir('ELEMARATE HD','http://adtv.ercdn.net/adalemarat/adalemarat_720p.m3u8?v=',2,'http://www.shahidhd.tv/video/uploads/thumbs/27d260a48-1.jpg',1)
 		
        addDir('Oman','http://38.96.148.30:1935/live/omantv3/playlist.m3u8',2,'https://cdn.sat.tv/wp-content/uploads/2016/05/Oman_tv.png',1)
 		
def RELIGION():

 
        addDir('Ayaat TV (KSA)','http://m.live.net.sa:1935/live/ayat/chunklist_w1642024713.m3u8',2,'https://i.imgur.com/nZTxP5z.jpg',1)
        addDir('Iqraa (KSA)','http://199.167.151.237:1935/live/sp15_25.stream/gmswf.m3u8',2,'http://www.telemuslim.tv/wp-content/uploads/2016/02/logo-iqraa-arabic-1.png',1)

        addDir('Al Majd Holy Quran (KSA)','http://199.167.151.237:1935/live/sp15_24.stream/gmswf.m3u8',2,'https://www.almstba.tv/video/uploads/thumbs/ea76a7e72-1.jpg',1)
		

        

# -*- coding: utf8 -*-



def years():###nt active-movies 110,series 210
        list=[]
        for i in range(1950,2019):
             #http://tellymov.com/s/year/2006
             list.append(i)
        list.reverse()     
        for i in list:
                
             addDir(str(i),'http://www.tfarjo.com/films/annee/film-'+str(i)+'-streaming/',100,'','',1)                 
                  
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["1" ,"2", "3" ,"4" ,"5" ,"6" ,"7" ,"9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://www.tfarjo.com/films/alphabet/'+letter.lower()+"/",100,'','',1)
###################################movies
			  

        
        
          
 
          
def postData(sterm):
    
    headers = {'Host': 'www.awaan.ae',
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer':'https://www.awaan.ae',
     'Connection': 'keep-alive'}
    s = requests.Session()
    content=s.get('https://www.awaan.ae').content
    
    regx='''<input name="_token" type="hidden" value="(.*?)"/>'''
    token=re.findall(regx,content, re.M|re.I)[0]
    print "token",token

    data={'_token': token,'term': sterm}    
    r = s.post('https://www.awaan.ae/research', headers=headers, data=data)
    htmldata = r.content
    return htmldata

def search(name,sterm,page):##may pastte code of getmovies here
               


                data=postData(sterm)

                blocks=data.split('shows-video-col')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace('&quot;',"-").replace('&ndash;',"-")
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''class="title-link.*?">(.*?)</a>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                
                
                





               
                   
                
               
                   
                
        






###############################################series

def getmovies(name,url,page):##series
                if page>1:
                  # http://cimaclub.com/new/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%89-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/page/2/
                   #https://www.awaan.ae/show/allprograms?p=1&cat_id=30348&language=&production_year=&order_type=&order=
                   ##https://www.awaan.ae/show/allprograms/30348/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA?p=1
                   page_url=url.replace("p=1","p="+str(page))
                  
                else:
                
                     page_url=url
                print "url_page",page_url
                #url=page_url
                
                #data=getData(url, data = {}, host = 'www.awaan.ae', Referer = url)
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('shows-video-col')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''class="title-link">(.*?)</a>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                if len(blocks)>14:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))
                   
                






def getseries(name,url,page):##series
                if page>1:
                  # http://cimaclub.com/new/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%89-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/page/2/
                   #https://www.awaan.ae/show/allprograms?p=1&cat_id=30348&language=&production_year=&order_type=&order=
                   ##https://www.awaan.ae/show/allprograms/30348/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA?p=1
                   page_url=url.replace("p=1","p="+str(page))
                  
                else:
                
                     page_url=url
                print "url_page",page_url
                #url=page_url
                
                #data=getData(url, data = {}, host = 'www.awaan.ae', Referer = url)
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('shows-video-col')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''class="title-link">(.*?)</a>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                if len(blocks)>14:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))
                   
                





                    

                                           
                                    


def getepisodes(name,url,page):##series
                if page>1:
                  # http://cimaclub.com/new/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%89-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/page/2/
                  #https://www.awaan.ae/show/208566/%D8%B3%D9%86%D8%AF%D8%B1%D9%8A%D9%84%D8%A7-?p=2
                  page_url=url+"?p="+str(page)
                  
                else:
                
                     page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('video-col')
                i=0
                
                print "blocks",len(blocks)
                
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''class="title-link">(.*?)</a>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
                if len(blocks)>14:
                    
                   addDir("next page",url,202,'img/next.png','',str(page+1))
                       
                   

#######################################host resolving                                                    
                    

def getservers(name,url):

        data=readnet(url)
                
        data=data.replace("&amp;","&")
        regx='''<iframe.*?src="(.*?)".*?></iframe>'''
        
        href=re.findall(regx,data, re.M|re.I)[1]
        print "href1",href
        
       
        data=readnet(href)
        print "Data",data
        regx='src: "(.*?)"'
        #href="http:"+finddata(data,'src: "','"')
        href=finddata(data,'src: "','"')
        print "href2",href
        addDir(name,href,0,'',1,link=True)
               

                 
def resolve_host(name,url):
       
       return

  
def start():  
        params=get_params()
        url=None
        name=None
        mode=None
        page=1


        name=params.get("name",None)
        url=params.get("url",None)
        try:mode=int(params.get("mode",None))
        except:mode=None
        image=params.get("image",None)
        section=params.get("section",None)
        page=int(params.get("page",1))
        extra=params.get("extra",None)
        show=params.get("show",None)





        print "Mode1: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "Image: "+str(image)
        print "page: "+str(page)
        print "section: "+str(section)
        print "show: "+str(show)
        print "extra: "+str(extra)
        ##menu and tools
        if mode==None==None or url==None or len(url)<1:
                print ""
                showmenu()
        ##hosts        
        elif mode==1:
                print ""+url
                
                getservers(name,url)
        elif mode==2:
                print ""+url
                addDir(name,url,0,"",link=True)       
        elif mode==3:
                print ""+url
                playlink(item,name,url)
                
        ###movies     
                
        elif mode==100:
                print ""+url
                getmovies(name,url,page)

        elif mode==11:
                print ""+url
                ARABTV()				
				
        elif mode==12:
                print ""+url
                RELIGION()
				
        elif mode==13:
                print ""+url
                NEWS()
				
				
        elif mode==14:
                print ""+url
                GULFTV()
				
        elif mode==15:
                print ""+url
                SPORTTV()
				
				
        
        elif mode==101:
                print ""+url
                years()	
        
        elif mode==102:
        	print ""+url
        	getA_Z('movies')
        	
        elif mode==103:
                sterm = getsearchtext()      
                 
                search("Search",sterm,page) 
        ##extra years 104,genres 105,a-z 106        
        ###series        
        
        
        elif mode==200:
        
        	getseries(name,url,page)
        	
        elif mode==201:
        	getseasons(name,url,page)
        	
        elif mode==202:
        	getepisodes(name,url,page)
        
        elif mode==203:
        	print ""+url
                search_tvshows(url)           
        
        return endDir()
        
start()