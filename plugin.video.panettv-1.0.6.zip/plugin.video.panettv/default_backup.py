# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os,json
from xbmctools import addDir,readnet,supported,get_params,getnet,finddata,getserver_image,playlink,postData,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error,removeunicode
################''
baseurl='http://www.panet.co.il'

##########################################parsing tools


def showmenu():
        addDir('Search ','http://www.panet.co.il',103,'img/search.png','',1,searchall=__file__)        
        addDir('افلام عربيه','http://www.panet.co.il/movies',100,'img/10.png','',1)
        addDir('مسلسلات رمضان 2018','http://www.panet.co.il/series/v1/category/58/1',200,'img/5.png','',1)
            
        addDir('مسلسلات مصريه','http://www.panet.co.il/series/category/19/1',200,'img/5.png','',1)
       
        addDir('مسلسلات لبنانيه وسوريه','http://www.panet.co.il/series/category/18/1',200,'img/7.png','',1)
        addDir('مسلسلات تركي','http://www.panet.co.il/series/category/17/1',200,'img/16.png','',1)

        addDir('مسلسلات خليجيه','http://www.panet.co.il/series/category/21/1',200,'img/6.png','',1)

        addDir('مسلسلات مكسيكيه وعالميه','http://www.panet.co.il/series/category/20/1',200,'img/12.png','',1)


        addDir('برامج ورسوم اطفال','http://www.panet.co.il/series/category/15/1',200,'img/13.png','',1)

        addDir('حفلات','http://www.panet.co.il/series/category/7/1',200,'img/8.png','',1)

        #addDir('كليبات مضحكه','http://www.panet.co.il/series/v1/category/2/1',100,'img/10.png','',1)
        

        
       





        





def years():###nt active-movies 110,series 210
        list=[]
        for i in range(1950,2019):
             #http://tellymov.com/s/year/2006
             list.append(i)
        list.reverse()     
        for i in list:
                
             addDir(str(i),'http://www.tfarjo.com/films/annee/film-'+str(i)+'-streaming/',100,'','',1)                 
                  
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["1" ,"2", "3" ,"4" ,"5" ,"6" ,"7" ,"9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://www.tfarjo.com/films/alphabet/'+letter.lower()+"/",100,'','',1)
###################################movies
			  

        
        
          
 
          
       


def search_103(name,sterm,page):##may pastte code of getmovies here

##############################################
                data={'query':sterm,'searchDomain': 'series','gsaServer': 'gsa','from': str(page)}
                data=postData('http://www.panet.co.il/search',data,'www.panet.co.il','http://www.panet.co.il/series/v1')           
                
                jdata=json.loads(data)
                for item in jdata['results']:
                    title= item['title']
                    href= item['link']
                    id=os.path.split(href)[0]
                    image='http://pms.panet.co.il/online/images/video_lib/movies/'+id+'_newimg.jpg'
       
                    try:
                         addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                        trace_error(0)
                        continue                   
                
                if len(jdata['results'])>8:
                    
                   addDir("next page",sterm,103,'img/next.png','',str(page+1))

                
                
                





               
                   
                
               
                   
                
        
def getmovies_100(name,url,page):##movies
               
               
                print "page",page
               
                if page>1:
                  
                      page_url=url[:-1]+str(page)
                  
                else:
                
                      page_url=url
                blocks=readnet(page_url,'id="moviePanel"','id="pageFooter"','class="panet-thumbnail">')
                
                i=0
               
                
               
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                               
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            href=baseurl+href
                            
                    except:
                            trace_error()
                            continue
                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                           
                            
                    except:
                            trace_error()
                            continue

                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    

                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>10:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                









###############################################series


def getseries_200(name,url,page):##series
                print "page",page
               
                if page>1:
                  
                      page_url=url[:-1]+str(page)
                  
                else:
                
                      page_url=url
                blocks=readnet(page_url,'id="categoryVideoPanel"','id="pageFooter"','class="panet-thumbnail"')
                
                i=0
               
                
               
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                               
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            href=baseurl+href
                            
                    except:
                            trace_error()
                            continue
                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                           
                            
                    except:
                            trace_error()
                            continue

                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    

                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>10:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))

                
                
                





                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return
                regx='''<div class="panel-body"> <a href="(.*?)"><span class="glyphicon glyphicon-triangle-right"></span>(.*?)</a>'''
                                                                           
                seasons=re.findall(regx,data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,1,'','',1)
                        

                                           
                                    


def getepisodes_202(name,url,page):##series


                print "page",page
               
                if page>1:
                  
                      page_url=url[:-1]+str(page)
                  
                else:
                
                      page_url=url
                blocks=readnet(page_url,'id="categoryVideoPanel"','id="pageFooter"','class="panet-thumbnail"')
                
                i=0
               
                
               
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                               
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            href=baseurl+href
                            
                    except:
                            trace_error()
                            continue
                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                           
                            
                    except:
                            trace_error()
                            continue

                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    

                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>10:
                    
                   addDir("next page",url,202,'img/next.png','',str(page+1))


               
                   
                
               

#######################################host resolving                                                    
                    

def getservers_1(name,url):
                data=readnet(url)
                
               
                
              
                if data is None:
                    return
                
                
                i=0
               

                regx='''<meta itemprop="contentURL" content="(.*?)".*?/>'''
                regx='''<meta itemprop="contentURL" content="(.*?)"'''
            
               
                href=re.findall(regx,data, re.M|re.I)[0]
                print "href",href
                addDir("direct link-"+name,href,0,'img/play.png',"",1,link=True)
               

                 
def resolve_host(surl):
       
       return

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers_1(name,url)
elif mode==2:
        print ""+url
        resolvehost(url)        
elif mode==3:
        print ""+url
        getservers_2(name,url)
elif mode==103:
        sterm = getsearchtext()      
         
        search_103("Search",sterm,page)         
###movies     
        
elif mode==100:
        print ""+url
        getmovies_100(name,url,page)

elif mode==101:
        print ""+url
        years_101()	

elif mode==102:
	print ""+url
	getA_Z_102('movies')
	

    
###series        


elif mode==200:

	getseries_200(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes_202(name,url,page)

   

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
