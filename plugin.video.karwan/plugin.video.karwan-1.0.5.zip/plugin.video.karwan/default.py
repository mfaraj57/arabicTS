# -*- coding: utf8 -*-


try:import sys,syspath
except:pass
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re

import requests

############################################

####functions

baseurl="http://karwan.tv"    
def readnet(url):
            
            return requests.get(url).content
      

              

               
                   
                
        
def getchannels(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                 
                  
                     url_page=urlmain+'/page'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
             
                
               
                if data is None:
                    return
               
                blocks=data.split('<a class="bt-title" target="_parent"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''href="(.*?)">(.*?)</a>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][1]
                    #/ronahi-tv.html"
                    href=match[0][0].replace(".html","")
                       
                    #href=baseurl+"/live"+href+href+".php"
                    href='http://karwan.tv/live'+href+".php"
                    if 'kurdmax-pepule' in href:
                        href=href.replace("-tv","")
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                   
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
                

                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    




def gethosts(name,urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
               
                
                match=re.findall("hls:.*?'(.*?)'",data, re.M|re.I)
                print "match",match
             
                if len(match)==0:
                   match=re.findall('image:.*?"(.*?)"',data, re.M|re.I)
                print "match",match
                if match[0]=='true':
                   match=re.findall('file:.*?"(.*?)"',data, re.M|re.I)
                playlink(match[0])
                return
                for href in match:
                      
                      
                    
                            
                     
                     addDir(name,href,3,'','',1,link=True)
                   
   

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param


	
def addDir(name,url,mode,iconimage,extra='',page=0,link=False):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        getchannels('Karwantv',baseurl,page)
        #showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
     
elif mode==3:
        print ""+url
        playlink(url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
