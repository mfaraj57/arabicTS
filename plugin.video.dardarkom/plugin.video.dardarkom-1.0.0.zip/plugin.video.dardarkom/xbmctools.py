# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/script.module.main/lib/xbmctools.py
import sys
import os
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import urllib
import urllib2
import ssl
import re
try:
    import requests
except:
    pass

try:fanart=__file__.split('xbmctools')[0]+'fanart.jpg'
except:fanart=''

if os.path.exists(fanart)==False:
    fanart=fanart.replace(".jpg","jpeg")

def downloadfile(url = None,basename=''):
    
    if url is None or url.strip() == '':
        return ''
    else:
        
        if os.name == 'nt':
            path = 'd:\\tmp'
        else:
            path = '/media/hdd'
        if url and url.startswith('http'):
            try:
                
                ofile = os.path.join(path, basename)
                
                r = f.get(url, timeout=0.5)
                if r.status_code == 200:
                    with open(ofile, 'wb') as f:
                        f.write(r.content)
                    f.close()
                    return ofile
            except:
                trace_error()

        return url
       
def get_youtube_link(value):
    """
    Examples:
    - http://youtu.be/SA2iWivDJiE
    - http://www.youtube.com/watch?v=_oPAwA_Udwc&feature=feedu
    - http://www.youtube.com/embed/SA2iWivDJiE
    - http://www.youtube.com/v/SA2iWivDJiE?version=3&amp;hl=en_US
    -'plugin://plugin.video.youtube/?action=play_video&amp;videoid=FBBLhRgrw0o'
    """
    from urlparse import urlparse
    vid=None
    if value is None:
        return None
    else:
        value = value.strip()
        if value.startswith('plugin://'):
           
            try:
                vid = value.split('=')[value.count('=')]
                
            except:
                return None
        else:
            query = urlparse(value)
            if query.hostname == 'youtu.be':
                vid= query.path[1:]
            elif query.hostname in ('www.youtube.com', 'youtube.com'):
                if query.path == '/watch':
                    p = parse_qs(query.query)
                    vid= p['v'][0]
                if query.path[:7] == '/embed/':
                    vid= query.path.split('/')[2]
                if query.path[:3] == '/v/':
                    vid=query.path.split('/')[2]
            
            
        return 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % vid

def decodeHtml(text):
    text = text.replace('&auml;', 'ae').replace('&Auml;', 'Ae').replace('&ouml;', 'oe').replace('&ouml;', 'Oe').replace('&uuml;', 'ue')
    text = text.replace('&Uuml;', 'Ue').replace('&szlig;', 'ss').replace('&amp;', '&').replace('&quot;', '"').replace('&gt;', "'")
    text = text.replace('&#228;', 'ae').replace('&#246;', 'oe').replace('&#252;', 'ue').replace('&#223;', 'ss').replace('&#8230;', '...')
    text = text.replace('&#8222;', ',').replace('&#8220;', "'").replace('&#8216;', "'").replace('&#8217;', "'").replace('&#8211;', '-')
    text = text.replace('&#8230;', '...').replace('&#8217;', "'").replace('&#128513;', ':-)').replace('&#8221;', '"')
    text = text.replace('&#038;', '&').replace('&#039;', "'")
    text = text.replace('\\u00c4', 'Ae').replace('\\u00e4;', 'ae').replace('\\u00d6', 'Oe').replace('\\u00f6', 'oe')
    text = text.replace('\\u00dc', 'Ue').replace('\\u00fc', 'ue').replace('\\u00df', 'ss')
    text = text.replace('&#196;', 'Ae').replace('&#228;', 'ae').replace('&#214;', 'Oe').replace('&#246;', 'oe').replace('&#220;', 'Ue').replace('&#252;', 'ue')
    text = text.replace('<br />\n', '')
    return text         
def getos():
    if __file__.startswith('/usr'):
        return 'enigma2'
    else:
        return 'windows'


def cleanparam(param):
    param = param.strip()
    param = param.replace('&#8211', '')
    param = param.replace('&#8', '')


def geturlbyreferal(url, referer):
    request2 = urllib2.Request(url)
    request2.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36')
    request2.add_header('Referer', referer)
    request2.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    request2.add_header('Accept-Language', 'de,en-US;q=0.7,en;q=0.3')
    response2 = urllib2.urlopen(request2)


def findalldata(data, marker1, marker2, index = 0, fdata = []):
    print 'fdata', fdata
    data = data[index:len(data)]
    idx1 = data.find(marker1)
    if -1 == idx1:
        return fdata
    idx2 = data.find(marker2, idx1 + len(marker1))
    if -1 == idx2:
        return fdata
    idx1 = idx1 + len(marker1)
    fdata.append(data[idx1:idx2])
    findalldata(data, marker1, marker2, idx2 + len(marker2), fdata)


def cfdownloadImage(url = None):
    if os.path.exists('/tmp/dimage') == False:
        return url
    elif url is None or url.strip() == '':
        return ''
    else:
        if 'ExQ' in url:
            url.replace('ExQ', '=')
        if os.name == 'nt':
            path = 'd:\\tmp'
        else:
            path = '/tmp/TSmedia'
        if url and url.startswith('http'):
            try:
                filename = url.split('/')[-1]
                ofile = os.path.join(path, filename)
                if os.path.exists(ofile):
                    return ofile
                try:
                    r = cfresolve(url)
                    with open(ofile, 'wb') as f:
                        f.write(r)
                    f.close()
                    return ofile
                except:
                    pass

            except:
                trace_error()

        return url
        return


def downloadImage(url = None):
    if os.path.exists('/tmp/dimage') == False:
        return url
    elif url is None or url.strip() == '':
        return ''
    else:
        if 'ExQ' in url:
            url.replace('ExQ', '=')
        if os.name == 'nt':
            path = 'd:\\tmp'
        else:
            path = '/tmp/TSmedia'
        if url and url.startswith('http'):
            try:
                filename = url.split('/')[-1]
                ofile = os.path.join(path, filename)
                if os.path.exists(ofile):
                    return ofile
                r = requests.get(url, timeout=0.5)
                if r.status_code == 200:
                    with open(ofile, 'wb') as f:
                        f.write(r.content)
                    f.close()
                    return ofile
            except:
                trace_error()

        return url
        return


def getitems(regx, data):
    items = re.findall(regx, data, re.M | re.I)
    return items


def finditem(text, from_string, to_string, excluding = True):
    import re
    import string
    if excluding:
        try:
            r = re.search('(?i)' + from_string + '([\\S\\s]+?)' + to_string, text).group(1)
        except:
            r = ''

    else:
        try:
            r = re.search('(?i)(' + from_string + '[\\S\\s]+?' + to_string + ')', text).group(1)
        except:
            r = ''

    return r


def finditems(text, start_with, end_with):
    import re
    r = re.findall('(?i)(' + start_with + '[\\S\\s]+?' + end_with + ')', text)
    return r


def removeunicode(data):
    try:
        try:
            data = data.encode('utf', 'ignore')
        except:
            pass

        data = data.decode('unicode_escape').encode('ascii', 'replace').replace('?', '').strip()
    except:
        pass

    return data


def readhttps(url):
    list1 = []
    try:
        req = urllib2.Request(url)
        try:
            response = urllib2.urlopen(req, context=ssl._create_unverified_context())
        except:
            response = urllib2.urlopen(req)

        data = response.read()
        response.close()
        return data
    except urllib2.URLError as e:
        trace_error()
        if hasattr(e, 'code'):
            print 'We failed with error code - %s.' % e.code
            if '401' in str(e.code):
                addDir('Error:invalid authorization,try login again', '', 104, 'error.png', '')
                return 'Error:invalid authorization,try login again'
            if '404' in str(e.code):
                addDir('Error:not found', '', 104, '', '')
                return 'Error:not found'
            if '400' in str(e.code):
                addDir('Error:invalid request/channel', '', 104, '', '')
                return 'Error:invalid request/channel'
            if '403' in str(e.code):
                addDir('Error:Forbidden request', '', 104, '', '')
                return 'Error:Forbidden request'
        elif hasattr(e, 'reason'):
            print 'We failed to reach a server.'
            print 'Reason: %s' % e.reason
        return 'Error:'


def requestsurl(url):
    try:
        import requests
        session = requests.Session()
        USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
        session.headers.update({'User-Agent': USER_AGENT})
        return session.get(url, verify=False).content
    except:
        trace_error()
        addDir('Error:Download error', '', 1, '', '', 1)
        return

    return


def readtrueurl(url):
    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
     'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
     'Accept-Encoding': 'none',
     'Accept-Language': 'en-US,en;q=0.8',
     'Connection': 'keep-alive'}
    req = urllib2.Request(url, headers=hdr)
    page = urllib2.urlopen(req)
    url = page.geturl()
    return url


def logdata(label_name = '', data = None):
    try:
        caller_name = getcaller_name()
        fp = open('/tmp/TSmedia/TSmedia_log2', 'a')
        fp.write('\n' + caller_name + ':' + str(label_name) + ': ' + str(data))
        fp.close()
    except:
        try:
            data = 'error in writing data to the log'
            fp = open('/tmp/TSmedia/TSmedia_log2', 'a')
            fp.write('\n' + label_name + ': ' + str(data))
            fp.close()
        except:
            print 'error in loging data'


def getcaller_name():
    try:
        import inspect
        import os
        frame = inspect.currentframe()
        frame = frame.f_back.f_back
        code = frame.f_code
        calling_module = os.path.basename(code.co_filename)
        return calling_module
    except:
        return ''


def trace_error():
    import sys
    import traceback
    traceback.print_exc(file=sys.stdout)
    if os.path.exists('/tmp/TSmedia'):
        logfile = '/tmp/TSmedia/TSmedia_log'
    else:
        logfile = os.path.dirname(__file__) + '/TSmedia_log'
    traceback.print_exc(file=open(logfile, 'a'))


def getData(url, data = {}, host = '', Referer = ''):
    import requests
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.get(url, headers=headers)
    htmldata = r.content
    return htmldata


def postData(url, data, host, Referer):
    import requests
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.post(url, headers=headers, data=data)
    htmldata = r.content
    return htmldata


def getItems(data, pattern, ignoreCase = False):
    if ignoreCase:
        match = re.findall(pattern, data, re.IGNORECASE)
    else:
        match = re.findall(pattern, data)
    return match


def getGroups(data, pattern, grupsNum = 1, ignoreCase = False):
    tab = []
    if ignoreCase:
        match = re.search(pattern, data, re.IGNORECASE)
    else:
        match = re.search(pattern, data)
    for idx in range(grupsNum):
        try:
            value = match.group(idx + 1)
        except:
            value = ''

        tab.append(value)

    return tab


def getBaseUrl(url):
    from urlparse import urlparse
    parsed_uri = urlparse(url)
    domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
    return domain


def readnet(url):
    return requestsurl(url)


def getnet(url):
    try:
        from addon.common.net import Net
        net = Net()
        USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
        MAX_TRIES = 3
        headers = {'User-Agent': USER_AGENT,
         'Referer': url}
        html = net.http_GET(url).content
        return html
    except:
        trace_error()
        return None

    return None


def postnet(url, data, referer):
    try:
        from addon.common.net import Net
        net = Net()
        USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
        MAX_TRIES = 3
        headers = {'User-Agent': USER_AGENT,
         'Referer': referer}
        html = net.http_POST(url, form_data=data, headers=headers).content
        return html
    except:
        trace_error()


def readurl(url):
    try:
        req = urllib2.Request(url)
        response = urllib2.urlopen(req)
        data = response.read()
        response.close()
        return data
    except urllib2.URLError as e:
        if hasattr(e, 'code'):
            print 'We failed with error code - %s.' % e.code
            addDir('Download failed:' + str(e.code), '', '', '', 1)
        elif hasattr(e, 'reason'):
            print 'We failed to reach a server.'
            print 'Reason: %s' % e.reason
            addDir('Download failed:' + str(e.reason), '', '', '', 1)


def trueUrl(site):
    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
     'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
     'Accept-Encoding': 'none',
     'Accept-Language': 'en-US,en;q=0.8',
     'Connection': 'keep-alive'}
    req = urllib2.Request(site, headers=hdr)
    page = urllib2.urlopen(req)
    url = page.geturl()
    return url


def readurlwithhost(url, host):
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Host', host)
        req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
        response = urllib2.urlopen(req)
        link = response.read()
        return link
    except Exception:
        addDir('Download failed:' + str(Exception), '', '', '', 1)


def getsearchtext(marker = '+'):
    keyboard = xbmc.Keyboard('', 'Search')
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText().replace(' ', marker)


def removebbcode(incomingString):
    try:
        import bbcode
        parser = bbcode.Parser()
        code = incomingString
        plain_txt = parser.strip(code)
        return plain_txt
    except:
        return incomingString


def supported(hostname):
    from tsresolver import supported
    return supported(hostname)


def resolvehost(url):
    from tsresolver import resolve
    stream_link = str(resolve(url))

    playlink(stream_link)


def cfresolve(url_page = None):
    if url_page:
        import cfscrape
        scraper = cfscrape.create_scraper()
        data = scraper.get(url_page).content
        return data


def parsedata(data, regx):
    try:
        match_list = re.findall(regx, data, re.M | re.I)
        return match_list
    except:
        return []


def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext


def getDomain(url):
    tmp = re.compile('//(.+?)/').findall(url)
    domain = 'server'
    if len(tmp) > 0:
        domain = tmp[0].replace('www.', '')
    if 'google' in domain:
        domain = 'google'
    if '.' in domain:
        domain = domain.split('.')[0]
    print 'server_url,server', url, domain
    return domain


def GetDomain(url):
    tmp = re.compile('//(.+?)/').findall(url)
    domain = 'server'
    if len(tmp) > 0:
        domain = tmp[0].replace('www.', '')
    if '.' in domain:
        domain = domain.split('.')[0]
    print 'server_url,server', url, domain
    return domain


def getwebfilesize(link):
    try:
        site = urllib.urlopen(link)
        meta = site.info()
        pagesize = int(float(meta.getheaders('Content-Length')[0]) / 1048576)
        return str(pagesize) + 'MB'
    except:
        return ''


def traceerror():
    import sys
    import traceback
    traceback.print_exc(file=sys.stdout)


def gethostname(url):
    try:
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        hostname = query.hostname
        hostname = hostname.replace('www.', '')
        hostname = hostname.replace('.com', '')
        hostname = hostname.replace('.net', '')
        if 'google' in hostname:
            hostname = 'google'
        if '.' in hostname:
            hostname = hostname.split('.')[0]
        return hostname
    except:
        return url


def finddata(data, marker1, marker2, withMarkers = False, caseSensitive = True):
    if caseSensitive:
        idx1 = data.find(marker1)
    else:
        idx1 = data.lower().find(marker1.lower())
    if -1 == idx1:
        return ''
    if caseSensitive:
        idx2 = data.find(marker2, idx1 + len(marker1))
    else:
        idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
    if -1 == idx2:
        return ''
    if withMarkers:
        idx2 = idx2 + len(marker2)
    else:
        idx1 = idx1 + len(marker1)
    return data[idx1:idx2]


class cParser:

    def parseSingleResult(self, sHtmlContent, sPattern):
        aMatches = re.compile(sPattern).findall(sHtmlContent)
        if len(aMatches) == 1:
            aMatches[0] = self.__replaceSpecialCharacters(aMatches[0])
            return (True, aMatches[0])
        return (False, aMatches)

    def __replaceSpecialCharacters(self, sString):
        return sString.replace('\\/', '/').replace('&amp;', '&').replace('\xc9', 'E').replace('&#8211;', '-').replace('&#038;', '&').replace('&rsquo;', "'").replace('\r', '').replace('\n', '').replace('\t', '').replace('&#039;', "'")

    def parse(self, sHtmlContent, sPattern, iMinFoundValue = 1):
        sHtmlContent = self.__replaceSpecialCharacters(str(sHtmlContent))
        aMatches = re.compile(sPattern, re.IGNORECASE).findall(sHtmlContent)
        if len(aMatches) >= iMinFoundValue:
            return (True, aMatches)
        return (False, aMatches)

    def replace(self, sPattern, sReplaceString, sValue):
        return re.sub(sPattern, sReplaceString, sValue)

    def escape(self, sValue):
        return re.escape(sValue)

    def getNumberFromString(self, sValue):
        sPattern = '\\d+'
        aMatches = re.findall(sPattern, sValue)
        if len(aMatches) > 0:
            return aMatches[0]
        return 0


def addDir(name, url, mode, iconimage, extra = '', page = 0, plugin = None, link = False, searchall = None, maintitle = False):
    spath = sys.argv[0]
    extra = str(extra)
    try:
        name = name.encode('utf-8', 'ingnore')
        cleanparam(name)
    except:
        pass

    if name is not None and maintitle == True:
        extra = 'maintitle'
    if plugin is not None:
        path = spath.replace('/default.py', '')
        spath = os.path.split(path)[0] + '/' + plugin + '/default.py'
        if not extra.strip() == '':
            u = url + '&extra=' + urllib.quote_plus(extra)
        else:
            u = url
    elif not extra.strip() == '':
        try:
            extra = extra.encode('utf-8', 'ingnore')
        except:
            pass

        u = spath + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&page=' + str(page) + '&extra=' + urllib.quote_plus(extra)
    elif link == True:
        u = url
        playlink(url)
        return
    else:
        u = spath + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&page=' + str(page)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name})
    
    liz.setProperty('fanart_image', fanart)
    
    if searchall is not None:
        try:
            dirname = os.path.split(searchall)[0]
            plugin_name = os.path.basename(dirname)
            search_file = searchall.replace('default.pyc', 'searchall').replace('default.pyo', 'searchall').replace('default.py', 'searchall')
            afile = open(search_file, 'w')
            afile.write(plugin_name + ';;' + u)
            afile.close()
        except:
            pass

    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


def playlink(url):

        xbmc.Player().play(url)

        sys.exit(0)
        return


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '&')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]

    return param
