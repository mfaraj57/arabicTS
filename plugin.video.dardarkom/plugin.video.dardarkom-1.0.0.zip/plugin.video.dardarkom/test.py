cmd="c:/python27/python.exe c:/uncompyle6/setup.py develop & pause"
import os
os.system(cmd)
