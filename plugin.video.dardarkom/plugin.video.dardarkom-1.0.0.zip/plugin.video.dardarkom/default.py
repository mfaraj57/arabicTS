# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,getnet,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error
################''
baseurl='http://dardarkom.com'

##########################################parsing tools


def showmenu():
        addDir('Search movies','http://www.dardarkom.com/index.php?do=search&subaction=search&story=',103,'img/1.png','',1)
        addDir('الافلام الاجنبيه','http://www.dardarkom.com/aflamonline/filme-gharbi/',100,'img/1.png','',1)
        addDir('المضاف حديثا','http://www.dardarkom.com/latest-movies/',100,'img/2.png','',1)
        addDir('أفلام فازت الاوسكار','http://www.dardarkom.com/oscar-winners/',100,'img/3.png','',1)        
        
        addDir('افلام مميزه','http://www.dardarkom.com/best-movies/',100,'img/4.png','',1)
        
        addDir('الافلام العربيه','http://www.dardarkom.com/aflamonline/filme-egypt/',100,'img/5.png','',1)   
        addDir('افلام انيمي','http://www.dardarkom.com/anime/',100,'img/6.png','',1)        
        addDir('افلام هندي','http://www.dardarkom.com/aflamonline/filme-gharbi/hindi-movies/',100,'img/7.png','',1)
        addDir('افلام اسيويه','http://www.dardarkom.com/watch-asian-movies-on-line/',100,'img/8.png','',1)
        addDir('افلام وثائقيه','http://www.dardarkom.com/documentary-films/',100,'img/9.png','',1) 
        
        #addDir('Search series','http://www.darshow.com/mosalsalat-ajnabi/index.php?do=search&subaction=search&story=prison',103,'img/1.png','',1)
        addDir('المسلسلات الاجنبيه','http://www.darshow.com/mosalsalat-ajnabi/',200,'img/10.png','',1)
	
        addDir('المسلسلات العربيه','http://www.darshow.com/arabic-series/',200,'img/11.png','',1)	
        #addDir('مسلسلات رمضان 2017','http://www.gdedak.com/series/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2017/',200,'img/5.png','',1)

       
        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        sitem = getsearchtext()      
         
        
          
        search_movies("Search",sitem,0)


def search_movies(namemain,sitem,page):##may pastte code of getmovies here


                print "page",page
                urlmain='http://www.dardarkom.com/index.php?do=search&subaction=search&search_start='+str(page+1)+'&full_search=0&result_from=25&story='+sitem
                #do=search&subaction=search&search_start=3&full_search=0&result_from=25&story=prison
                print "urlmian",urlmain
                #sys.exit(0)
                data=getnet(urlmain)
                                  
               
                if data is None:
                    return
                blocks=data.split('<div class="main-news-image">')
                i=0
                

                print "blocks",len(blocks)
              
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                    #regx='''<div class="movief">'''
                    regx='''<div class="main-news-title">
			<a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",sitem,104,'http://www.darkdaily.com/wp-content/uploads/Foward-Arrow.jpg','',str(page+1))                
               


               
                   
                
               
                   
                
        
def getmovies(name,urlmain,page):##movies
               
                print "page",page
               
                if page>1:
                  #/page/2/http://series4watch.com/english-movies/2/
                  #     
                  url_page=urlmain+str(page)+"/"
                  url_page=urlmain+'/page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                data=getnet(url_page)
                                  
               
                if data is None:
                    return
                blocks=data.split('<div class="main-news-image">')
                i=0
                

                print "blocks",len(blocks)
              
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                    #regx='''<div class="movief">'''
                    regx='''<div class="main-news-title">
			<a href=".*?">(.*?)</a>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,100,'http://www.darkdaily.com/wp-content/uploads/Foward-Arrow.jpg','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))











###############################################series


def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #/page/2/http://series4watch.com/english-movies/2/
                  #     
                  url_page=urlmain+str(page)+"/"
                  url_page=urlmain+'/page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                data=getnet(url_page)
                                  
               
                if data is None:
                    return
                blocks=data.split('class="shortmail"')
                i=0
                

                print "blocks",len(blocks)
              
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                    #regx='''<div class="movief">'''
                    regx='''<div class="title-shorts">(.*?)\s<div class="linecons">'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-4])[1]
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,201,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,200,'http://www.darkdaily.com/wp-content/uploads/Foward-Arrow.jpg','',str(page+1))                
                




                    
def getseasons(name,url_page,page):##series

                 

                data=getnet(url_page)
                                  
               
                if data is None:
                    return
                blocks=data.split('seasonsclass')
                i=0
                
                #http://on.darshow.com/mom-2014-s2/" class="seasonlinkclassa
                print "blocks",len(blocks)
                #sys.exit(0)
                if len(blocks)<2:
                        getepisodes2(name,url_page,page)
                        return
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''href="(.*?)"'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    
                    
                    regx='''class="seasonname">(.*?)</div>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-4])[1]
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,202,'','',1)
                    except:continue
                
                
                             
                

                        

def getepisodes2(name,url_page,page):#

                data=getnet(url_page)
                                  
                regx='''<a href="(.*?)" title=".*?" class="btn_showmore1"'''
                href=re.findall(regx,data, re.M|re.I)[0]
                print "href",href
                getepisodes(name,href,page)
                return
                
                                                           
                                    


def getepisodes(name,url_page,page):#

                data=getnet(url_page)
                                  
               
                if data is None:
                    return
                blocks=data.split('img-shortmain')
                i=0
                

                print "blocks",len(blocks)
              
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    
                    
                    regx='''dir="rtl">(.*?)</div>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-4])[1]
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,3,'','',1)
                    except:continue
                
                


#######################################host resolving                                                    
                    
def getservers_series(url):


        regx='''<iframe.*?src='(.*?)'.*?</iframe>'''
        data=getnet(url)
        match=re.findall(regx,data, re.M|re.I)
        for href in match:
                server=getDomain(href)
                addDir(server,href,2,'img/server.png')
                
        regx='''<iframe.*?src="(.*?)".*?</iframe>'''
        match=re.findall(regx,data, re.M|re.I)

        for href in match:
                server=getDomain(href)
                addDir(server,href,2,'img/server.png')        
def getserver(url):

      data=readnet(url)
      regx='''<iframe.*?src='(.*?)'.*?</iframe>'''
      href=None
      try:
        href=re.findall(regx,data, re.M|re.I)[0]
      except:
              regx='''<iframe.*?src="(.*?)".*?</iframe>'''
              try:
               href=re.findall(regx,data, re.M|re.I)[0]
              except:pass
      return href        

def getservers(name,urlmain):##cinema and tv featured
                data=readnet(urlmain)
                regx='''<a href="(.*?)" target="_blank" rel="nofollow">https://clicknupload.link'''
                regx='''<iframe.*?src="(.*?)" class="iframeresponsive".*?></iframe>'''
                regx='''<iframe.*?src="(.*?)".*?</iframe>'''
                
                match = re.findall(regx,data, re.M|re.I)
                #re.findall(regx,data, re.M|re.I)[0]
               
                i=0
                from xbmctools import getDomain
                for href in match:
                       
                        #data2=readnet(href)
                        #regx='''<iframe src='(.*?)'.*?></iframe'''
                        #try:href=re.findall(regx,data2, re.M|re.I)[0]
                        #except:pass
                        #server=getDomain(href)
                        if not 'darkom.video' in href:
                                continue
                        href=getserver(href)
                        if href is None or 'picla'in href or 'my' in href:
                            continue
                        server=getDomain(href)   
                        addDir(server,href,2,'img/server.png')
                regx='''<a href="(.*?)" target=".*?".*?</a>'''
                match = re.findall(regx,data, re.M|re.I)
                for href in match:
                    
                    if not 'darkom.video' in href:
                                continue
                    
                    href=getserver(href)
                    if href is None or 'picla'in href or 'my' in href:
                            continue
                    server=getDomain(href)    
                    addDir(server,href,2,'img/server.png')
                 
def resolve_host(url):
        resolve_host(url)    

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        resolvehost(url)        
elif mode==3:
        print ""+url
        getservers_series(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)

elif mode==104:
	print ""+url
        search_movies(name,url,page)        
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
