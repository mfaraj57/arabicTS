# -*- coding: utf8 -*-

try:import sys
except:pass
import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
from xbmctools import addDir,readnet,supported,get_params,resolvehost,readtrueurl,getDomain,parsedata,playlink,finddata


def read_url2(url):
    import requests
    return requests.get(url).content            
def read_url3(url):#redirect error
    import requests
    return requests.get(url).content     


def read_url(url):
    import requests
    return requests.get(url).content     

def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial

    return inner



def getCategories():
	addDir('Search','https://egy.best/explore/?q=',4,'img/0.jpg',1)
	

	addDir('••أحدث الاضافات••','http://egy.best/movies/latest',11,'img/1.jpg',1)
	addDir('••أفـــلام أجنبية••','http://egy.best/movies/',11,'img/9.jpg',1)
	addDir('••أفضل الافلام••','http://egy.best/movies/top',11,'img/7.jpg',1)
	addDir('••الاكثر شهرة••','http://egy.best/movies/popular',11,'img/8.jpg',1)
	addDir('••أفلام عربية••','https://egy.best/movies/arab',11,'img/12.jpg',1)	
	addDir('••مسلسلات أجنبية••','http://egy.best/tv/latest',100,'img/10.jpg',1)	
	addDir('HD','http://egy.best/movies/bluray',8,'img/2.jpg',1)
        addDir('••أفلام اسيوية••','https://egy.best/movies/japanese-korean-mandarin-chinese-cantonese-thai',11,'img/13.jpg',1)

        addDir('YEARS','url',45,'img/6.jpg',1)
	addDir('••بوليود••','http://egy.best/movies/hindi',11,'img/3.jpg',1)
        addDir('••أفلام أنمي أون لاين••','http://egy.best/movies/animation',9,'img/4.jpg',1)
        addDir('••أفــلام مصنفة••','url',5,'img/5.jpg',1)



       
               
def GENRES(url):
      	
	addDir('أفلام أكشن اون لاين','http://egy.best/movies/action',8,'img/1.jpg',1)
	addDir('افلام رعب اون لاين','http://egy.best/movies/horror',8,'img/2.jpg',1)
	addDir('افلام دراما اون لاين','http://egy.best/movies/drama',8,'img/3.jpg',1)
	addDir('افلام رومانسية اون لاين','http://egy.best/movies/crime',8,'img/9.jpg',1)
	addDir('افلام جريمة اون لاين','http://egy.best/movies/documentary',8,'img/12.jpg',1)
	addDir('••كـــومديـــا••','http://egy.best/movies/comedy',8,'img/6.jpg',1)

        setView('movies', 'MAIN')
        
def years(url):

        addDir('2017','http://egy.best/movies/2017',11,'img/8.jpg',1)        
        addDir('2016','http://egy.best/movies/2016',11,'img/1.jpg',1)        
        addDir('2015','http://egy.best/movies/2015',11,'img/2.jpg',1)      
        addDir('2014','http://egy.best/movies/2014',11,'img/3.jpg',1)
        addDir('2013','http://egy.best/movies/2013',11,'img/4.jpg',1)        
        addDir('2012','http://egy.best/movies/2012',11,'img/5.jpg',1)      
        addDir('2011','http://egy.best/movies/2011',11,'img/6.jpg',1)
        addDir('2010','http://egy.best/movies/2010',11,'img/3.jpg',1)        
        addDir('2009','http://egy.best/movies/2009',11,'img/2.jpg',1)      
        addDir('2008','http://egy.best/movies/2008',11,'img/1.jpg',1)
        addDir('2007','http://egy.best/movies/2007',11,'img/5.jpg',1)        
        addDir('2006','http://egy.best/movies/2006',11,'img/3.jpg',1)      
        addDir('2005','http://egy.best/movies/2005',11,'img/4.jpg',1)

        setView('movies', 'MAIN')
        
      
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url=url+search_entered+"/"
        print "mfarajx4_url",url
          
        getVideos("Search",url,1)        
        
        
        
def getVideos(name1, urlmain,page):
               if page>1:
                  #http://egy.best/movies/2/
                  url_page=urlmain+"?page="+str(page)
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               regx='''<a href="(.*?)" class="movie">\s*<img src="(.*?)">\s*<span class="title">(.*?)</span>'''              
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title  in match:
                        pic = ''
 
                        url=href
                        if not image.startswith("http:"):
                                image="http:"+image
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,2, image)
                       
               
               addDir('next page>',urlmain, 11,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))


              

        
def getblock(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>0 :
                  
                  
                  url_page="http://egy.best/hd-movies/?page="+str(page)
                  url_page=urlmain+"?page="+str(page)

               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
                   
               regx='''<a href="(.*?)">\s*<img .*? src="(.*?)".*?alt="(.*?)".*?/> '''              
               regx='''<a href="(.*?)" class="movie">\s*<img src="(.*?)">\s*<span class="title">(.*?)</span>'''              
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
                        if not image.startswith("http:"):
                                image="http:"+image 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        Etitle=title.replace("فيلم","")
                        #try:name=name.decode('unicode_escape').encode('ascii','ignore')
                        #except:pass
                        addDir(name,url,2, image,page)
               
               addDir('next page>',urlmain, 8,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))
def getyear(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                  
                  
                  url_page='http://egy.best/hd-movies/2016/?page='+str(page)
                  url_page=urlmain+"/"+"/"+'?page='+str(page)
                  url_page='http://egy.best/movies/'+"/"+'?page='+str(page)
                  
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
                   
               regx='''<a href="(.*?)">\s*<img .*? src="(.*?)".*?alt="(.*?)".*?/> '''              
               regx='''<a href="(.*?)" class="movie">\s*<img src="(.*?)">\s*<span class="title">(.*?)</span>'''              
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
                        if not image.startswith("http:"):
                                image="http:"+image 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        Etitle=title.replace("فيلم","")
                        #try:name=name.decode('unicode_escape').encode('ascii','ignore')
                        #except:pass
                        addDir(name,url,2,image,page)
               
               addDir('next page>',urlmain,44,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))


def getanime(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>0 :
                  
                  
                  url_page="http://egy.best/hd-movies/animation/?page="+str(page)
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
                   
               regx='''<a href="(.*?)">\s*<img .*? src="(.*?)".*?alt="(.*?)".*?/> '''              
               regx='''<a href="(.*?)" class="movie">\s*<img src="(.*?)">\s*<span class="title">(.*?)</span>'''              
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
                        if not image.startswith("http:"):
                                image="http:"+image  
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        Etitle=title.replace("فيلم","")
                        #try:name=name.decode('unicode_escape').encode('ascii','ignore')
                        #except:pass
                        addDir(name,url,2, image,page)
               
               addDir('next page>',urlmain, 9,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))
              

def getVideosTV(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                  
                  url_page=urlmain+'/page/'+str(page)
                  
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
             
               regx='''<p class="link"><a href="(.*?)"><p style=".*?">(.*?)</p>'''
               regx='''<a href="(.*?)">\s*<img .*? src="(.*?)" class="attachment-col wp-post-image" alt="(.*?)" /></a>'''
	       regx='''<a href="(.*?)">\s*<img .*? src="(.*?)" class="attachment-col wp-post-image" alt="(.*?)" />'''    			    
               regx='''<a href="(.*?)">\s*<img .*? src="(.*?)" class="attachment-col size-col wp-post-image" alt="(.*?)" .*?/>'''  
               regx='''<div class="img">\s*<a href="(.*?)" title="(.*?)">\s*<img src="(.*?)">'''  
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
 
                        
                      
                        url=href
                        #url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        #title=title.replace("فيلم","")
                        ##try:name=name.decode('unicode_escape').encode('ascii','ignore')
                        #except:pass
                        addDir(name,url,2, image)
                        
               
               
               
               addDir("next page",urlmain,12,'http://www.tachyonpunch.com/comics/images/next_icon.png',str(page+1))
               
               
               
def getTV(name1, urlmain,page):
               
               if page>1:
                  #http://egy.best/movies/2/
                  url_page=urlmain+"?page="+str(page)
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               regx='''<a href="(.*?)" class="movie">\s*<img src="(.*?)">\s*<span class="title">(.*?)</span>'''              
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title  in match:
                        pic = ''
 
                        url=href
                        if not image.startswith("http:"):
                                image="http:"+image
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,120, image)
                       
               
               addDir('next page>',urlmain,100,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))

def getseason(name1, urlmain,page):
               
               if page>1:
                  #http://egy.best/movies/2/
                  url_page=urlmain+"?page="+str(page)
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               regx='''<a href="(.*?)" class="movie">\s*<img src="(.*?)">\s*<span class="title">(.*?)</span>'''              
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title  in match:
                        pic = ''
 
                        url=href
                        if not image.startswith("http:"):
                                image="http:"+image
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,13, image)
                       
               
               addDir('next page>',urlmain,120,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))


              

               
def getVideosEpisodes(name1, urlmain,page):
               if page>1:
                  #http://egy.best/movies/2/
                  url_page=urlmain+"?page="+str(page)
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               regx='''<a href="(.*?)" class="movie tvep">\s*<img src="(.*?)">\s*<span class="title">(.*?)</span>'''   
                          
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title  in match:
                        pic = ''
 
                        url=href
                        if not image.startswith("http:"):
                                image="http:"+image
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,2, image)
                       
               
               #addDir("next page",urlmain,12,'',str(page+1))




def getmatch(match):
                if len(match)<1:
                        return False
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    #resolve_host(href)
                    #return True
                    addDir(server,href,7,'img/server.png')
            		
def get_servers(url):
	        data=read_url(url)
                regx='''<a href="(.*?)" class=".*?" target="_blank">'''
                regx='''<a data-url="(.*?)".*?>'''
                match = re.findall(regx,data, re.M|re.I)
                print "match",match
                
                for href in match:
                        href='https://egy.best'+href
                        href=readtrueurl(href)
                        server=getDomain(href)
                        addDir(server,href,7,'img/server.png')
                
            



                   

def resolve_host(url):

      import urlresolver
      stream_link = urlresolver.resolve(url)
      print "stream_link",stream_link
      
      if stream_link is None or "unresolvable" in stream_link:
            addDir("Error:unresolvable link","",1,"",1)
            return
      playlink(stream_link)


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	


def addDir(name,url,mode,iconimage,page=1):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def playlink(url):
            xbmc.Player().play(url)
            sys.exit(0)

              
params=get_params()
url=None
name=None
mode=None
initial=None
max=None
rating=None
cast=None
year=None
genre=None
duration=None
writer=None
director=None

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
	
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        page=1


		


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
if mode==None or url==None or len(url)<1:
        print ""
        getCategories()
       
elif mode==1:
        print ""+url
        getVideos(name,url,page)
elif mode==11:
        print ""+url
        getVideos(name,url,page)
        
  
elif mode==8:
        print ""+url        
        getblock(name,url,page)
        
elif mode==9:
        print ""+url        
        getanime(name,url,page)        
elif mode==12:
        print ""+url
        getVideosTV(name,url,page)
elif mode==100:
        print ""+url
        
        getTV(name,url,page)
        
elif mode==120:
        print ""+url
        
        getseason(name,url,page)        
elif mode==13:
        print ""+url
        getVideosEpisodes(name,url,page)   
                        
                
elif mode==2:
        print ""+url
        get_servers(url)
        
elif mode==4:
        print ""+url
        search(url)
elif mode==44:
        print ""+url

        getyear(name,url,page)   
elif mode==45:
        print ""+url
        
        years(url)
                        
elif mode==5:
        print ""+url        
        
        GENRES(url)
        

elif mode==6:
        print ""+url
        get_hostlink(url)
elif mode==7:
        resolvehost(url)
        
elif mode==3:
        print ""+url
        playlink(url)       
xbmcplugin.endOfDirectory(int(sys.argv[1]))
