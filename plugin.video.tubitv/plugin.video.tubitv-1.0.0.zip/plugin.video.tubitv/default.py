# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os,json
from xbmctools import addDir,readnet,supported,get_params,getnet,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error
################''
baseurl='https://tubitv.com'

##########################################parsing tools


def showmenu():
        addDir('Search','https://tubitv.com/oz/search/query/groups',103,'img/search.jpg','',1)
        addDir('Featured','https://tubitv.com/oz/containers/action/content?cursor=0&limit=30',100,'img/1.jpg','',1)
        addDir('most_popular','https://tubitv.com/oz/containers/most_popular/content?cursor=0&limit=30',100,'img/2.jpg','',1)
        addDir('Action','https://tubitv.com/oz/containers/action/content?cursor=0&limit=30',100,'img/3.jpg','',1)
        addDir('comedy','https://tubitv.com/oz/containers/comedy/content?cursor=0&limit=30',100,'img/4.jpg','',1)
        addDir('thrillers','https://tubitv.com/oz/containers/thrillers/content?cursor=0&limit=30',100,'img/5.jpg','',1)
        addDir('family_movies','https://tubitv.com/oz/containers/family_movies/content?cursor=0&limit=30',100,'img/6.jpg','',1)

        addDir('kids_shows','https://tubitv.com/oz/containers/kids_shows/content?cursor=0&limit=30',100,'img/7.jpg','',1)

        addDir('black_cinema','https://tubitv.com/oz/containers/black_cinema/content?cursor=0&limit=30',100,'img/8.jpg','',1)
        addDir('romance','https://tubitv.com/oz/containers/romance/content?cursor=0&limit=30',100,'img/9.jpg','',1)
        addDir('sci_fi_and_fantasy','https://tubitv.com/oz/containers/sci_fi_and_fantasy/content?cursor=0&limit=30',100,'img/10.jpg','',1)
        addDir('documentary','https://tubitv.com/oz/containers/documentary/content?cursor=0&limit=30',100,'img/11.jpg','',1)
        addDir('tv_dramas','https://tubitv.com/oz/containers/tv_dramas/content?cursor=0&limit=30',200,'img/12.jpg','',1)
        addDir('tv_comedies','https://tubitv.com/oz/containers/tv_comedies/content?cursor=0&limit=30',200,'img/13.jpg','',1)
        addDir('reality_tv','https://tubitv.com/oz/containers/reality_tv/content?cursor=0&limit=30',200,'img/14.jpg','',1)
        addDir('classics','https://tubitv.com/oz/containers/classics/content?cursor=0&limit=30',200,'img/15.jpg','',1)
        addDir('crime_tv','https://tubitv.com/oz/containers/crime_tv/content?cursor=0&limit=30',200,'img/16.jpg','',1)
        addDir('foreign_favorites','https://tubitv.com/oz/containers/foreign_favorites/content?cursor=0&limit=30',100,'img/17.jpg','',1)
        addDir('special_interest','https://tubitv.com/oz/containers/special_interest/content?cursor=0&limit=30',100,'img/18.jpg','',1)
        addDir('stand_up_comedy','https://tubitv.com/oz/containers/stand_up_comedy/content?cursor=0&limit=30',100,'img/19.jpg','',1)
        addDir('martial_arts','https://tubitv.com/oz/containers/martial_arts/content?cursor=0&limit=30',100,'img/20.jpg','',1)
        addDir('docuseries','https://tubitv.com/oz/containers/docuseries/content?cursor=0&limit=30',100,'img/21.jpg','',1)
        addDir('cult_favorites','https://tubitv.com/oz/containers/cult_favorites/content?cursor=0&limit=30',100,'img/22.jpg','',1)
        addDir('clips','https://tubitv.com/oz/containers/clips/content?cursor=0&limit=30',100,'img/23.jpg','',1)
        addDir('indie_films','https://tubitv.com/oz/containers/indie_films/content?cursor=0&limit=30',100,'img/24.jpg','',1)
        addDir('preschool','https://tubitv.com/oz/containers/preschool/content?cursor=0&limit=30',100,'img/25.jpg','',1)
        return















        
	
                             
        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        searchkey = getsearchtext()      
         
        url= url.replace("query",searchkey)
          
        getmovies("Search",url,1)





               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                    
                        #https://tubitv.com/oz/containers/action/content?cursor=0&limit=30
                        page_url='https://tubitv.com/oz/containers/action/content?cursor='+str((page-1)*30)+'&limit=30'
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
                jdata= json.loads(data)
                #print "jdata",jdata['contents']
                
                for item in jdata.get('contents', {}):
                        id=item
                        title= jdata['contents'][id]['title']
                        img="http:"+jdata['contents'][id]["thumbnails"][0].replace('ExQ','=')
                        
                        extra=jdata['contents'][id]['description']
                        year=jdata['contents'][id]['year']
                        if True:
                              addDir(title+"_"+str(year),id,1,img,extra.encode("utf-8","ignore"),1,maintitle=True)
                        else:
                                    trace_error(0)
                                    continue
                addDir("next page",url,100,'img/next.jpg','',str(page+1))
                return
                if data is None:
                    return
               
                
               
                blocks=data.split('"has_subtitle"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''"id":"(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''"title":"(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''"thumbnails":["(.*?)"]'''                    
                                          
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    mode=1
                    
                    try:
                      addDir(title,href,mode,'','',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>50:
                    
                   addDir("next page",url,100,'img/next.jpg','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))












###############################################series


def getseries(name,url,page):##series
                if page>1:
                    
                        #https://tubitv.com/oz/containers/action/content?cursor=0&limit=30
                        page_url='https://tubitv.com/oz/containers/action/content?cursor='+str((page-1)*30)+'&limit=30'
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=readnet(page_url)           
                
                
                jdata= json.loads(data)
                #print "jdata",jdata['contents']
                
                for item in jdata.get('contents', {}):
                        id=item
                        title= item[id]['title']
                        img="http:"+jdata['contents'][id]["thumbnails"][0].replace('ExQ','=')
                        
                        extra=jdata['contents'][id]['description']
                        year=jdata['contents'][id]['year']
                        href="https://tubitv.com/oz/videos/"+str(id)+"/content"
                        if True:
                              addDir(title+"_"+str(year),href,202,img,extra.encode("utf-8","ignore"),1,maintitle=True)
                        else:
                                    trace_error(0)
                                    continue
                addDir("next page",url,200,'img/next.png','',str(page+1))
                return
               



                    

def getepisodes(name,url,page):##series

                if page>1:
                    
                        #https://tubitv.com/oz/containers/action/content?cursor=0&limit=30
                        page_url='https://tubitv.com/oz/containers/action/content?cursor='+str((page-1)*30)+'&limit=30'
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=readnet(page_url)           
                
                
                jdata= json.loads(data)
                
                for item in jdata.get('children', {}):
                    for i in range(0,len(item['children'])):
                        url="http:"+item['children'][i]['url']
                        name="episode"+str(i+1)
                        addDir(name,url,0,'','',1,link=True)
                    
                    
                    
                return
               
                
               
                


#######################################host resolving                                                    
                    

def getservers(name,url):
        import requests
        import re
        import json
        #More than 7000 Movies/Tv Show Exclusive For TSMedia
        #Service 100% Free 100% legal
        s = requests.Session()

        headers = {
            'Host': 'tubitv.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
            'Accept': 'Accept: */*',
            'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
            'Content-Type': 'application/json',
            'Referer': 'https://tubitv.com/login',
            'Connection': 'keep-alive'}

        #The web site is 100% free but when you load page without login some movies are free just by login !
        #so we make it by default login from the begin to get all !!
        #data ={"username":"","password":"","rememberMe": "true"}
        #r=s.post('https://tubitv.com/oz/auth/login/', headers=headers, json=data)
        #htmldata= r.content

        #After Parse movies from main page or category each link have the movie id as Exp :
        #https://tubitv.com/movies/364438/criticsized
        #For posters because you need it at begin not at end you can parse them too from html
        movieid=url

        #Direct API Call for Full info , Stream url , poster,...
        rd = s.get('https://tubitv.com/oz/videos/'+movieid+'/content')

        htmldata   = rd.content
        
        
        TargetURL = json.loads(htmldata)
        Stream_Name = TargetURL['title']
        Stream_URL = 'http://'+TargetURL['url']
        #Poster_URL ='http:'+ (TargetURL['posterarts'])
        print "Movie: "+Stream_Name
        print "Stream Url: "+Stream_URL
        addDir("Play",Stream_URL.replace("http://","https:"),0,"","",1,link=True)

                 
def resolve_host(url):
        resolve_host(url)    

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        resolvehost(url)        
elif mode==3:
        print ""+url
        playlink(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
