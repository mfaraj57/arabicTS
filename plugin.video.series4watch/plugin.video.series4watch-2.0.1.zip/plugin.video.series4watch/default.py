# -*- coding: utf8 -*-
try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
import urllib2,urllib
import re
import httplib
import time,itertools

__settings__ = xbmcaddon.Addon(id='plugin.video.series4watch')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = (sys.argv[0])
baseurl='http://www.series4watch.com/'
def read_url2(url):
        try:
            req = urllib2.Request(url)
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
            return data
        except urllib2.URLError, e:
            print 'URL: '+url
            if hasattr(e, 'code'):
                print 'We failed with error code - %s.' % e.code
                #xbmc.executebuiltin("XBMC.Notification(musichcannels,We failed with error code - "+str(e.code)+",10000,"+icon+")")
            elif hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: %s' %e.reason
                #xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")
def read_url3(url):#redirect error
        try:


           p = urllib2.build_opener(urllib2.HTTPCookieProcessor).open(url)

           return p.read()
        except:
                addDir("Download failed:","","",'')
                #xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")                
                return None


def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.series4watch.com')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link

def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial

    return inner

def getCategories():

        
        addDir('Search','http://www.series4watch.com/?s=',3,'IMG/0.png',1)
	addDir('••أخــر الاضافات••','http://www.series4watch.com/',22,'IMG/1.png',1)
        addDir('هـــوليود','http://www.series4watch.com/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9-%D8%A3%D9%88%D9%86-%D9%84%D8%A7%D9%8A%D9%86/',11,'IMG/2.png',1)
       	addDir('YEAR','url',155,'IMG/7.png',1)

        addDir('مسلسلات أجنبية','http://www.series4watch.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a3%d8%ac%d9%86%d8%a8%d9%8a%d8%a9-%d9%85%d9%85%d9%8a%d8%b2%d8%a9/',11,'IMG/3.png',1)
	addDir('أفلام عربي','http://www.series4watch.com/category/%d8%a3%d9%81%d9%84%d8%a7%d9%85-%d8%b9%d8%b1%d8%a8%d9%8a%d8%a9-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/',11,'IMG/4.png',1)
	addDir('مسلسلات رمضان 2016','http://www.series4watch.com/series/ramadan-2016/',11,'IMG/5.png',1)

	addDir('بــوليود','http://www.series4watch.com/category/%d8%a3%d9%81%d9%84%d8%a7%d9%85-%d9%87%d9%86%d8%af%d9%8a/',11,'IMG/6.png',1)

	addDir('افلام اسيوية','http://www.series4watch.com/type/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%b3%d9%8a%d9%88%d9%8a%d8%a9/',11,'IMG/10.png',1)
	addDir('أفلام تركي اون لاين','http://www.series4watch.com/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%AA%D8%B1%D9%83%D9%8A-%D8%A7%D9%88%D9%86-%D9%84%D8%A7%D9%8A%D9%86/',11,'IMG/12.png',1)

	addDir('أفلام أنميشن','http://www.series4watch.com/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A3%D9%86%D9%85%D9%8A%D8%B4%D9%86/',11,'IMG/11.png',1)
	addDir('برامج تليفزيونية','http://www.series4watch.com/category/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%AA%D9%84%D9%8A%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D8%A9/',11,'IMG/8.png',1)

	addDir('المصــارعة','http://www.series4watch.com/category/%d9%85%d8%b5%d8%a7%d8%b1%d8%b9%d8%a9-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/',11,'IMG/9.png',1)


def years(url):
	addDir('2016','http://www.series4watch.com/year/2016/',11,'IMG/1.png',1)
        addDir('2015','http://www.series4watch.com/year/2015/',12,'IMG/2.png',1)
        addDir('2014','http://www.series4watch.com/year/2014/',12,'IMG/3.png',1)
        addDir('2013','http://www.series4watch.com/year/2013/',12,'IMG/6.png',1)
       	addDir('2012','http://www.series4watch.com/year/2012/',12,'IMG/7.png',1)
        addDir('2011','http://www.series4watch.com/year/2011/',12,'IMG/1.png',1)
        addDir('2010','http://www.series4watch.com/year/2010/',12,'IMG/2.png',1)
        addDir('2009','http://www.series4watch.com/year/2009/',12,'IMG/6.png',1)
       	addDir('2008','http://www.series4watch.com/year/2008/',12,'IMG/3.png',1)
        addDir('2007','http://www.series4watch.com/year/2007/',12,'IMG/7.png',1)
        addDir('2006','http://www.series4watch.com/year/2006/',12,'IMG/1.png',1)
        addDir('2005','http://www.series4watch.com/year/2005/',12,'IMG/2.png',1)

        setView('movies', 'MAIN')
     
      
def search():
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url="http://www.series4watch.com/?s="+search_entered
        print "mfarajx4_url",url
          
        getVideos("Search",url,1)
        



              
                                   
def getVideos(name1, urlmain,page):
               if page>1:
                  #page-2
                  url_page=urlmain+'/page/'+str(page)
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               try:data=content.split('class="title-news"')[1]
               except:pass
               
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               
             
               blocks=data.split('class="block_loop"')
               i=0

               for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                   # print "block",block
                    regx='''<a href="(.*?)" title="(.*?)">'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    
                    
                    name=match[0][1]
                    href=match[0][0]
                   
                    
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    addDir(name,href,2,img,1)
                    print "next",i
                    
                    
               
                   
                
               
               addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png',str(page+1))
               if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))               
                                   
def shows(name1, urlmain,page):
               if page>1:
                  #page-2
                  #http://www.series4watch.com/filme/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A3%D8%AC%D9%86%D8%A8%D9%8A-%D8%A3%D9%88%D9%86-%D9%84%D8%A7%D9%8A%D9%86/page/3/
                  url_page=urlmain+'"/"/page/'+str(page)+"/"
                  url_page=urlmain+'"/""/"/page/'+str(page)
                  url_page=urlmain+'/page/'+'/page/'+str(page)
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'?page'+str(page)
                  #url_page=urlmain+'?/page/'+'/str(page)/'
              
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               
               #regx=''' <a href="(.*?)" .*? >\s*<img .*? src="(.*?)" .*? alt="(.*?)"/>'''
               regx='''<a href="(.*?)" title="(.*?)">\s*<img.*?src="(.*?)" class='''#"attachment-w_224x328 wp-post-image" alt="Rush 2013_1" /><h1 class="title_loop">مشاهدة وتحميل فيلم Rush 2013 مترجم اون لاين وتحميل مباشر</h1> </a></div><div '''
               regx='''<a href="(.*?)" title="(.*?)">\s*<img .*?src="(.*?)".*?/>'''
               regx='''<div class="block_loop">\s*<a href="(.*?)" title="(.*?)">\s*<img .*?src="(.*?)".*?/>'''
               regx='''<div class="block_loop">\s*<a href="(.*?)" .*?>\s*<div class=".*?"></div>\s*<h1 class=".*?">(.*?)</h1>\s*<img data-src="(.*?)" src=".*?">''' 
               
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,title ,image in match:
                        pic = ''
 
                        url=href
                        
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,2, image)
                        
               addDir("next page",urlmain,22,'http://www.tachyonpunch.com/comics/images/next_icon.png',str(page+1))               
               
               
               
            
        
def getVideosTV(name1, urlmain,page):
               if page>1:
                  #page-2
                  url_page=urlmain+'?page/'+str(page)
                  url_page=urlmain+'"/""/"/page/'+str(page)
                  url_page=urlmain+'/page/'+str(page)
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               
               #regx=''' <a href="(.*?)" .*? >\s*<img .*? src="(.*?)" .*? alt="(.*?)"/>'''
               regx='''<a href="(.*?)" title="(.*?)">\s*<img.*?src="(.*?)" class='''#"attachment-w_224x328 wp-post-image" alt="Rush 2013_1" /><h1 class="title_loop">مشاهدة وتحميل فيلم Rush 2013 مترجم اون لاين وتحميل مباشر</h1> </a></div><div '''
               regx='''<div class="block_loop">\s*<a href="(.*?)" title="(.*?)">\s*<img .*?src="(.*?)".*?>'''         	
               regx='''<a href="(.*?)" .*?>\s*<div class=".*?"></div>\s*<h1 class=".*?">(.*?)</h1>\s*<img .*? src="(.*?)" .*? /> ''' 
                    
               #regx='''<div class="block_loop">\s*<a href="(.*?)" .*?>\s*<img src="(.*?)" />\s*<h1 class="title_loop">(.*?)</h1> ''' 
		    	
		       
                 
            
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,title ,image in match:
                        pic = ''
 
                        url=href
                        
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,2, image)
                        
               
               
               
               addDir("next page",urlmain,12,'http://www.tachyonpunch.com/comics/images/next_icon.png',str(page+1))
def getVideosEpisodes(name1, urlmain,page):
               if page>1:
                  url_page=urlmain+'page/'+str(page)+"/"
              
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return                      

               regx='''<div class="block_loop">\s*<a href="(.*?)">\s*<img .*? src="(.*?)".*? alt="(.*?)" srcset=''' 
               
	     	
               
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        #title=title.replace("فيلم","")
                        try:name=name.decode('unicode_escape').encode('ascii','ignore')
                        except:pass


                        addDir(name,url,30, image)
                        







               
def getmatch(match):
                if len(match)<1:
                        return False
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    resolve_host(href)
                    return True
                    addDir(server,href,7,'')
            		

def get_servers(url):
        data=read_url(url)
        #http://www.series4watch.com/wp-content/themes/series4watch/server1.php?server=1&p=24927
        
        regx="rel='shortlink' href='(.+?)'"
        idm = re.findall(regx,data, re.M|re.I)[0].split("=")[1].strip()
        print "id",int(idm)
        for i in range(1,11):

          url='http://www.series4watch.com/wp-content/themes/series4watch/server1.php?server='+str(i)+'&p='+str(idm)
                                                                             
          
          print 'url3',url
         
          addDir('server'+str(i),url,4, 'IMG/3.jpg')

def get_servers2(url):
		data=read_url(url)
                #data=read_url3(url)
                print data
                regx='''</span><a href='(.+?)' class='redirect_link'>'''
                regx1='''<IFRAME SRC="(.+?)" .+?></IFRAME>'''
                regx2='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx3='''class="tabcontent"><iframe.+?src='(.+?)'.+?></iframe></div>'''
                regx4='''<param name="movie" value="(.+?)" ></param>'''
                regx5='''<IFRAME SRC="(.+?)" FRAMEBORDER=0 MARGINWIDTH=.+?></IFRAME>'''
                #regx5='''<IFRAME SRC="(.+?)" FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO allowfullscreen="true"  WIDTH=100% HEIGHT=100%></IFRAME>'''
                match1 = re.findall(regx1,data, re.M|re.I)
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                match5 = re.findall(regx5,data, re.M|re.I)
                result=getmatch(match1)
                if result:
                        return
                result=getmatch(match2)
                if result:
                        return                
                result=getmatch(match3)
                if result:
                        return                
                result=getmatch(match4)
                if result:
                        return                
                result=getmatch(match5)
                if result:
                        return
                else:
                        addDir("Error:unresolvable link","",1,"",1) 
                        
                        
                        
                        
                        
                        

def resolve_host(url):

    
       

      import urlresolver
    #hosted_media = urlresolver.HostedMediaFile(url=url, title="host")
      stream_link = urlresolver.resolve(url)
      print "stream_link",stream_link
      if stream_link is None or "unresolvable" in stream_link:
            addDir("Error:unresolvable link","",1,"",1)
            return
        
      xbmc.Player().play(stream_link)
      sys.exit(0)
def get_hostlink(url):
	        data=read_url2(url)
                
		
                regx='''<iframe src="(.+?)" width='''
                match = re.findall(regx,data, re.M|re.I)
                print 'match-mfaraj',match,url
                if len(match)<1:
                        regx="'proxy.link'.+?'(.+?)'"
                        match = re.findall(regx,data, re.M|re.I)
                        print 'match-mfaraj2',match,url
                        
                i=0
                for href in match:
                    
     
                    i=i+1
                    server='link1'+str(i)
                    addLink(server,href,7,'')

def resolve_youwatch(url):
		print 'youwatch data'
		from packer import unpack, detect
		data=read_url2(url)
		get_packedjava = re.search("<script type=.text.javascript.>(eval.function.*?)</script>", data, re.S|re.DOTALL)
#		print get_packedjava.group(1)
		if get_packedjava and detect(get_packedjava.group(1)):
			print 'get_packedjava'
			sJavascript = get_packedjava.group(1)
			sUnpacked = unpack(sJavascript)
			if sUnpacked:
				print "unpacked"
#				print sUnpacked
				stream_url = re.search('file:"(.*?)"', sUnpacked, re.S)
				if stream_url:
					link= stream_url.group(1)
					return link
					

		print "no valic stream link found"
                return None    
def resolve_vk(url):
        web_url =url
        print "45m",web_url
        debug=True
        from addon.common.net import Net
        import json as json
        net = Net()
        try:
            soup   = net.http_GET(web_url).content
            html   = soup.decode('cp1251')
            print "html",html
            vars_s = re.findall("""var vars = (.+)""",html)
            if vars_s :
                jsonvars        = json.loads(vars_s[0])
                purged_jsonvars = {}
                for item in jsonvars :
                    if re.search('url[0-9]+', str(item)) :
                        purged_jsonvars[item] = jsonvars[item]               
                lines  = []
                ls_url = []
                for item in purged_jsonvars :
                    ls_url.append(item)
                    quality = item.lstrip('url')
                    lines.append(str(quality))
                if len(ls_url) == 1 :
                    return purged_jsonvars[ls_url[0]].encode('utf-8')
                result =1# xbmcgui.Dialog().select('Choose the link', lines)
                if result != -1 :
                    return purged_jsonvars[ls_url[result]].encode('utf-8')
                else :
                    return None
            else :
                return "No links found"
        except urllib2.URLError, e:
            
            print 'Error','Http error: '+str(e)
            
        except Exception, e:
            print '**** VK Error occured: %s' % e

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	


def addDir(name,url,mode,iconimage,page=1):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok



              
params=get_params()
url=None
name=None
mode=None
initial=None
max=None
rating=None
cast=None
year=None
genre=None
duration=None
writer=None
director=None

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
	
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        page=1


		


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
if mode==None or url==None or len(url)<1:
        print ""
        getCategories()
       
elif mode==1:
        print ""+url
        getVideos(name,url,page)
elif mode==11:
        print ""+url
        getVideos(name,url,page)
elif mode==22:
        print ""+url        
        
        shows(name,url,page)
        
elif mode==23:
        print ""+url        
        shows(name,url,page)
        
elif mode==12:
        print ""+url
        getVideosTV(name,url,page)   
        
             
elif mode==13:
        print ""+url
        getVideosEpisodes(name,url,page) 
        
elif mode==155:
        print ""+url          
        years(url)
        
elif mode==16:
        print ""+url        
        getaddVideos(name,url,page)  
        
elif mode==2:
        print ""+url
        get_servers(url)
elif mode==3:
        print ""+url
        search()		
elif mode==4:
        print ""+url
        get_servers2(url)
                
elif mode==30:
        print ""+url        
        get_series4watch(url) 
elif mode==44:
        print ""+url        
        get_series4watch2(url) 
        
elif mode==5:
        print ""+url
        get_host(url)        
        
elif mode==7:
        print ""+url
        get_host2(url)        
                
        
elif mode==6:
        print ""+url
        get_hostlink(url)
elif mode==7:
        resolve_host(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
