# -*- coding: utf8 -*-
try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
from xbmctools import addDir,readnet,supported,get_params,readtrueurl,getDomain,parsedata,playlink,finddata
baseurl = 'http://cimaclub.com'
############################################
###############################


##########################################main menu
def showmenu():
        
        
        addDir('Search','http://www.series4watch.tv/?s=',104,'IMG/0.png',1)
	#addDir('••أخــر الاضافات••','http://www.series4watch.tv/',600,'IMG/1.png',1)
        
	addDir('••أخــر الاضافات••','http://www.series4watch.tv/',600,'IMG/1.png',1)
        addDir('هـــوليود','http://www.series4watch.tv/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/',100,'IMG/2.png',1)
        #addDir('سلاسل الافلام','http://www.series4watch.tv/%D8%B3%D9%84%D8%A7%D8%B3%D9%84-%D8%A7%D9%84%D8%A7%D9%81%D9%84%D8%A7%D9%85/',60,'IMG/15.png',1)
       	addDir('2017','http://www.series4watch.tv/release-year/2017/',10000,'IMG/7.png',1)
        #addDir('المواسم الكاملة','http://www.series4watch.tv/%D8%AC%D9%85%D9%8A%D8%B9-%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA/',2000,'IMG/14.png',1)
        #addDir('مواسم تعرض حاليا','http://www.series4watch.tv/%D8%AC%D9%85%D9%8A%D8%B9-%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA/',2000,'IMG/13.png',1)
	addDir('جميع المسلسلات','http://www.series4watch.tv/%D8%AC%D9%85%D9%8A%D8%B9-%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA/',60,'IMG/15.png',1)

        addDir('مسلسلات أجنبية','http://www.series4watch.tv/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a/',60,'IMG/3.png',1)
	addDir('مسلسلات-عربي','http://www.series4watch.tv/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A/',60,'IMG/5.png',1)
	addDir('مسلسلات تركي','http://www.series4watch.tv/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%AA%D8%B1%D9%83%D9%8A/',60,'IMG/12.png',1)

	addDir('أفلام عربي','http://www.series4watch.tv/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%b9%d8%b1%d8%a8%d9%8a/',100,'IMG/4.png',1)

	addDir('بــوليود','http://www.series4watch.tv/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%87%d9%86%d8%af%d9%8a/',100,'IMG/6.png',1)

	addDir('افلام اسيوية','http://www.series4watch.tv/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%b3%d9%8a%d9%88%d9%8a%d8%a9/',100,'IMG/10.png',1)

	addDir('أفلام أنميشن','http://www.series4watch.tv/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%86%d9%8a%d9%85%d9%8a/',100,'IMG/11.png',1)

	addDir('المصــارعة','http://www.series4watch.tv/category/%d8%b9%d8%b1%d9%88%d8%b6-%d9%85%d8%b5%d8%a7%d8%b1%d8%b9%d8%a9/',100,'IMG/9.png',1)



def years(url):
	addDir('2017','http://www.series4watch.tv/tag/2017/',100,'IMG/13.png',1)
	addDir('2016','http://www.series4watch.tv/tag/2016/',100,'IMG/1.png',1)
        addDir('2015','http://www.series4watch.tv/tag/2015/',10000,'IMG/12.png',1)
        addDir('2014','http://www.series4watch.tv/tag/2014/',10000,'IMG/3.png',1)
        addDir('2013','http://www.series4watch.tv/tag/2013/',10000,'IMG/6.png',1)
       	addDir('2012','http://www.series4watch.tv/tag/2012/',10000,'IMG/7.png',1)
        addDir('2011','http://www.series4watch.tv/tag/2011/',10000,'IMG/14.png',1)
        addDir('2010','http://www.series4watch.tv/tag/2010/',10000,'IMG/2.png',1)
        addDir('2009','http://www.series4watch.tv/tag/2009/',10000,'IMG/13.png',1)
       	addDir('2008','http://www.series4watch.tv/tag/2008/',10000,'IMG/3.png',1)
        addDir('2007','http://www.series4watch.tv/tag/2007/',10000,'IMG/7.png',1)
        addDir('2006','http://www.series4watch.tv/tag/2006/',10000,'IMG/15.png',1)
        addDir('2005','http://www.series4watch.tv/tag/2005/',10000,'IMG/2.png',1)

        setView('movies', 'MAIN')
      
                
####################movies		
               
def getyears_movies(url):
        for i in range(2002,2016):
             addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                    
def getgenre_movies(url):
        #http://www.vidics.ch/Category-Movies/Genre-comedy/Letter-Any/ByPopularity/1.htm
        genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
        for item in genrelist:
                
                 addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-Movies'),100,'http://i45.tinypic.com/2d9u26c.jpg',1)
	

                    


				  




                   
def getmovies(name,urlmain,page):##movies
               
                if page>1:
                  #/page/2/http://aflamonlinee.org/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+"/"+"/"'+/page/'+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  #url_page=urlmain+'/page/'+str(page)
                  url_page=urlmain+"/"+'/?page='+str(page)
                  url_page=urlmain+"/page/"+str(page)+"/"
                  
                  #url_page='http://www.series4watch.tv/?page='+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                #data=data.split('<div class="moviesBlocks DataFill">')[1]

                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="movie">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                  
                    regx='''<a href="(.*?)">'''
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    regx='''<img.*?src="(.*?)".*?''' 
                    #regx='''<img data-src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<h2>(.*?)</h2>'''
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,100,'http://www.lilesnet.com/ocfair/2016/2016-07-16/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))


def getmovies3(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                 url_page="http://www.series4watch.tv/release-year/2017/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                
                
               
                if data is None:
                    return
                blocks=data.split('<div class="movie">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
              
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)">'''
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    regx='''<img.*?src="(.*?)".*?''' 
                    #regx='''<img data-src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                    
                    regx='''<h2>(.*?)</h2>'''
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                    
                     
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page
                   
                  
                addDir("Next Page",urlmain,10000,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))


def loop1(name,urlmain,page):##movies               
                print "page",page
               
                if page>1:
                  # http://foxegy.com/new/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%89-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/page/2/
                
                 url_page=urlmain+"/page/"+str(page)+"/"
                 
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                
                data=data.split('class="titleCategory">')[1]
                
               
                if data is None:
                    return
               
                blocks=data.split('class="movie">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                  
                    regx='''href="(.*?)"'''
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    regx='''src="(.*?)"''' 
                    #regx='''<img data-src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<h2>(.*?)</h2>'''
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    #name=removeunicode(name)
                    
                    
                    
                    try:addDir(name,href,202,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,60,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                    


def loop(name,urlmain,page):##movies               
                print "page",page
               
                if page>1:
                  # http://foxegy.com/new/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%89-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/page/2/
                
                 url_page=urlmain+"/?page="+str(page)
                 
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                data=data.split('<div class="moviesBlocks DataFill">')[1]

                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="movie">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                  
                    regx='''<a href="(.*?)">'''
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    regx='''<img.*?src="(.*?)".*?''' 
                    #regx='''<img data-src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<h2>(.*?)</h2>'''
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                
                addDir("next page",urlmain,600,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                    





def search_movies(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   Searchtext = keyboard.getText() 
                   
                   
        else:
             print "search error"
            
        
        
         
        
        #url=;http://www.vidics.ch/Category-FilmsAndTV/Genre-Any/Letter-Any/ByPopularity/1/Search-titanic.htm
        url=url+urllib.quote_plus(Searchtext)
        print "url",url
        #sys.exit(0)
        getmovies("Search",url,0)
        #No results

                    

                    

def getmovies_search(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # http://cera.online/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html/page/2/
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="movie">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img src="(.*?)" alt="(.*?)" />'''
                            

                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    #regxname='''class="attachment-col wp-post-image" alt="(.*?)"'''
                    name=re.findall(regxname,block, re.M|re.I)[0]
                    
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    regxhref='''<a href="(.*?)">'''
                    href=re.findall(regxhref,block, re.M|re.I)[0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    if 'series' in href:
                            mode=2001
                    else:
                            mode=1
                    
                    try:addDir(name,href,mode,img,'',1)
                    except:pass
                    
                   
               
                   
                if len(blocks)>10:
                   addDir("next page",urlmain,104,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def getmovies2(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # www.vidics.ch/Category-Movies/Genre-Any/Letter-Any/LatestFirst/1.htm
                  url1=os.path.split(urlmain)[0]
                  url_page=url1+"/"+str(page)+".htm"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split(" <option value='none'")[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<option')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)" title="(.*?)">'''
                    regx='''value='(.*?)'>(.*?)</option>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    href=match[0][0]
                    name=match[0][1]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    year=''
                    img=''

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:name=str(name)+"("+year+")"
                    except:name=str(name)
                    
                    
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))             
def getseries2(name,urlmain,page):##movies
               
                if page>1:
                  #/page/2/http://series4watch.tv/english-movies/2/
                  #     
                  url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+"/"+"/"'+/page/'+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'?offset=40'+str(page)
                  url_page=urlmain+"/?offset="+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
               #data=data.split('id="movie_list"')[1]

                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="movie">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                  
                    regx='''<a href="(.*?)">'''
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    regx='''<img.*?src="(.*?)".*?''' 
                    #regx='''<img data-src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<p>(.*?)</p>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,201,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,2000,'http://www.lilesnet.com/ocfair/2016/2016-07-16/next_icon.png','',str(page+40))                
                if len(blocks)==0:
                    addDir("Eror:no results",urlmain,100,'','',str(page+1))
def getepisodes2(name,urlmain,page):##movies
               
                if page>1:
                  #/page/2/http://series4watch.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+"/"+"/"'+/page/'+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
               #data=data.split('id="movie_list"')[1]

                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="movie">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                  
                    regx='''<a href="(.*?)">'''
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    regx='''<img.*?src="(.*?)".*?''' 
                    #regx='''<img data-src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<p>(.*?)</p>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,20000,'http://www.lilesnet.com/ocfair/2016/2016-07-16/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Eror:no results",urlmain,100,'','',str(page+1))
                 
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
###############################################tv shows
def getyears_series(url):
        for i in range(2002,2016):
             addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                    
def getgenre_series(url):
       
        genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
        for item in genrelist:
                
      	  addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-Movies'),100,'http://i45.tinypic.com/2d9u26c.jpg',1)
	

                            
                    


def getA_Z_series(name,mode):
        AZ_DIRECTORIES = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z']
        for character in AZ_DIRECTORIES:
                
                addDir(character,"http://www.vidics.ch/"+name+"/Genre-Any/Letter-"+character+"/ByPopularity/1.htm",mode,"")
			
				                      
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getseries_search("Search",url,0)
                    

               
                                    
def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                 
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                #try:data=data.split('</center>')[4]
                #except:pass
                data=readnet(urlmain)
                
                regx='''<p><a href="(.*?)"><img src=".*?"></a></p>'''
                regx='''<a href="(.*?)">
<img src=".*?" alt="">'''

                href=re.findall(regx,data, re.M|re.I)[0]
                print "href",href
                data=readnet(href)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                blocks=data.split('<div class="movie">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                  
                    regx='''<a href="(.*?)">'''
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    regx='''<img.*?src="(.*?)".*?''' 
                    #regx='''<img data-src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<h2>(.*?)</h2>'''
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    try:addDir(name,href,2001,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
def getseries_search(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                 
                  url1=os.path.split(urlmain)[0]
                  url_page=url1+"/"+str(page)+".htm"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split('<div class="episodes">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<option')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)" title="(.*?)">'''
                    regx='''value='(.*?)'>(.*?)</option>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    href=match[0][0]
                    name=match[0][1]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    year=''
                    img=''

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:name=str(name)+"("+year+")"
                    except:name=str(name)
                    
                    
                    try:addDir(name,href,2001,img,'',1)
                    except:pass
               
                   
                
                
                                                            

def getseasons(name,urlmain,page):##series
                print "page",page
            
                if page>1:
                  
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                print "data",data
                
                #if not "<option value='none' selected>=" in data:
                        #gethosts(urlmain)
                        #return                   
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="episodes">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*?src="(.*?)"'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regx='''<a href="(.*?)">
								(.*?)								<span>.*?</span>'''
                    match=re.findall(regx,block, re.M|re.I)[0]
                    name=match[0][1]
                    href=match[0][0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    #name=removeunicode(name)
                    try:addDir(name,href,201,img,'',1)
                    except:pass
               
                   
                
               
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    

               
                   
                
               
                

def getepisodess(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://tellymov.com/category/Movies/page2
                  
                     url_page=urlmain+'page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                #regx='''<meta http-equiv="refresh" content="0;URL='(.*?)'" />'''
                #href=re.findall(regx,data, re.M|re.I)[0]
                #data=readnet(href)
               
                try:data=data.split('<div class="episodes">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div data-season=')
                i=0
                
                print "blocks",len(blocks)
                print "block",blocks
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)">
								(.*?)								<span>.*?</span>'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''src="(.*?)'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    name="Episode "+str(i-1)
                    if "?" in img:
                        img=img.split("?")[0].encode("utf-8")                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
                
               
               

 

                    

               
def getepisodes(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                 
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                
               
                
               
                if data is None:
                    return
               
                blocks=data.split('<div data-season')
                i=0
                
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    
                   
                    regx='''(.*?)<span>.*?</span>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                    name="episode "+name
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    
                    try:addDir(name,href,1,'IMG/00.jpg','',1)
                    except:pass
               
                   
                
               #addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    
                    

               
                   
                
               


#######################################host resolving                                                    
               

                   

def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #resolve_host(href)
                    #return True
                            
                    addDir(server,href,20,'IMG/server.png')


def gethostsss(urlmain):##cinema and tv featured
                
        data=readnet(urlmain)
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,9):
          url='http://www.series4watch.tv/wp-content/themes/online/servers/server.php?q='+id+'&i='+str(i)
          print 'url',url
         
          data=readnet(url)          
          regx='''src="(.+?)"'''
          link = re.findall(regx,data, re.M|re.I)[0]
          server=gethostname(link)
          addDir(server,link,20,'IMG/server.png')
          
def gethosts(urlmain):##cinema and tv featured

                data=readnet(url)
                regx="rel='shortlink' href='(.*?)'"
                pid=re.findall(regx,data, re.M|re.I)[0].split("=")[1]
                print "pid",pid
                for i in range(1,6):
                   newurl='http://www.series4watch.tv/wp-content/themes/online/servers/server.php?q='+pid+"&i="+str(i)
                   try:data=readnet(newurl)
                   except:break
                   regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                   href=re.findall(regx,data, re.M|re.I)[0]
                   server=getDomain(href)
                   if not href.startswith("http:"):
                           href="http:"+href
                   if True:
                           if server=="ok":
                              from yasokru import get_video_url
                              get_video_url(href)                           
                   #addDir(server,href,2,"IMG/server.png",'',1)

                   



          
                
                             
                   
                             
def resolve_host(url):#last good-used with local resolver

        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error:"+stream_link,stream_link,9,"") 	    
    
def addDir(name,url,mode,iconimage,extra='',page=1):

        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##parsing tools        
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==2:
        print ""+url
        resolve_host(url)   
        
elif mode==33:
        print ""+url
        resolve_host3(url)     
        
          
elif mode==9:
        print ""+url
        playlink(url)  
elif mode==10:
        print ""+url
        gethosts2(url)
        
elif mode==66:
        print ""+url
        get_servers(url)
        
elif mode==20:
        print ""+url
        resolve_host2(url)          
####movies        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==1000:
        print ""+url
        getmovies2(name,url,page)  
        
elif mode==60:
        print ""+url        
        loop1(name,url,page) 
         
elif mode==600:
        print ""+url           
        loop(name,url,page) 
        
elif mode==2000:
        print ""+url
        getseries2(name,url,page) 
elif mode==20000:
        print ""+url        
        getepisodes2(name,url,page)       
elif mode==10000:
        print ""+url     
        getmovies3(name,url,page) 
elif mode==101:
        print ""+url
        getgenre_movies('movies')	

elif mode==102:
	
	getA_Z_movies(name,100)

elif mode==103:
	print ""+url
	
	getyears_movies(name)	
elif mode==104:
	print ""+url
        search_movies(url)

elif mode==105:
	print ""+url
	
	getmovies_search(url)

###series        
elif mode==200:
	
	getseries(name,url,page)
elif mode==222:	
	getseries3(name,url,page)
	
elif mode==2000:
	
	getseries2(name,url,page)
	
	
elif mode==201:
	
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)
elif mode==203:
	
	getA_Z_series(name,100)

elif mode==204:
	print ""+url
	
	getyears_series(name)	
elif mode==205:
	print ""+url
        search_series(url)
elif mode==500:
	print ""+url        
        years(url)

elif mode==206:
	print ""+url
	
	getseries_search(url)

xbmcplugin.endOfDirectory(int(sys.argv[1])) 
