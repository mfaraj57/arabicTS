#!/usr/bin/python
# -*- coding: utf-8 -*-
try:import sys, syspath
except:pass
from yttools import *


def infolist():
  list1=[]
 
  
  list1.append(('Albernameg','UCUvufBZoieEr1YOFhOMnzHw'))
  return list1
  

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))

