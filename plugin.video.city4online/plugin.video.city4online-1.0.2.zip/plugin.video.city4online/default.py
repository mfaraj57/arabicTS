# -*- coding: utf8 -*-
try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,os
from addon.common.addon import Addon
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
import urllib2,urllib
import re
import httplib
import time,itertools
__settings__ = xbmcaddon.Addon(id='plugin.video.city4online')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = (sys.argv[0])
baseurl='http://www.city4online.com/'

 
     
def read_url2(url):
        try:
            req = urllib2.Request(url)
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
            return data
        except urllib2.URLError, e:
            print 'URL: '+url
            if hasattr(e, 'code'):
                print 'We failed with error code - %s.' % e.code
            elif hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: %s' %e.reason
def read_url3(url):#redirect error
        try:
           p = urllib2.build_opener(urllib2.HTTPCookieProcessor).open(url)
           return p.read()
        except:
                addDir("Download failed:","","",'')      
                return None
def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'city4online.com')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link
def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial
    return inner                                                                                                                                                                            
def getCategories():
        addDir('Search','http://www.city4online.com/?s=',3,'img/0.jpg',1)
        addDir('••أخــر الاضافات••','http://city4online.com/',11,'img/9.jpg',1)
	addDir('أفلام أجنبية اون لاين','http://city4online.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a/',11,'img/1.jpg',1)
        addDir('أفلام عربية أون لاين','http://city4online.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%b9%d8%b1%d8%a8%d9%8a/',11,'img/2.jpg',1)       	
	addDir('أفلام هندية أون لاين','http://city4online.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%87%d9%86%d8%af%d9%8a/',11,'img/3.jpg',1)	
	addDir('أفلام كارتون مدبلجة أون لاين','http://city4online.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%86%d9%85%d9%8a-%d9%85%d8%af%d8%a8%d9%84%d8%ac%d8%a9/',11,'img/5.jpg',1)
	addDir('أفلام كارتون منرجمة أون لاين','http://city4online.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%86%d9%85%d9%8a-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9/',11,'img/5.jpg',1)
	addDir('مسلسلات اجنبيه','http://city4online.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a%d8%a9/',11,'img/8.jpg',1)
        addDir('••مسلسلات أون لاين••','url',55,'img/4.jpg',1)
        #addDir('مسلسلات عربيه','http://city4online.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%b1%d9%85%d8%b6%d8%a7%d9%86-2015/',11,'img/4.jpg',1)
        
        addDir('مسلسلات تركيه مترجمة','http://city4online.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%aa%d8%b1%d9%83%d9%8a%d8%a9-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9/',11,'img/7.jpg',1)
        addDir(' مسلسلات تركيه مدبلجة','http://city4online.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%aa%d8%b1%d9%83%d9%8a%d8%a9-%d9%85%d8%af%d8%a8%d9%84%d8%ac%d8%a9/',11,'img/7.jpg',1)
       
        addDir('برامج تلفزيونية','http://city4online.com/category/%d8%a8%d8%b1%d8%a7%d9%85%d8%ac-%d8%aa%d9%84%d9%8a%d9%81%d8%b2%d9%8a%d9%88%d9%86%d9%8a%d8%a9-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/',11,'img/6.jpg',1)
        addDir('WWE','http://city4online.com/category/%d9%85%d8%b5%d8%a7%d8%b1%d8%b9%d8%a9/',11,'img/10.jpg',1)
       
        
def seris(url):
        addDir('مسلسلات عربيه','http://city4online.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%b9%d8%b1%d8%a8%d9%8a%d8%a9/',11,'img/4.jpg',1)
        addDir('••مسلسلات رمضان 2016••','http://city4online.com/category/%d8%b1%d9%85%d8%b6%d8%a7%d9%86-2016/',11,'img/4.jpg',1)
        addDir('••مسلسلات رمضان 2015••','http://city4online.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%b1%d9%85%d8%b6%d8%a7%d9%86-2015/',11,'img/4.jpg',1)

        addDir('••برامج رمضان 2016••','http://city4online.com/category/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%AA%D9%84%D9%8A%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D8%A9-%D8%A7%D9%88%D9%86-%D9%84%D8%A7%D9%8A%D9%86/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%AA%D9%84%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D8%A9-%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2015/',11,'img/8.jpg',1)
        setView('movies', 'MAIN')
        
      
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url=url+search_entered
        print "mfarajx4_url",url
          
        getVideos("Search",url,1)        
        
        
        
def getVideos(name1, urlmain,page):
               if page>1:
                  url_page=urlmain+'/page/'+str(page)+"/"
               else:
                      url_page=urlmain
               print "url_page",url_page
               content = read_url(url_page)                 
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
	       regx='''<a href="(.*?)">\s*<div class="image">\s*<img src="(.*?)" alt="(.*?)" .*?/>'''		
               regx='''<img .*? src="(.*?)" class="postimg wp-post-image" alt="(.*?)" .*? />\s*<div class=".*?">\s*<h2><a href="(.*?)">'''
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,title ,image in match:
                        pic = ''
 
                        url=href
                        
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,image,2,url)
               addDir('next page>',urlmain, 1,'http://www.tachyonpunch.com/comics/images/next_icon.png',str(page+1))
              
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                     
                    addDir(server,href,7,'http://orig15.deviantart.net/3c70/f/2011/076/b/9/source_code_by_fandvd-d3buxak.png')
             		
def get_servers(url):
        #?server=2
        for i in range(1,7):
                server='server '+str(i)
                href=url+"/?show_post=true&server="+str(i)
                addDir(server,href,4, '')
        
               
def get_servers2(url):
	        data=read_url(url)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''
                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                #regx5='''<IFRAME .+? SRC="(.+?)" .+?></IFRAME>'''
               
                #match1 = re.findall(regx1,data, re.M|re.I)
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return
def resolve_host1(url):#last good-used with local resolver

        from urlresolver import resolve
        print 'url',url
        
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    #listItem = xbmcgui.ListItem(path=str(stream_link))
	    #xbmcplugin.setResolvedUrl(1, True, listItem)
	    xbmc.Player().play(stream_link)
            sys.exit(0)
        else:
            addDir("Error,"+str(stream_link),"",9,"") 	    
def resolve_host2(url):#last good
       
              from urlresolver import resolve
         
              stream_link=str(resolve(url))
              print stream_link
              if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
         
                  listItem = xbmcgui.ListItem(path=str(stream_link))
                  xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
              else:
                  addDir("Error,"+stream_link,"",9,"")                        
                      
                             
#######################################end common                                                        
                          				

###############################local resolver
def resolve_thevideo(web_url):
            from t0mm0.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            import jsunpack


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': web_url
            }

            html = net.http_GET(web_url).content

            js = ''
            tries=1
            while not js and tries<=MAX_TRIES:
                r = re.findall(r'type="hidden"\s*name="(.+?)"\s*value="(.*?)"', html)
                data={}
                for name, value in r:
                    data[name] = value
                data[u"imhuman"] = "Proceed to video"; 
                r = re.findall(r"type:\s*'hidden',\s*id:\s*'([^']+).*?value:\s*'([^']+)", html)
                for name, value in r:
                    data[name] = value
                                                                                  
                cookies={}
                for match in re.finditer("\$\.cookie\('([^']+)',\s*'([^']+)",html):
                    key,value = match.groups()
                    cookies[key]=value
                cookies['ref_url']=web_url
                headers['Cookie']=urllib.urlencode(cookies)
    
                html = net.http_POST(web_url, data, headers=headers).content
                #print 'Try: %s/%s' % (tries, MAX_TRIES)
                r = re.search("<script type='text/javascript'>(eval\(function\(p,a,c,k,e,d\).*?)</script>",html,re.DOTALL)
                if r:
                    js = jsunpack.unpack(r.group(1))
                    break
                tries += 1
            else:
                raise Exception ('Unable to resolve TheVideo link. Player config not found.')
                
            r = re.findall(r"label:\\'([^']+)p\\',file:\\'([^\\']+)", js)
            if not r:
                raise Exception('Unable to locate link')
            else:
                max_quality=0
                for quality, stream_url in r:
                    if int(quality)>=max_quality:
                        best_stream_url = stream_url
                        max_quality = int(quality)
                return best_stream_url








			
def resolve_nowvideo(web_url):

        debug=True
        from t0mm0.common.net import Net
        net=Net()
        if debug:
            html = net.http_GET(web_url).content
            
            key = re.compile('flashvars.filekey=(.+?);').findall(html)
            ip_key = key[0]
            pattern = 'var %s="(.+?)".+?flashvars.file="(.+?)"'% str(ip_key)
            r = re.search(pattern,html, re.DOTALL)
            #print 'find key: '+str(r)
            if r:
                filekey, filename= r.groups()
                #print "FILEBLOBS=%s  %s"%(filename,filekey)
            else:
                r = re.search('file no longer exists',html)
                if r:
                    raise Exception ('File Not Found or removed')
            
            #get stream url from api
                
            api = 'http://www.nowvideo.sx/api/player.api.php?key=%s&file=%s' % (filekey, filename)
            print "api",api
            html = net.http_GET(api).content
            r = re.search('url=(.+?)&title', html)
            if r:
                stream_url = urllib.unquote(r.group(1))
            else:
                r = re.search('no longer exists',html)
                print html
                if r:
                    raise Exception ('File Not Found or removed')
                raise Exception ('Failed to parse url')
                
            return stream_url
def resolve_dailymotion(id):
    import json
    from t0mm0.common.net import Net
    net=Net()
    content =net.http_GET("http://www.dailymotion.com/embed/video/"+id).content
    if content.find('"statusCode":410') > 0 or content.find('"statusCode":403') > 0:
        xbmc.executebuiltin('XBMC.Notification(Info:,'+translation(30022)+' (DailyMotion)!,5000)')
        return ""
    
    else:
        get_json_code = re.compile(r'dmp\.create\(document\.getElementById\(\'player\'\),\s*([^);]+)').findall(content)[0]
        #print len(get_json_code)
        cc= json.loads(get_json_code)['metadata']['qualities']  #['380'][0]['url']
        #print cc
        if '1080' in cc.keys():
            #print 'found hd'
            return cc['1080'][0]['url']
        elif '720' in cc.keys():
            return cc['720'][0]['url']
        elif '480' in cc.keys():
            return cc['480'][0]['url']
        elif '380' in cc.keys():
            return cc['380'][0]['url']
        elif '240' in cc.keys():
            return cc['240'][0]['url']
        elif 'auto' in cc.keys():
            return cc['auto'][0]['url']
        else:
            xbmc.executebuiltin('XBMC.Notification(Info:, No playable Link found (DailyMotion)!,5000)')
        
def resolve_vodlocker(web_url):
        from t0mm0.common.net import Net
        net=Net()
        resp=net.http_GET(web_url)
        html=resp.content
        debug=True
        if debug:
                data={}; r=re.findall(r'type="hidden" name="(.+?)"\s* value="?(.+?)">',html); data['usr_login']=''
        	for name,value in r: data[name]=value
        	data['imhuman']='Proceed to video'; data['btn_download']='Proceed to video'
        	xbmc.sleep(2000)
        	html=net.http_POST(web_url,data).content
        	print html
        else :
                  
            return "unresolvable"
        r=re.search('file\s*:\s*"(http://.+?)"',html)
        if r:
            #stream_url=urllib.unquote_plus(r.group(1))
            stream_url=str(r.group(1))
            #print stream_url
        else:
            
            return "unresolvable"
        return stream_url
      
########################################################33			
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]                                
        return param

def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
def addDir(name,url,mode,iconimage,page=1):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def playlink(url):
            print "m2",url
	    listItem = xbmcgui.ListItem(path=str(url))
	    xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)

params=get_params()
url=None
name=None
mode=None
initial=None
max=None
rating=None
cast=None
year=None
genre=None
duration=None
writer=None
director=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
	
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        page=1
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
if mode==None or url==None or len(url)<1:
        print ""
        getCategories()
elif mode==1:
        print ""+url
        getVideos(name,url,page)
elif mode==11:
        print ""+url
        getVideos(name,url,page)
elif mode==3:
        print ""+url        
        search(url)
elif mode==55:
        print ""+url        
        seris(url)
        
elif mode==2:
        print ""+url
        get_servers(url)
elif mode==4:
        print ""+url        
	get_servers2(url)	
elif mode==6:
        print ""+url
        get_hostlink(url)
elif mode==7:
       resolve_host1(url)
	

xbmcplugin.endOfDirectory(int(sys.argv[1]))
