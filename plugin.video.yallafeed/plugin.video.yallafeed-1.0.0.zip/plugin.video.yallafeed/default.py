#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
from yttools import *


def infolist():
  list1=[]
 
  list1.append(('YallaFeed','UCiwFsY2vAOkjhK_2LYTGjpg',1001,"img/1.png"))#playlist
  list1.append(('YTLaugh','UC3_jPpyZfFmYGPXSt2xUGIw',1001,"img/1.png"))#playlist
 
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))

