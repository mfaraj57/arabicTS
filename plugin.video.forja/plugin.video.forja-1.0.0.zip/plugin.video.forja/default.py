# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os,json
from xbmctools import addDir,readnet,supported,get_params,getnet,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error
################''
baseurl='http://aflam06.com'
host='www.forja.tn'
##########################################parsing tools
def postData(url, data, host, Referer):
    import requests
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.post(url, headers=headers, data=data)
    htmldata = r.content
    return htmldata


def showmenu():
        addDir('ٍSearch movies','https://forja.tn/api/movies?extended=shor',103,'img/search.png','',1)

        addDir('Movies','https://forja.tn/api/movies?extended=short',100,'img/1.png','',1)
        addDir('ٍSearch series','https://forja.tn/api/series?extended=shor',104,'img/search.png','',1)
        addDir('Series','https://forja.tn/api/series?extended=short',200,'img/2.png','',1)
	
        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  

        
        
         
 
          
       


def search(name,sterm,page):##may pastte code of getmovies here
                url='https://forja.tn/api/movies?extended=short'
                data={"page":page,'sortby':'added','title':sterm}

                Referer='https://forja.tn/movies'
                data=postData(url, data, host, Referer)
                
                jdata = json.loads(data)
                type='movies'
                for item in jdata['movies']:
                                icon   = item.get('Poster', '')
                                title  = item.get('Title', '')
                                desc = item.get('Plot', '')
                                imdbID = item.get('imdbID', '')
                                url ='https://forja.tn/movies'+ '/%s/%s/' % (type[:-1], imdbID)
                                rated= item.get('Rated', '')
                                print "title",title
                                print "url",url
                                
                                addDir(title,str(imdbID),1,icon,desc.encode("utf-8",'ignore'),1)
                                
                addDir("next page",sterm,103,'img/next.png','',str(page+1))
                return
                

def search_series(name,sterm,page):##may pastte code of getmovies here
                
                

                url='https://forja.tn/api/series?extended=short'
                data={"page":page,'sortby':'added','title':sterm}

                Referer='https://forja.tn/series'
                data=postData(url, data, host, Referer)
                
                jdata = json.loads(data)
                type='series'
                for item in jdata['series']:
                                icon   = item.get('Poster', '')
                                title  = item.get('Title', '')
                                desc = item.get('Plot', '')
                                imdbID = item.get('imdbID', '')
                                url ='https://forja.tn'+ '/%s/%s/' % (type[:-1], imdbID)
                                rated= item.get('Rated', '')
                                print "title",title
                                print "url",url
                                
                                addDir(title,url,201,icon,desc.encode("utf-8",'ignore'),1)
                                
                addDir("next page",url,104,'img/next.png','',str(page+1))
                return

               
                   
                
               
                   
                
        
def getmovies(name,murl,page):##movies
               
               

                url='https://forja.tn/api/movies?extended=short'
                data={"page":page,'sortby':'added'}

                Referer='https://forja.tn/movies'
                data=postData(url, data, host, Referer)
                
                jdata = json.loads(data)
                type='movies'
                for item in jdata['movies']:
                               
                                icon   = item.get('Poster', '')
                                title  = item.get('Title', '')
                                desc = item.get('Plot', '')
                                imdbID = item.get('imdbID', '')
                                url ='https://forja.tn/movies'+ '/%s/%s/' % (type[:-1], imdbID)
                                rated= item.get('imdbRating', '')
                                year= item.get('Year', '')
                                print "title",rated
                                print "url",url
                                title=title+"("+year+"-"+rated+")"
                                addDir(title,str(imdbID),1,icon,desc.encode("utf-8",'ignore'),1)
                                
                addDir("next page",murl,100,'img/next.png','',str(page+1))
                return
                




###############################################series

def getseries(name,murl,page):

                url='https://forja.tn/api/series?extended=short'
                data={"page":page,'sortby':'added'}

                Referer='https://forja.tn/series'
                data=postData(url, data, host, Referer)
                
                jdata = json.loads(data)
                type='series'
                for item in jdata['series']:
                                icon   = item.get('Poster', '')
                                title  = item.get('Title', '')
                                desc = item.get('Plot', '')
                                imdbID = item.get('imdbID', '')
                                url ='https://forja.tn'+ '/%s/%s/' % (type[:-1], imdbID)
                                rated= item.get('imdbRating', '')
                                year= item.get('Year', '')
                                print "title",rated
                                print "url",url
                                try:title=str(title)+"("+year+"-"+rated+")"
                                except:pass
                                
                                addDir(title,url,201,icon,desc.encode("utf-8",'ignore'),1)
                                
                addDir("next page",murl,200,'img/next.png','',str(page+1))
                return

    
def getseries2(name,url,page):##series
                url='https://forja.tn/api/series?extended=short'
                data={"page":page,'sortby':'added'}

                Referer='https://forja.tn/series'
                data=postData(url, data, host, Referer)
                
                jdata = json.loads(data)
                print "jdata",jdata
                type='series'
                seasonsTab = []
                for item in jdata['series']:

                    season = self.cm.ph.getSearchGroups(item, '''season=['"]([^'^"]+?)['"]''')[0]
                    season=re.findall('''season=['"]([^'^"]+?)['"]''',item, re.M|re.I)[0]
                    icon=re.findall('''data\-original=['"]([^'^"]+?)['"]''',item, re.M|re.I)[0]
                    url=re.findall('''data\-original=['"]([^'^"]+?)['"]''',item, re.M|re.I)[0]
                    title  = '%s - %s' % (cItem['title'], self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''episode\-name=['"]([^'^"]+?)['"]''')[0]))
                    icon   = self.getFullIconUrl(self.cm.ph.getSearchGroups(item, '''data\-original=['"]([^'^"]+?)['"]''')[0])
                    url    = self.getFullUrl(self.cm.ph.getSearchGroups(item, '''episode\-url=['"]([^'^"]+?)['"]''')[0])
                    title  = '%s - %s' % (cItem['title'], self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''episode\-name=['"]([^'^"]+?)['"]''')[0]))

                    return
                

def getAllItemsBeetwenNodes(data, node1, node2, withNodes=True):
        if len(node1) < 2 or len(node2) < 2:
            return []
        itemsTab = []
        n1S = node1[0]
        n1E = node1[1]
        if len(node1) > 2: n1P = node1[2]
        else: n1P = None
        n2S = node2[0]
        n2E = node2[1]
        if len(node2) > 2: n2P = node2[2]
        else: n2P = None
        lastIdx = 0
        search = 1
        sData = data
        while True:
            if search == 1:
                # node 1 - start
                idx1 = sData.find(n1S, lastIdx)
                if -1 == idx1: return itemsTab
                lastIdx = idx1 + len(n1S)
                idx2 = sData.find(n1E, lastIdx)
                if -1 == idx2: return itemsTab
                lastIdx = idx2 + len(n1E)
                if n1P != None and sData.find(n1P, idx1 + len(n1S), idx2) == -1:
                    continue
                search = 2
            else:
                # node 2 - end
                tIdx1 = sData.find(n2S, lastIdx)
                if -1 == tIdx1: return itemsTab
                lastIdx = tIdx1 + len(n2S)
                tIdx2 = sData.find(n2E, lastIdx)
                if -1 == tIdx2: return itemsTab
                lastIdx = tIdx2 + len(n2E)

                if n2P != None and sData.find(n2P, tIdx1 + len(n2S), tIdx2) == -1:
                    continue

                if withNodes:
                    idx2 = tIdx2 + len(n2E)
                else:
                    idx1 = idx2 + len(n1E)
                    idx2 = tIdx1
                search = 1
                itemsTab.append(sData[idx1:idx2])
        return itemsTab
                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                seasonsTab = []
                data = getAllItemsBeetwenNodes(data, ('<div', '>', 'episode-container'), ('</div', '>'))


                for item in data:

                    
                    season=re.findall('''season=['"]([^'^"]+?)['"]''',item, re.M|re.I)[0]
                    icon=re.findall('''data\-original=['"]([^'^"]+?)['"]''',item, re.M|re.I)[0]
                    url=re.findall('''episode\-url=['"]([^'^"]+?)['"]''',item, re.M|re.I)[0]
                    title=re.findall('''episode\-name=['"]([^'^"]+?)['"]''',item, re.M|re.I)[0]
                    print "title",title
                    print "season",season
                    print "url",url
                    print "image",icon
                    addDir(title,'https://forja.tn'+url,3,'https://forja.tn'+str(icon),'',1)
                    continue
                    title  = '%s - %s' % (cItem['title'], self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''episode\-name=['"]([^'^"]+?)['"]''')[0]))
                    icon   = self.getFullIconUrl(self.cm.ph.getSearchGroups(item, '''data\-original=['"]([^'^"]+?)['"]''')[0])
                    url    = self.getFullUrl(self.cm.ph.getSearchGroups(item, '''episode\-url=['"]([^'^"]+?)['"]''')[0])
                    title  = '%s - %s' % (cItem['title'], self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''episode\-name=['"]([^'^"]+?)['"]''')[0]))

                    return
                        

                                           
                                    


def getepisodes(name,url,page):##series

                print "page",page
               
                if page>1:
                    
                        #http://www.movs4u.com/movie/page/2/
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=readnet(page_url)
               
                
                
               
                if data is None:
                    return
               
                #blocks=data.split('قائمة الحلقات:')
                regx='''<li><a target="_blank" href="(.*?)" title=".*?">(.*?)</a></li>'''
                match=re.findall(regx,tblock, re.M|re.I)
                print "match",match
                for href,title in match:
                    addDir(title,href,1,'','',1,maintitle=True)    
                i=0
                return 


#######################################host resolving                                                    
                    

def getservers(name,url):
                        #"/hls_movies/tt5109784/sd/manifest.m3u8"
                        
                        hrefsd='https://forja.tn'+'/hls_movies/'+url+'/sd/manifest.m3u8'
                        hrefhd='https://forja.tn'+'/hls_movies/'+url+'/manifest.m3u8'
                        
                        addDir('sd',hrefsd,10,"img/server.png",'',link=True)
                        addDir('hd',hrefhd,10,"img/server.png",'',link=True)
def getservers_series(name,url):
                        #"/hls_movies/tt5109784/sd/manifest.m3u8"
                        id=name.split('-:-')[0].split(":")[0].strip()
                        data=readnet(url)
                        regx='''src: "(.*?)"'''
                        match=re.findall(regx,data, re.M|re.I)
                        
                        for href in match:
                            print "href",href,id
                            if not id in href:
                                continue
                            href='https://forja.tn'+href
                            if '/hd/' in href:
                                
                               addDir("hd",href,10,'','',1,link=True)

                            else:
                               addDir("sd",href,10,'','',1,link=True) 
                        
                               
def resolve_host(url):
        resolve_host(url)    


params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        resolvehost(url)        
elif mode==3:
        print ""+url
        getservers_series(name,url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
        sterm = getsearchtext()      
         
        search("Search",sterm,page)
elif mode==104:
        sterm = getsearchtext()      
         
        search_series("Search",sterm,page) 
        
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
