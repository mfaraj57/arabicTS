# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import Item,resolvehost,readnet,get_params,getsearchtext,getDomain,getserver_image,resolvehost,getserver_image,supported,finddata,trace_error
#################################     
item=Item()
addDir=item.addDir
endDir=item.endDir  

baseurl='https://www.tvfun.ma'

##########################################parsing tools


def showmenu():
        addDir('Search ',baseurl,103,'img/search.png','',1,searchall=__file__)        
        

       
        addDir('مسلسلات عربيه','https://www.tvfun.ma/mosalsalat-3arabia/',200,'img/1.png','',1)
        addDir('مسلسلات رمضان 2018','https://www.tvfun.ma/ts,mosalsalat-ramadan-2018/',200,'img/2.png','',1)
        
        addDir('مسلسلات مغربيه','https://www.tvfun.ma/mosalsalat-maghribia/',200,'img/3.png','',1)

        
        addDir('مسلسلات هنديه','https://www.tvfun.ma/mosalsalat-hindia/',200,'img/4.png','',1)

        addDir('مسلسلات لاتينيه','https://www.tvfun.ma/mosalsalat-latinia/',200,'img/5.png','',1)

        addDir('مسلسلات كوريه','https://www.tvfun.ma/mosalsalat-korea/',200,'img/6.png','',1)


       
        addDir('مسلسلات انيمي','https://www.tvfun.ma/dessin-animee/',200,'img/7.png','',1)


       
        addDir('مسلسلات تركي','https://www.tvfun.ma/mosalsalat-torkia/',200,'img/8.png','',1)


       
        addDir('برامج','https://www.tvfun.ma/programme-tv/',200,'img/9.png','',1)








        





             
                  

                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["1" ,"2", "3" ,"4" ,"5" ,"6" ,"7" ,"9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://www.tfarjo.com/films/alphabet/'+letter.lower()+"/",100,'','',1)

			  



def search_103(name,sterm,page):
                surl='https://www.tvfun.ma/q/'

                if page>1:
                        page_url=baseurl+'/page/'+str(page)+'/?s='+sterm


                else:
                        page_url=surl+sterm
                print "page_url",page_url        
                blocks=readnet(page_url,'<svg viewBox',"<h4> آخر الحلقات </h4>",'class="ThumbBigDiv"')           
                
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                                   
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''class="qu">(.*?)</div>'''
                    try:quality=re.findall(regx,block.repalce("\n",""), re.M|re.I)[0].strip()
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                   
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,name,1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>10:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))

                
                
                
                
                
                





               
                   
                
               
                   
                
        
def getmovies_100(name,url,page):##movies
               
               
                if page>1:
                    
                    page_url=url+'page/'+str(page)
                    
                  
                else:
                
                     page_url=url
                print "url_page",page_url
                blocks=readnet(page_url,'class="loopsFilms"','<svg viewBox','class="pagination"')           
                
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                                   
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    if True:
                            regx='''class="qu">(.*?)</div>'''
                            try:quality=re.findall(regx,block.repalce("\n",""), re.M|re.I)[0].strip()
                            except:quality=''

                            regx='''<span>(.*?)</span>'''
                            try:
                                    rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:
                                    regx='''</span>(.*?)</div>'''
                                    try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                                    except:rating=''
                            title=title+"-"+quality+"-"+rating
                           
                            
                            
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,name,1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>29:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                









###############################################series


def getseries_200(name,url,page):##series
                if page>1:
                    #https://www.tvfun.ma/ts,mosalsalat-ramadan-2018/page,2/
                    page_url='https://www.tvfun.ma/ts,mosalsalat-ramadan-2018/page,'+str(page)+"/"
                    
                  
                else:
                
                     page_url=url
                print "url_page",page_url
                blocks=readnet(page_url,'<svg viewBox','class="pagination"','class="ThumbBigDiv"')           
                
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                                   
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image
                    except:
                            image=''
                            trace_error()
                            pass                            
                    if True:
                            regx='''class="qu">(.*?)</div>'''
                            try:quality=re.findall(regx,block.repalce("\n",""), re.M|re.I)[0].strip()
                            except:quality=''

                            regx='''<span>(.*?)</span>'''
                            try:
                                    rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:
                                    regx='''</span>(.*?)</div>'''
                                    try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                                    except:rating=''
                            title=title+"-"+quality+"-"+rating
                           
                            
                            
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,name,1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>33:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))

                
                
                





                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return
                regx='''<div class="panel-body"> <a href="(.*?)"><span class="glyphicon glyphicon-triangle-right"></span>(.*?)</a>'''
                                                                           
                seasons=re.findall(regx,data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,1,'','',1)
                        

                                           
                                    


def getepisodes_202(name,url,page):##series

                if page>1:
                    
                    page_url=url+'page/'+str(page)
                    
                  
                else:
                
                     page_url=url
                print "url_page",page_url
                blocks=readnet(page_url,'<svg viewBox','<h4> آخر الحلقات </h4>','class="ThumbBigDiv"')           
                
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                                   
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0][:-1]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''class="qu">(.*?)</div>'''
                    try:quality=re.findall(regx,block.repalce("\n",""), re.M|re.I)[0].strip()
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                   
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,name,1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>33:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))

                
               

#######################################host resolving                                                    
                    

def getservers_1(name,url):
                data=readnet(url)
                
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                match=re.findall(regx,data, re.M|re.I)
                print "match",match
               
                for href in match:
                        
                   
                   href="http:"+href
                   server=getDomain(href)
                  
                   image=getserver_image(server)
                   addDir(server+"-"+name,href,2,image,name,1)

                   

                 
def resolve_host(url,name):
       if 'tvfun.ma/videoembed' in url:
               data=readnet(url)
               regx='''<source src='(.*?)' type='video/mp4' label='(.*?)' res='(.*?)' />'''
               match=re.findall(regx,data, re.M|re.I)
               for href,label,res in match:
                   addDir(label+"-"+res,href,0,'',1,link=True)
               return        
       resolvehost(url,name)
       return

params=get_params()
url=None
name=None
mode=None
page=1
name=params.get("name",None)
url=params.get("url",None)
try:mode=int(params.get("mode",None))
except:mode=None
image=params.get("image",None)
section=params.get("section",None)
page=int(params.get("page",1))
extra=params.get("extra",None)
show=params.get("show",None)
print "Mode1: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Image: "+str(image)
print "page: "+str(page)
print "section: "+str(section)
print "show: "+str(show)
print "extra: "+str(extra)  

##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers_1(name,url)
elif mode==2:
        print ""+url
        resolve_host(url,name)         
elif mode==3:
        print ""+url
        getservers_2(name,url)
elif mode==103:
        sterm = getsearchtext()      
         
        search_103("Search",sterm,page)         
###movies     
        
elif mode==100:
        print ""+url
        getmovies_100(name,url,page)


elif mode==102:
	print ""+url
	getA_Z_102('movies')
	

    
###series        


elif mode==200:

	getseries_200(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes_202(name,url,page)

   

endDir()                         
