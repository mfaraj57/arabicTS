# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import Item,readnet,get_params,getnet,finddata,playlink,getDomain,resolvehost,getsearchtext,finditems,resolvehost,finddata,trace_error,removeunicode,playlink
item=Item()
addDir=item.addDir
endDir=item.endDir
baseurl='http://www.online.dramacafe.in'

##########################################parsing tools


def showmenu():
        
        
        addDir('SEARCH','http://www.online.dramacafe.in/search.php?keywords=',103,'img/search.png','',1,searchall=__file__) 
        addDir('أخر الاضافات ','http://www.online.dramacafe.in/newvideos.html',100,'img/series.png','2',1)          
        addDir('أفـــلام أجنبية','http://www.online.dramacafe.in/browse-NonArabicFilms-videos-1-date.html',100,'img/mov.png','0',1)          
        addDir('سلسلــة أفلام','http://www.online.dramacafe.in/browse-MoviesPacks-videos-1-date.html',100,'img/dubbed.png','0',1)
        addDir('أفضل الافـــلام','http://www.online.dramacafe.in/topvideos.html?do=recent',100,'img/top.png','0',1)
        addDir('مسلسلات أجنبية','http://www.online.dramacafe.in/browse-NonArabicSeries-videos-1-date.html',200,'img/non.png','0',1)
     	
	addDir('أفـــلام عربية','http://www.online.dramacafe.in/browse-ArabicMovies-videos-1-date.html',100,'img/arabic.png','1',1)
	
        
        addDir('مســلسلات عربية','http://www.online.dramacafe.in/browse-EgyptianDrama-videos-1-date.html',200,'img/7.png','1',1)
        addDir('مسلسلات سوريه','http://www.online.dramacafe.in/browse-SyrianDrama-videos-1-date.html',200,'img/8.png','1',1)
        addDir('مسلسلات خليجيه','http://www.online.dramacafe.in/browse-Khaleeji-videos-1-date.html',200,'img/9.png','1',1)
        addDir('مسلسلات رمضان 2018','http://www.online.dramacafe.in/browse-Ramadan2018-videos-1-date.html',200,'img/10.png','1',1)
        addDir('مسلسلات رمضان 2017','http://www.online.dramacafe.in/browse-Ramadan2017-videos-1-date.html',200,'img/11.png','1',1)
        addDir('مسلسلات رمضان 2016','http://www.online.dramacafe.in/browse-Ramadan2016-videos-1-date.html',200,'img/12.png','1',1)
        addDir('مسلسلات رمضان 2015','http://www.online.dramacafe.in/browse-Ramadan2015-videos-1-date.html',200,'img/13.png','1',1)
        addDir('مسلسلات تاريخيه','http://www.online.dramacafe.in/browse-Historical-videos-1-date.html',200,'img/14.png','1',1)
        addDir('مســلسلات عربية','http://www.online.dramacafe.in/browse-BedouinDrama-videos-1-date.html',200,'img/15.png','1',1)
        
        addDir('افلام هنديه','http://www.online.dramacafe.in/browse-Bollywood-videos-1-date.html',100,'img/16.png','1',1)
        
   
        addDir('مسلسلات مدبلجة','http://www.online.dramacafe.in/browse-DubbedDrama-videos-1-date.html',200,'img/dubbed.png','',1)

        addDir('مسلسلات هنديه مدبلجه','http://www.online.dramacafe.in/browse-HindiSeries-videos-1-date.html',200,'img/18.png','',1)

        addDir('مسلسلات تركيه مدبلجه','http://www.online.dramacafe.in/browse-TurkishDrama-videos-1-date.html',200,'img/19.png','',1)


        addDir('مسلسلات ايرانيه مدبلجه','http://www.online.dramacafe.in/browse-IranianDrama-videos-1-date.html',200,'img/20.png','',1)

        addDir('مسلسلات مكسيكيه مدبلجه','http://www.online.dramacafe.in/browse-MexicanDrama-videos-1-date.html',200,'img/21.png','',1)


        
        addDir('درامـــا أسيوية','http://www.online.dramacafe.in/browse-AsianDrama-videos-1-title.html',200,'img/asia.png','',1)
       
        addDir('أنيمايشن','http://www.online.dramacafe.in/browse-AnimeAndCartoon-videos-1-date.html',100,'img/cartoon.png',1)
        addDir('مســــرحيات','http://www.online.dramacafe.in/browse-Theatre-videos-1-title.html',100,'img/theater.png','',1)
        






        





def years():###nt active-movies 110,series 210
        list=[]
        for i in range(1950,2019):
             #http://tellymov.com/s/year/2006
             list.append(i)
        list.reverse()     
        for i in list:
                
             addDir(str(i),'http://www.tfarjo.com/films/annee/film-'+str(i)+'-streaming/',100,'','',1)                 
                  
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["1" ,"2", "3" ,"4" ,"5" ,"6" ,"7" ,"9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://www.tfarjo.com/films/alphabet/'+letter.lower()+"/",100,'','',1)

			  



def search_103(name,sterm,page,extra=''):
                surl='http://www.online.dramacafe.in/search.php?keywords='

                if page>1:
                        page_url='http://www.online.dramacafe.in/search.php?keywords='+sterm+'&page='+str(page)


                else:
                        page_url=surl+sterm
                print "page_url",page_url        
                blocks=readnet(page_url,'id="primary"','pagination','pm-li-video')           
                
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                                   
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                            if extra=='0':
                              title=removeunicode(title)
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''class="qu">(.*?)</div>'''
                    try:quality=re.findall(regx,block.repalce("\n",""), re.M|re.I)[0].strip()
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                   
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>39:
                    
                   addDir("next page",sterm,103,'img/next.png','',str(page+1))

                
                
                





               
                   
                
               
                   
                
        
def getmovies_100(name,url,page,extra=''):##movies
               
               
                if page>1 :
                   
                  
                   
                      if "2" in extra:
                         page_url=url+'?&page='+str(page)
                      else:  
                         page_url=url+'&page='+str(page)+".html"
                else:
               
                
                      page_url=url
                print "url_page",page_url
                blocks=readnet(page_url,'id="primary"','pagination','pm-li-video')           
                
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                                   
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                            
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''class="qu">(.*?)</div>'''
                    try:quality=re.findall(regx,block.repalce("\n",""), re.M|re.I)[0].strip()
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                   
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>39:
                    
                   addDir("next page",url,100,'img/next.png',extra,str(page+1))

                print "extra",extra









###############################################series


def getseries_200(name,url,page,extra=''):##series
                if page>1 :
                   
                  
                   
                   
                      page_url=url+'&page='+str(page)+".html"
                else:
               
                
                      page_url=url
                print "url_page",page_url
                blocks=readnet(page_url,'id="primary"','pagination','pm-li-video')           
                
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                                   
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                            
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''class="qu">(.*?)</div>'''
                    try:quality=re.findall(regx,block.repalce("\n",""), re.M|re.I)[0].strip()
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                   
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>39:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))

                





                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return
                regx='''<div class="panel-body"> <a href="(.*?)"><span class="glyphicon glyphicon-triangle-right"></span>(.*?)</a>'''
                                                                           
                seasons=re.findall(regx,data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,1,'','',1)
                        

                                           
                                    


def getepisodes_202(name,url,page):##series


                data=readnet(url)           
                
                regx='''<a href="(.*?)" class="WatchButton">'''
                href=re.findall(regx,data, re.M|re.I)[0]
                data=readnet(href) 
                if data is None:
                    return
               
                
                try:
                        sdata=finddata(data,'class="MoviesBlocks"','id="FilterCatsFooter"')
                        if sdata=='':
                                sdata=data
                except:
                        sdata=data
                data=sdata
                
                blocks=data.split('class="MovieBlock"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace('&#8211;',' ')                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            
                            
                    except:
                            trace_error()
                            continue

                    regx='''alt="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''data-img="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]                                  
                    except:
                            image=''
                            trace_error()
                            pass                            
                    
                    regx='''<span class="quality">(.*?)</span>'''
                    try:quality=re.findall(regx,block, re.M|re.I)[0]
                    except:quality=''

                    regx='''<span>(.*?)</span>'''
                    try:
                            rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                    except:
                            regx='''</span>(.*?)</div>'''
                            try:rating=re.findall(regx,block, re.M|re.I)[0].replace('IMDb:','').strip()
                            except:rating=''
                    title=title+"-"+quality+"-"+rating
                    title=title.replace('&#038;',' ')
                    
                    
                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
               

#######################################host resolving                                                    
                    

def getservers_1(name,url):

        videoid = re.findall('-video_(.*?).html', url)
        print "videoid",videoid
        url = 'http://www.online.dramacafe.in/ajax.php?p=video&do=getplayer&vid=' + videoid[0] + '&aid=4&player=detail'
        print "urlxx",url
        
        data=readnet(url)        
        
        hrefs = re.findall('src="(.+?)"', data)
        print "tagrets",hrefs
       
        data2=readnet(hrefs[0])
        
        if 'dailymotion.com' in str(hrefs[0]):
            addDir("dailymotion-"+name,hrefs[0],2,"img/dailymotion.png","",1)
            return
       
       
        elif 'type="video/mp4"' in data2:

          regx="src='(.+?)'"
          #mp4links=re.findall(regx,data2, re.M|re.I)
          mp4links = finditems(data2,'<source','>')
          print "mp4links",mp4links
          for item in mp4links:
                 link = re.findall(regx,item, re.M|re.I)[0]
                 print "linkxx",link
                 if "hd" in link:
                         addDir("hd"+"-"+name,link,11,"","",1,link=True)
                 else:
                                
                         addDir("sd"+"-"+name,link,0,"","",1,link=True)

          return                                
          
        else:                
           
                                server,image,issupported=getDomain(hrefs[0])        
                                if issupported:
                                   addDir(server,hrefs[0],2,image,name,1)
    
           

           
            
		    

                 
def resolve_host(name,url):
       stream_link=resolvehost(item,name,url)
       playlink(item,name,url)
       return

def start():  
        params=get_params()
        url=params.get('url','')
        name=params.get('name','')
        try:mode=int(params.get('mode',None))
        except:mode=None
        page=int(params.get('page',1))
        section=params.get('section','')
        extra=params.get('extra','')
        show=params.get('show','')
        image=params.get('image','')

        print "Mode: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "page: "+str(page)
        print "section: "+str(section)
        print "extra: "+str(extra)
        print "show: "+str(show)
        print "image: "+str(image)
        ##menu and tools
        ##menu and tools
        if mode==None or url==None or len(url)<1:
                print ""
                showmenu()
        ##hosts        
        elif mode==1:
                print ""+url
                
                getservers_1(name,url)
        elif mode==2:
                print ""+url
                resolve_host(name,url)         
        elif mode==3:
                print ""+url
                getservers_2(name,url)
        elif mode==103:
                sterm = getsearchtext()      
                 
                search_103("Search",sterm,page,extra)         
        ###movies     
        elif mode==11:
                print ""+url
                playlink(item,name,url)                
        elif mode==100:
                print ""+url
                getmovies_100(name,url,page,extra)

        elif mode==101:
                print ""+url
                years_101()	

        elif mode==102:
                print ""+url
                getA_Z_102('movies')
                

            
        ###series        


        elif mode==200:

                getseries_200(name,url,page,extra)
                
        elif mode==201:
                getseasons(name,url,page)
                
        elif mode==202:
                getepisodes_202(name,url,page)

           

        return endDir()                             
start()
