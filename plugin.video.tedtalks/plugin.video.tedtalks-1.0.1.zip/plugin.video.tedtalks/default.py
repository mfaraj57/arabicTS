# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py




try:import sys, syspath
except:pass
import os, sys
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse


import StringIO
#url='http%3A%2F%2Fvgrp1.viewstream.co.il%2Fviewstream%2F34%2F13%2F299%2F13299.flv%3Fvtraffid%3D13299%26ctraffid%3D34'
#print urllib.unquote_plus(url)
#sys.exit(0)
__settings__ = xbmcaddon.Addon(id='plugin.video.tedtalks')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://www.ted.com/talks'

####functions

def read_url(url):
     
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
    
def readnet2(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
##########################################parsing tools
def showmenu():

                genreliste=[]
               
                
                genreliste.append(("Search", 'http://www.ted.com/talks?sort=newest&q=',104,'img/search.png','',1))
                genreliste.append(("Speakers", 'http://www.ted.com/people/speakers',105,'img/speakers.png','',1))

                genreliste.append(("Categories", 'cat',102,'img/1.png','',1))
                genreliste.append(("Languages", 'cat',103,'img/2.png','',1))


                
                genreliste.append(("Topics-newest", 'http://www.ted.com/talks',100,'img/3.png','',1))
                genreliste.append(("Topics-popular", 'http://www.ted.com/talks?sort=popular',100,'img/4.png','',1))
                genreliste.append(("Topics-Jaw-dropping", 'http://www.ted.com/talks?sort=jaw-dropping',100,'img/5.png','',1))
                genreliste.append(("Topics-funny", 'http://www.ted.com/talks?sort=funny',100,'img/6.png','',1))
                genreliste.append(("Topics-persuasive", 'http://www.ted.com/talks?sort=persuasive',100,'img/7.png','',1))
                genreliste.append(("Topics-courageous", 'http://www.ted.com/talks?sort=courageous',100,'img/8.png','',1))
                genreliste.append(("Topics-ingenious", 'http://www.ted.com/talks?sort=ingenious',100,'img/9.png','',1))
                genreliste.append(("Topics-fascinating", 'http://www.ted.com/talks?sort=fascinating',100,'img/10.png','',1))
                genreliste.append(("Topics-inspiring", 'http://www.ted.com/talks?sort=inspiring',100,'img/11.png','',1))
                genreliste.append(("Topics-beautiful", 'http://www.ted.com/talks?sort=beautiful',100,'img/12.png','',1))
                genreliste.append(("Topics-informative", 'http://www.ted.com/talks?sort=informative',100,'img/13.png','',1))
                   


               
                
                
		
                for title, url, mode,pic,desc,page in genreliste:
                    addDir(title, url, mode, pic,desc,1)

###############################################tv shows

def langauges():
        langauges=[('Afrikaans', 'af'),('Albanian', 'sq'),('Afrikaans','af'),('Albanian', 'sq'),('Algerian Arabic', 'arq'), ('Amharic', 'am'), ('Arabic', 'ar'), ('Armenian', 'hy'), ('Assamese', 'as'), ('Asturian', 'ast'), ('Azerbaijani', 'az'), ('Basque', 'eu'), ('Belarusian', 'be'), ('Bengali', 'bn'), ('Bislama', 'bi'), ('Bosnian', 'bs'), ('Bulgarian', 'bg'), ('Burmese', 'my'), ('Catalan', 'ca'), ('Cebuano', 'ceb'), ('Chinese, Simplified', 'zh-cn'), ('Chinese, Traditional', 'zh-tw'), ('Chinese, Yue', 'zh'), ('Creole, Haitian', 'ht'), ('Croatian', 'hr'), ('Czech', 'cs'), ('Danish', 'da'), ('Dutch', 'nl'), ('English', 'en'), ('Esperanto', 'eo'), ('Estonian', 'et'), ('Filipino', 'fil'), ('Finnish', 'fi'), ('French', 'fr'), ('French (Canada)', 'fr-ca'), ('Galician', 'gl'), ('Georgian', 'ka'), ('German', 'de'), ('Greek', 'el'), ('Gujarati', 'gu'), ('Hakha Chin', 'cnh'), ('Hausa', 'ha'), ('Hebrew', 'he'), ('Hindi', 'hi'), ('Hungarian', 'hu'), ('Hupa', 'hup'), ('Icelandic', 'is'), ('Igbo', 'ig'), ('Indonesian', 'id'), ('Ingush', 'inh'), ('Irish', 'ga'), ('Italian', 'it'), ('Japanese', 'ja'), ('Kannada', 'kn'), ('Kazakh', 'kk'), ('Khmer', 'km'), ('Klingon', 'tlh'), ('Korean', 'ko'), ('Kurdish', 'ku'), ('Kyrgyz', 'ky'), ('Lao', 'lo'), ('Latgalian', 'ltg'), ('Latin', 'la'), ('Latvian', 'lv'), ('Lithuanian', 'lt'), ('Luxembourgish', 'lb'), ('Macedo', 'rup'), ('Macedonian', 'mk'), ('Malagasy', 'mg'), ('Malay', 'ms'), ('Malayalam', 'ml'), ('Maltese', 'mt'), ('Marathi', 'mr'), ('Mauritian Creole', 'mfe'), ('Mongolian', 'mn'), ('Montenegrin', 'srp'), ('Nepali', 'ne'), ('Norwegian Bokmal', 'nb'), ('Norwegian Nynorsk', 'nn'), ('Occitan', 'oc'), ('Pashto', 'ps'), ('Persian', 'fa'), ('Polish', 'pl'), ('Portuguese', 'pt'), ('Portuguese, Brazilian', 'pt-br'), ('Punjabi', 'pa'), ('Romanian', 'ro'), ('Russian', 'ru'), ('Serbian', 'sr'), ('Serbo-Croatian', 'sh'), ('Silesian', 'szl'), ('Sinhala', 'si'), ('Slovak', 'sk'), ('Slovenian', 'sl'), ('Somali', 'so'), ('Spanish', 'es'), ('Swahili', 'sw'), ('Swedish', 'sv'), ('Swedish Chef', 'art-x-bork'), ('Tagalog', 'tl'), ('Tajik', 'tg'), ('Tamil', 'ta')]

        for language in langauges:
                href='http://www.ted.com/talks?sort=newest&language='+language[1]
                name=language[0]
                addDir(name, href, 100,'','',1)
def topics():
          list=[('activism', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=activism'), ('Addiction', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=addiction'), ('adventure', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=adventure'), ('advertising', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=advertising'), ('Africa', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=africa'), ('aging', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=aging'), ('agriculture', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=agriculture'), ('AI', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=ai'), ('AIDS', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=aids'), ('aircraft', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=aircraft'), ('algorithm', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=algorithm'), ('alternative energy', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=alternative energy'), ('ancient world', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=ancient world'), ('animals', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=animals'), ('anthropology', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=anthropology'), ('ants', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=ants'), ('apes', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=apes'), ('architecture', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=architecture'), ('art', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=art'), ('arts', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=arts'), ('Asia', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=asia'), ('astronomy', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=astronomy'), ('atheism', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=atheism'), ('augmented reality', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=augmented reality'), ('Autism spectrum disorder', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=autism spectrum disorder'), ('bacteria', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=bacteria'), ('beauty', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=beauty'), ('bees', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=bees'), ('behavioral economics', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=behavioral economics'), ('big bang', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=big bang'), ('big problems', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=big problems'), ('biodiversity', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=biodiversity'), ('Bioethics', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=bioethics'), ('biology', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=biology'), ('biomechanics', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=biomechanics'), ('biomimicry', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=biomimicry'), ('biosphere', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=biosphere'), ('biotech', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=biotech'), ('birds', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=birds'), ('body language', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=body language'), ('books', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=books'), ('botany', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=botany'), ('brain', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=brain'), ('Brand', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=brand'), ('Brazil', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=brazil'), ('Buddhism', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=buddhism'), ('bullying', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=bullying'), ('business', 'http://www.ted.com/talks?sort=newest&topics%5B%5D=business')]
          for item in list:
              addDir(item[0], item[1], 100,'','',1)
      

       
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getmovies("Search",url,1)

def getspeakers(tname,urlmain,page):##series
                if page>1:
                 
                 
                          url_page='http://www.ted.com/people/speakers?page='+str(page)+'&per_page=30'
                  
                else:
                
                      url_page=urlmain
                data=readnet2(url_page)
               #data=data.split('id="movie_list"')[1]
                print "urlpage",url_page
                #sys.exit(0)
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split("<a class='results")
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    
                    
                    
                    regx='''href='(.*?)'>'''
                    
                    href='http://www.ted.com'+re.findall(regx,block, re.M|re.I)[0]
                    print "match",href
                   
                   
                    
                    
                    regx='''<img.*?src="(.*?)" />'''
                    regx='''<img.*?src="(.*?)" /><span'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    print "img",img.strip()
                    regx='''class='h12 talk-link__speaker'>(.*?)</h4>'''
                    block=block.replace("\n","")
                    regx='''<h4 class='.*?5'>(.*?)</h4>'''
                    speaker=re.findall(regx,block, re.M|re.I)[0]
                   

                   
                                             
                               
                    
                    
                    speaker=speaker.encode("utf-8").replace("<br>"," ")
                    try:addDir(speaker,href,100,img,'',1)
                    except:continue
               
                if len(blocks)>25:
                   addDir("next page",urlmain,105,'img/nextpage.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))                                           
def getmovies(tname,urlmain,page):##series
                if page>1:
                  
                  if "?" in urlmain:
                          parts=urlmain.split("?")
                          url_page='http://www.ted.com/talks?page='+str(page)+"?"+parts[1]
                  else:
                          url_page=urlmain+"?page="+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet2(url_page)
               #data=data.split('id="movie_list"')[1]
                print "urlpage",url_page
                #sys.exit(0)
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split("class='talk-link'>")
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    
                    block=block.replace("\n"," ")
                    regx='''<a class='' href='(.*?)'>'''
                    regx="<h4 class='h9 m5'><a class='' href='(.*?)'>(.*?)</a></h4>"
                    regx='''<h4 class='h9 m5'> <a class='' href='(.*?)'.*?>(.*?)</a> </h4>'''
                    
                    match=re.findall(regx,block, re.M|re.I)#[0]
                    print "match",match
                   
                    href='http://www.ted.com'+match[0][0]
                    name=match[0][1]
                    
                    regx='''<img.*?src="(.*?)" />'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    print "img",img.strip()
                    regx='''class='h12 talk-link__speaker'>(.*?)</h4>'''
                    speaker=re.findall(regx,block, re.M|re.I)[0]
                   

                   
                                             
                               
                    
                    name=name.encode("utf-8")
                    speaker=speaker.encode("utf-8")
                    try:addDir(name+":"+speaker,href,1,img,'',1)
                    except:continue
               
                if len(blocks)>25:
                   addDir("next page",urlmain,100,'img/nextpage.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))


def getlinks(name,urlmain):##cinema and tv featured

       
        
        data=readnet2(urlmain)
        
        
        if '"service":"YouTube"' in data:
            regx='''"code":"(.*?)","service":"YouTube"'''
            videoid=re.findall(regx,data, re.M|re.I)[0]
            stream_link = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
          
            addDir("youtube",stream_link,22,'','',1)
            return
            
        regx='''"bitrate":(.*?),"file":"(.*?)"'''
        match=re.findall(regx,data, re.M|re.I)
       
        for name,href in match:
            try:
                href=href.replace("mp4:","")
                if not href.startswith("http://download.ted.com"):
                   href='http://video.ted.com/'+href
            except:
                pass
            if 'google' in href:
                continue
            
            addDir("quality:"+name,href,22,'','',1)
        regx='''"name":"(.*?)","low":"(.*?)"'''
        
        regx=':{"name":"(.*?)","low":"(.*?)","high":(.*?)"}'
        regx=''',".*?":{"name":"(.*?)","low":"(.*?)","high":"(.*?)"}'''
        
        data=data.split('"subtitledDownloads"')[1].split('"audioDownload"')[0]
        blocks=data.split('":{')
        i=0
        
        
        for block in blocks:
            i=i+1
            if i==1:
                continue
            print "block",block
            
            regx='''"name":"(.*?)","low":"(.*?)","high":"(.*?)"}'''

            match1=re.findall(regx,block, re.M|re.I)
            print "match1",match1
            match2=[]
            if len(match1)==0:
                regx='''"name":"(.*?)","(.*?)":"(.*?)"},".*?'''
                match2=re.findall(regx,block, re.M|re.I)
                print "match2",match2
                for title,res,href2 in match2:
            
                   
                   addDir(title+"_high",href2,22,'','',1)
                   
                
            print "match11",match1
            for title,href,href2 in match1:
            
              
                
                addDir(title,href,22,'','',1)
                addDir(title+"_high",href2,22,'','',1)
        return
        
        
       

		
		
               

def playlink(url):
            xbmc.Player().play(url)
            sys.exit(0)

            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        getlinks(name,url)



        
elif mode==22:
        print ""+url
        playlink(url)          
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==102:
	print ""+url
	topics()
elif mode==103:
	print ""+url
	langauges()	
elif mode==104:
	print ""+url
        search(url)
        
elif mode==105:
	print ""+url
        getspeakers(name,url,page)        
xbmcplugin.endOfDirectory(int(sys.argv[1]))	


                              
