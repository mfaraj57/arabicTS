# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/script.module.main/lib/yttools.py
try:
    import sys, syspath
except:
    pass

import xbmc, xbmcaddon, xbmcplugin, xbmcgui, urllib, urllib2, re, os
import json
from xbmctools import playlink, get_params,  requestsurl
pluginhandle = int(sys.argv[1])
default_params = '&order=date'
print 'defaultParams', default_params
KEYV3 = 'AIzaSyDn2w07I3D8xNQ9D-QcY5t3n0JZ7RW8J8c'

def getchannelid(chusername):
    url = 'https://www.googleapis.com/youtube/v3/channels?part=id&forUsername=%s&key=%s' % (chusername, KEYV3)
    content = requestsurl(url)
    list1 = []
    if content:
        data = json.loads(content)
        channelId = str(data['items'][0]['id'])
        return channelId


def mainmenu(list1):
    for item in list1:
        try:
            mode = item[2]
        except:
            mode = 1001

        try:
            pic = item[3]
        except:
            pic = ''
        try:
            page = item[5]
        except:
            page = ''
        addDir(item[0], item[1], mode, pic, '',page)


def gettotalresults(url):
    list1 = []
    content = requestsurl(url)
    if content.startswith('Error'):
        return '0'
    data = json.loads(content)
    print data
    if data:
        totalResults = data.get('pageInfo')['totalResults']
        return str(totalResults)
    else:
        return '0'


def submenu(name, chid, page = ''):
    url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=playlist&channelId=' + chid + '&maxResults=11' + default_params + '&key=' + KEYV3
    count = str(gettotalresults(url))
    addDir('Playlists(' + count + ')', url, 1002, 'img/playlist.png', '','')
    url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&channelId=' + chid + '&maxResults=11' + default_params + '&key=' + KEYV3
    count = str(gettotalresults(url))
    addDir('Videos(' + count + ')', url, 1002, 'img/video.png', '','')


def getviedoList(name1, urlmain, page = ''):
    print 'page', page
    if page == '':
        url_page = urlmain
    else:
        url_page = urlmain + '&pageToken=' + str(page).strip()
    print 'url_page', url_page
    #url_page="https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&channelId=UCwTysbEc5Ol12caxTWLW56Q&maxResults=11&order=date&key=AIzaSyDn2w07I3D8xNQ9D-QcY5t3n0JZ7RW8J8c&pageToken=CAsQAA"
    content = requestsurl(url_page)
    if content is None:
        addDir('Error:downoad error', '', 1, '', '')
        return
    else:
        data = json.loads(content)
        c4_browse_ajax = str(data.get('nextPageToken', ''))
        a = 0
        l = len(data)
        if l < 1:
            addDir('No contents / results found!', '', 1, '', '')
            return
        print "data",data
        list_item = 'ItemList' in data['kind']
        for item in data.get('items', {}):
            if not list_item:
                kind = item['id']['kind']
            else:
                kind = item['kind']
            if kind:
                title = item['snippet']['title'].encode('utf-8')
                desc = item['snippet']['description'].encode('utf-8', 'ignore').replace('&', '_').replace(';', '')
                if kind.endswith('#video'):
                    try:
                        url = str(item['id']['videoId'])
                        img = str(item['snippet']['thumbnails']['default']['url'])
                        print 'url', url
                        stream_link = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
                        addDir(title, stream_link, 1004, img, desc, '', link=True)
                    except:
                        continue

                elif kind.endswith('#playlistItem'):
                    try:
                        url = str(item['snippet']['resourceId']['videoId'])
                        img = str(item['snippet']['thumbnails']['default']['url'])
                        url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
                        addDir(title, url, 1004, img, desc, '', link=True)
                    except:
                        pass

                elif kind.endswith('#channel'):
                    url = str(item['id']['channelId'])
                    try:
                        img = str(item['snippet']['thumbnails']['default']['url'])
                    except:
                        img = ''

                    url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&channelId=' + url + '&maxResults=11' + default_params + '&key=' + KEYV3
                    addDir(title, url, 1002, img, desc, '')
                elif kind.endswith('#playlist'):
                    url = str(item['id']['playlistId'])
                    try:
                        img = str(item['snippet']['thumbnails']['default']['url'])
                    except:
                        img = ''

                    url = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=' + url + '&maxResults=11' + default_params + '&key=' + KEYV3
                    addDir(title, url, 1002, img, desc, '')

        if not c4_browse_ajax == '':
            addDir('next page>', urlmain, 1002, '', '', c4_browse_ajax)
        return
        return


def getplayList(name1, urlmain, page = ''):
    print 'mahmou1', urlmain
    print 'page', page
    if page == '':
        urlmain = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=playlist&channelId=' + urlmain + '&maxResults=11' + default_params + '&key=' + KEYV3
        url_page = urlmain
    else:
        url_page = urlmain + '&pageToken=' + page
    print 'url_page', url_page
    content = requestsurl(url_page)
    if content is None:
        addDir('Error:downoad error', '', 1, '', '')
        return
    else:
        data = json.loads(content)
        c4_browse_ajax = str(data.get('nextPageToken', ''))
        a = 0
        l = len(data)
        if l < 1:
            addDir('No contents / results found!', '', 1, '', '')
            return
        list_item = 'ItemList' in data['kind']
        for item in data.get('items', {}):
            if not list_item:
                kind = item['id']['kind']
            else:
                kind = item['kind']
            if kind:
                title = item['snippet']['title'].encode('utf-8')
                desc = item['snippet']['description'].encode('utf-8').replace('&', '_').replace(';', '')
                if kind.endswith('#video'):
                    try:
                        url = str(item['id']['videoId'])
                        img = str(item['snippet']['thumbnails']['default']['url'])
                        print 'url', url
                        stream_link = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
                        addDir(title + '_' + desc, stream_link, 1004, img, desc, '')
                    except:
                        continue

                elif kind.endswith('#playlistItem'):
                    try:
                        url = str(item['snippet']['resourceId']['videoId'])
                        img = str(item['snippet']['thumbnails']['default']['url'])
                        url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
                        addDir(title, url, 1004, img, desc, '')
                    except:
                        pass

                elif kind.endswith('#channel'):
                    url = str(item['id']['channelId'])
                    img = str(item['snippet']['thumbnails']['default']['url'])
                    url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&channelId=' + url + '&maxResults=12' + default_params + '&key=' + KEYV3
                    addDir(title, url, 1002, img, desc, '')
                elif kind.endswith('#playlist'):
                    url = str(item['id']['playlistId'])
                    img = str(item['snippet']['thumbnails']['default']['url'])
                    url = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=' + url + '&maxResults=12' + default_params + '&key=' + KEYV3
                    addDir(title, url, 1002, img, desc, '')

        if not c4_browse_ajax == '':
            addDir('next page>', urlmain, 1002, img, desc, c4_browse_ajax)
        return
        return
                  
def addDir(name,url,mode,iconimage,desc='',page='',link=False):
        if not page=='':
           u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&desc="+urllib.quote_plus(desc)+"&pageToken="+str(page)
        else:
           u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name) +"&desc="+urllib.quote_plus(desc)+"&pageToken="  
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def getmode(url):
    if url and url.endswith('/'):
        url = url[:-1]
    if 'videoid=' in url:
        url = url.split('videoid=')[1]
        return (url, 1007)
    if 'channelid=' in url:
        url = url.split('channelid=')[1]
        return (url, 1001)
    if '/channel/' in url:
        url = os.path.split(url)[1]
        return (url, 1001)
    if '/user/' in url:
        url = os.path.split(url)[1]
        return (url, 1005)
    if 'channel_id=' in url:
        url = url.split('channel_id=')[1]
        if '&' in url:
            url = url.split('&')[0]
        return (url, 1001)
    if 'userchannel=' in url:
        url = url.split('userchannel=')[1]
        return (url, 1005)
    if 'user_channel=' in url:
        url = url.split('user_channel=')[1]
        if '&' in url:
            url = url.split('&')[0]
        return (url, 1005)
    if 'playlistid=' in url:
        url = url.split('playlistid=')[1]
        return (url, 1006)
    if 'playlist_id=' in url:
        url = url.split('playlist_id=')[1]
        if '&' in url:
            url = url.split('&')[0]
        return (url, 1006)
    if '/playlist/' in url:
        url = os.path.split(url)[1]
        return (url, 1006)
    if 'video_id=' in url:
        url = url.split('video_id=')[1]
        if '&' in url:
            url = url.split('&')[0]


def getlist(url = None, name = None):
    print 'url', url
    if url is not None and url.startswith('plugin:'):
        url, mode = getmode(url)
        print 'url,mode', url, mode
    else:
        return
    if mode == None:
        mainmenu(list1)
    elif mode == 1001:
        submenu(name, url, '')
    elif mode == 1002:
        print 'url', url
        getviedoList(name, url, page)
    elif mode == 1003:
        getplayList(name, url, page)
    elif mode == 1004:
        if not url.startswith('plugin://'):
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + url
        addDir('link', url, 1007, '', '', 1, link=True)
    elif mode == 1005:
        print '', url
        chid = getchannelid(url)
        submenu(name, chid, page='')
    elif mode == 1006:
        print 'url', url
        url = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=' + url + '&maxResults=11&order=date&key=' + KEYV3
        name = 'playlist'
        page = ''
        getviedoList(name, url, page)
    elif mode == 1007:
        if not url.startswith('plugin://'):
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + url
        print 'url', url, mode
        addDir('link', url, 1007, '', '', 1, link=True)
    return


def process_mode(list1 = []):
    sys.argv[2]=sys.argv[2].strip()
    params = get_params()
    url = None
    name = None
    mode = None
    page = ''
    print 'url', url
    print 'mode', mode
    try:
        url = urllib.unquote_plus(params['url'])
    except:
        pass

    try:
        name = urllib.unquote_plus(params['name'])
    except:
        pass

    try:
        mode = int(params['mode'])
    except:
        pass

    try:
        page = str(params['pageToken'])
    except:
        pass

    print 'Mode: ' + str(mode)
    print 'URL: ' + str(url)
    print 'Name: ' + str(name)
    print 'page: ' + str(page)
    if type(url) == type(str()):
        url = urllib.unquote_plus(url)
    if url is not None and url.startswith('plugin:'):
        url, mode = getmode(url)
        print 'url,mode', url, mode
    if mode == None:
        mainmenu(list1)
    elif mode == 1001:
        submenu(name, url, '')
    elif mode == 1002:
        print 'url', url
        getviedoList(name, url, page)
    elif mode == 1003:
        getplayList(name, url, page)
    elif mode == 1004:
        if not url.startswith('plugin://'):
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + url
        addDir(name, url, 1007, '', '', 1, link=True)
    elif mode == 1005:
        print '', url
        chid = getchannelid(url)
        submenu(name, chid, page='')
    elif mode == 1006:
        print 'url', url
        url = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=' + url + '&maxResults=11&order=date&key=' + KEYV3
        name = 'playlist'
        page = ''
        getviedoList(name, url, page)
    elif mode == 1007:
        print "urlxx",url
       
        if not url.startswith('plugin://'):
                    url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + url.strip()
                    from tube_resolver import getvideo
                    stream_link=getvideo(url)
                    playlink(stream_link)
        #playlink(url) 
        addDir(name, url, 1007, '', '', 1, link=True)
    elif mode == 1000:
        if not url.startswith('plugin://'):
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + url
        getlist(url, name)
    return
