# -*- coding: utf8 -*-
try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
import urllib2,urllib
import re
import httplib
import time,itertools
import urlresolver
__settings__ = xbmcaddon.Addon(id='plugin.video.arabhd')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = (sys.argv[0])
baseurl='http://www.arabhd.co/'
def read_url2(url):
        import urllib2
        try:
            req = urllib2.Request(url)
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
            return data
        except urllib2.URLError, e:
            print 'URL: '+url
            if hasattr(e, 'code'):
                print 'We failed with error code - %s.' % e.code
                #xbmc.executebuiltin("XBMC.Notification(musichcannels,We failed with error code - "+str(e.code)+",10000,"+icon+")")
            elif hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: %s' %e.reason
                #xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")


def read_url3(url):#redirect error
        try:


           p = urllib2.build_opener(urllib2.HTTPCookieProcessor).open(url)

           return p.read()
        except:
                addDir("Download failed:","","",'')
                #xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")                
                return None


def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'arabhd.co')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link

def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial

    return inner

def getCategories():
	addDir('Search','http://www.arabhd.co/?s=',3,'img/0.png',1)
	
        addDir('••احر الاضافات••','http://arabhd.co/online/',11,'img/01.png',1)
	
	addDir('••أفـــلام أجنبية••','http://arabhd.co/online/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/',11,'img/02.png',1)
	addDir('••أفـــلام عربية••','http://arabhd.co/online/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%b9%d8%b1%d8%a8%d9%8a/',11,'img/03.png',1)
	addDir('••بوليود••','http://arabhd.co/online/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%87%d9%86%d8%af%d9%8a/',11,'img/04.png',1)
	#addDir('••برامج-تليفزيونية••','http://arabhd.co/category/%d8%a8%d8%b1%d8%a7%d9%85%d8%ac-%d8%aa%d9%84%d9%8a%d9%81%d8%b2%d9%8a%d9%88%d9%86%d9%8a%d8%a9',11,'img/6.png',1)

        #addDir('••أفــلام مصنفة••','url',5,'img/5.png',1)
       	#addDir('••مسلسلات أون لاين••','url',55,'img/6.png',1)

        #addDir('••منوعـــات••','http://www.arabhd.co/new/category/%d9%85%d9%86%d9%88%d8%b9%d8%a7%d8%aa-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/',11,'img/7.png',1)
        addDir('••مسلسلات عربية أون لاين••','http://arabhd.co/online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA/',11,'img/05.png',1)
        addDir('••أفلام أنمي أون لاين••','http://arabhd.co/online/category/%d8%a8%d8%b1%d8%a7%d9%85%d8%ac-%d8%aa%d9%84%d9%81%d8%b2%d9%8a%d9%88%d9%86/',11,'img/06.png',1)
        #addDir('••المصـــــارعه••','http://arabhd.co/online/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%83%d8%b1%d8%aa%d9%88%d9%86/',11,'img/9.jpg',1)
        
        
        
        
      
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url=url+search_entered
        print "mfarajx4_url",url
          
        getVideos("Search",url,1)        
        
        
        
def getVideos(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                  
                  url_page=urlmain+'/page/'+str(page)
                  
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
             
               regx='''<p class="link"><a href="(.*?)"><p style=".*?">(.*?)</p>'''
               regx='''<a href="(.*?)">\s*<img .*? src="(.*?)" class="attachment-col wp-post-image" alt="(.*?)" /></a>'''
	       regx='''<a href="(.*?)">\s*<img .*? src="(.*?)" class="attachment-col wp-post-image" alt="(.*?)" />'''    			    
               regx='''<a href="(.*?)">\s*<img .*? src="(.*?)" class="attachment-col size-col wp-post-image" alt="(.*?)" .*? />'''    	
        	
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
 
                        
                      
                        url=href
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,2, image)

               
               addDir('next page>',urlmain, 1,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))


              

        
def getblock(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                  
                  url_page=urlmain+'"/"/?page='+str(page)
                  
                  
               else:
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
                   
               regx='''<a href="(.*?)">\s*<img .*? src="(.*?)".*?alt="(.*?)".*?/> '''              
					
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        Etitle=title.replace("فيلم","")
                        #try:name=name.decode('unicode_escape').encode('ascii','ignore')
                        #except:pass
                        addDir(name,url,2, image,page)
               
               addDir('next page>',urlmain, 1,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))


              

def getVideosTV(name1, urlmain,page):
               if page>1:
                  #page-2
                  url_page=urlmain+'/page/'+str(page)+"/"
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               
               #regx=''' <a href="(.*?)" .*? >\s*<img .*? src="(.*?)" .*? alt="(.*?)"/>'''
               regx='''<a href="(.*?)" title="(.*?)">\s*<img.*?src="(.*?)" class='''#"attachment-w_224x328 wp-post-image" alt="Rush 2013_1" /><h1 class="title_loop">مشاهدة وتحميل فيلم Rush 2013 مترجم اون لاين وتحميل مباشر</h1> </a></div><div '''
               regx='''<a href="(.*?)" title="(.*?)">\n.*?src="(.*?)" class='''               
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,title ,image in match:
                        pic = ''
 
                        url=href
                        
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,13, image)
                        
               
               
               
               #addDir("next page",urlmain,12,'http://www.tachyonpunch.com/comics/images/next_icon.png',str(page+1))
def getVideosEpisodes(name1, urlmain,page):
               if page>1:
                  #page-2
                  url_page=urlmain+'/page/'+str(page)+"/"
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               try:content=content.split('<ul id="recent_intery">')[0]
               except:pass
               
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               
               #regx=''' <a href="(.*?)" .*? >\s*<img .*? src="(.*?)" .*? alt="(.*?)"/>'''
               regx='''<a href="(.*?)" title="(.*?)">\s*<img.*?src="(.*?)" class='''#"attachment-w_224x328 wp-post-image" alt="Rush 2013_1" /><h1 class="title_loop">مشاهدة وتحميل فيلم Rush 2013 مترجم اون لاين وتحميل مباشر</h1> </a></div><div '''
               regx='''<a href="(.*?)" title="(.*?)">\n.*?src="(.*?)" class='''
               regx='''<a href="(.*?)" title="(.*?)">'''
               regximage='''<img width="224" height="328" src="(.*?)" class=".*?"'''
               #regx='''<div class="block_loop">
                            #<a href="http://www.aflamk.tv/show_online/%d9%85%d8%b3%d9%84%d8%b3%d9%84-%d8%b3%d8%a7%d8%ad%d8%b1%d8%a9-%d8%a7%d9%84%d8%ac%d9%86%d9%88%d8%a8-%d8%a7%d9%84%d8%ad%d9%84%d9%82%d8%a9-5-hd720-%d8%a7%d9%88%d9%86%d9%84%d8%a7%d9%8a%d9%86-witch-south/" title="مسلسل ساحرة الجنوب الحلقة 5 HD720 اونلاين Witch South">
                                #<img width="224" height="328" src="http://www.aflamk.tv/wp-content/uploads/3331-224x328.png" class="attachment-w_224x328 wp-post-image" alt="333" />  '''
               match = re.findall(regx,content, re.M|re.I)
               try:image = re.findall(regximage,content, re.M|re.I)[0]
               except:image=''
               
               if not match :
                       return
               print "match",match
               
               for href,title  in match:
                        pic = ''
 
                        url=href
                        title=title.replace("&#8211","")
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,2, image)
                        
               
               
               
               #addDir("next page",urlmain,12,'',str(page+1))


def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    addDir(server,href,7,'img/server.png')
            		
def get_servers(url):
        data=read_url(url)
        #http://cima4up.com/wp-content/themes/yourcolor/servers/server.php?q=2257&i=2
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,7):
          url='http://arabhd.co/online/wp-content/themes/YourColor/servers/server.php?q='+id+'&i='+str(i)
          print url
          addDir('server'+str(i),url,4, 'img/server.png')
        
def get_servers2(url):
	        data=read_url(url)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''
                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                #regx5='''<IFRAME .+? SRC="(.+?)" .+?></IFRAME>'''
               
                #match1 = re.findall(regx1,data, re.M|re.I)
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return



def resolve_host(url):

      
    #hosted_media = urlresolver.HostedMediaFile(url=url, title="host")
      stream_link = urlresolver.resolve(url)
      print "stream_link",stream_link
      if stream_link is None or "unresolvable" in stream_link:
            addDir("Error:unresolvable link","",1,"",1)
            return
      playlink( stream_link) 
      

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	


def addDir(name,url,mode,iconimage,page=1):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def playlink(url):
            
	    xbmc.Player().play(url)
	    sys.exit(0)
            return
	    listItem = xbmcgui.ListItem(path=str(url))
	    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listItem)

              
params=get_params()
url=None
name=None
mode=None
initial=None
max=None
rating=None
cast=None
year=None
genre=None
duration=None
writer=None
director=None

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
	
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        page=1


		


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
if mode==None or url==None or len(url)<1:
        print ""
        getCategories()
       
elif mode==1:
        print ""+url
        getVideos(name,url,page)
elif mode==11:
        print ""+url
        getVideos(name,url,page)
        
  
elif mode==8:
        print ""+url        
        getblock(name,url,page)
        
        
elif mode==12:
        print ""+url
        getVideosTV(name,url,page)        
elif mode==13:
        print ""+url
        getVideosEpisodes(name,url,page)   
                
        
        
        
elif mode==2:
        print ""+url
        get_servers(url)
        


elif mode==3:
        print ""+url
        search(url)		


elif mode==4:
        print ""+url
        get_servers2(url)
        
elif mode==5:
        print ""+url        
        
        GENRES(url)
elif mode==55:
        print ""+url         
        seris(url)
elif mode==6:
        print ""+url
        get_hostlink(url)
elif mode==7:
        resolve_host(url)
        
elif mode==40:
        playlink(url)        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
