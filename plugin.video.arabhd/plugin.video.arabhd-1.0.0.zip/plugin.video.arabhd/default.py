# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,getnet,postData,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error
################''
baseurl='http://aflam06.com'
from tsresolver import resolve
##########################################parsing tools


def showmenu():
        addDir('ٍSearch','http://arabhd.co/?s=',103,'img/1.png','',1)

        addDir('الافلام الاجنبيه','http://arabhd.co/category/movies/',100,'img/1.png','',1)
        addDir('المسلسلات الاجنبيه','http://arabhd.co/category/series/',100,'img/2.png','',1)
	addDir('الافلام العربيه','http://arabhd.co/category/arabic-movies/',100,'img/3.png','',1)
        addDir('افلام الزمن الجميل','http://arabhd.co/category/classic-arabic-movies/',100,'img/4.png','',1)              
        addDir('افلام انيمي مدبلجه','http://arabhd.co/category/animation-movies/animation-movies-arabic/',100,'img/5.png','',1)        
        addDir('افلام انيمي مترجمه','http://arabhd.co/category/animation-movies/animation-movies-1/',100,'img/6.png','',1)
        addDir('افلام هندي','http://arabhd.co/category/indian-movies/',100,'img/7.png','',1)    
       
        addDir('برامج تلفزيونيه','http://arabhd.co/category/%D9%85%D9%86%D9%88%D8%B9%D8%A7%D8%AA/',100,'img/8.png','',1)

       
        

# -*- coding: utf8 -*-



def years():###nt active-movies 110,series 210
        list=[]
        for i in range(1950,2019):
             #http://tellymov.com/s/year/2006
             list.append(i)
        list.reverse()     
        for i in list:
                
             addDir(str(i),'http://www.tfarjo.com/films/annee/film-'+str(i)+'-streaming/',100,'','',1)                 
                  
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["1" ,"2", "3" ,"4" ,"5" ,"6" ,"7" ,"9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://www.tfarjo.com/films/alphabet/'+letter.lower()+"/",100,'','',1)
###################################movies
			  

        
        
          
 
          
       


def search(name,sterm,page):##may pastte code of getmovies here
                surl='http://arabhd.co/?s='

                if page>1:
                    
                        #http://arabhd.co/page/3/?s=love
                       
                        page_url='http://arabhd.co/page/'+str(page)+'/?s='+sterm
                  
                else:
                
                        page_url=surl+sterm
                 
##################################################################                
                
               
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('"moviefilm"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    print "title",title
                    
                    try:
                            addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>15:
                    
                      addDir("next page",sterm,103,'img/next.png','',str(page+1))

                



               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                    #http://arabhd.co/category/movies/page/3/
                        page_url=url+"page/"+str(page)+"/"
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('"moviefilm"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<div class="movief"><a href=".*?">(.*?)</a>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            image="http:"+image

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    print "title",title
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>15:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                









###############################################series


def getseries(name,url,page):##series
                if page>1:
                    
                        #http://www.tfarjo.com/films/page/32
                        page_url=url+"page/"+str((page-1)*16)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
                #regx='''<a href="(.*?)"><li class="s1"><img src="(.*?)" alt=""><span></span>(.*?)<br><span></span></li></a>'''
               # match=re.findall(regx,data, re.M|re.I)
                #print "match",match
                #sys.exit(0)
                blocks=data.split('class="image"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            href=href.split('/saison')[0]
                    except:
                            trace_error()
                            continue

                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,201,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>15:
                    
                   addDir("next page",url,200,'img/next.png','',str(page+1))

                
                





                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return
                regx='''<div class="panel-body"> <a href="(.*?)"><span class="glyphicon glyphicon-triangle-right"></span>(.*?)</a>'''
                                                                           
                seasons=re.findall(regx,data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,1,'','',1)
                        

                                           
                                    


def getepisodes(name,url,page):##series

                print "page",page
               
                if page>1:
                    
                        #http://www.movs4u.com/movie/page/2/
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=readnet(page_url)
               
                
                
               
                if data is None:
                    return
               
                #blocks=data.split('قائمة الحلقات:')
                regx='''<li><a target="_blank" href="(.*?)" title=".*?">(.*?)</a></li>'''
                match=re.findall(regx,tblock, re.M|re.I)
                print "match",match
                for href,title in match:
                    addDir(title,href,1,'','',1,maintitle=True)    
                i=0
                return 


#######################################host resolving                                                    
                    

def getservers(name,url):
                
                data=postData(url, {'view':'1'}, 'arabhd.co', url)              
                   
                regx="<link.*?rel='shortlink'.*?href='(.*?)'.*?/>"
                id=re.findall(regx,data, re.M|re.I)[0].split("=")[1]
                print id
                for i in range(1,10):
                        href='http://arabhd.co/wp-content/themes/YourColor666/servers/server.php?q='+id+'&i='+str(i)
                        data=readnet(href)
                        data=data.replace("'",'"')
                        regx='''<iframe.*?src="(.*?)".*?></iframe'''
                        try:href=re.findall(regx,data, re.M|re.I)[0]
                        except:break
                        server=getDomain(href)
                        addDir(server,href,2,'img/server.png','',1)

                return

                
                 
def resolve_host(surl):
       
       print "surl",surl
       url='http://www.tfarjo.com/getlink'
       host='www.tfarjo.com'
       Referer=surl.split("&")[0]
       id=surl.split("&")[1]
       
       print "Referer,id",Referer,id
       #data={'csrf_test_name':csrf,'movie':'Mjk3Nyx2Ziwy'}
       if 'serie' in Referer:
                data=postdata_series(url,  host, Referer,id)
       else:        
         data=postdata(url,  host, Referer,id)
       print "data2",data
       if data is None:
          addDir("Error:no links found",'rt',0,"",1,link=True)     
       regx='''src="(.*?)"'''
       href=re.findall(regx,str(data), re.M|re.I)[0]
       link=resolvehost(href)
       addDir("play",link,0,"",1,link=True)

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        stream_url=resolve(url)
        playlink(stream_url)
        
        #resolvehost(url)        
elif mode==3:
        print ""+url
        playlink(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        years()	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
        sterm = getsearchtext()      
         
        search("Search",sterm,page) 
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
