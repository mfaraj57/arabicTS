#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
from yttools import *

def infolist():
    list1=[]
    list1.append(('FajrTube','UC_5rtUaObNO0SEHm4FkbZtA',1001,"img/1.png", '',1))##user channel id
    return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))

