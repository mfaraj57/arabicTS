# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,getnet,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error
################''
baseurl='http://alfajertv.com'

##########################################parsing tools
#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
from yttools import *

def infolist():
  
  list1=[]
 
  
  list1.append(('FajrTube','UC_5rtUaObNO0SEHm4FkbZtA',1001,"img/1.png", '',1))##user channel id
  
  process_mode(list1 )
################################################################333


def showmenu():
        #addDir('Search','http://alfajertv.com',103,'img/search.png','',1)
        

        addDir('بث مباشر','http://alfajertv.com',300,'img/2.png','',1)
        addDir('FajrTube','UC_5rtUaObNO0SEHm4FkbZtA',1001,'img/1.png','',1)
        addDir('الافلام الاجنبيه','http://alfajertv.com/playlist/3/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',100,'img/3.png','',1)
        addDir('الافلام العربيه','http://alfajertv.com/playlist/4/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9',100,'img/4.png','',1)

        addDir('افلام هندي','http://alfajertv.com/playlist/4002915/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D9%87%D9%86%D8%AF%D9%8A%D8%A9',100,'img/5.png','',1) 
        addDir('افلام مدبلجه','http://alfajertv.com/playlist/4002907/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D9%85%D8%AF%D8%A8%D9%84%D8%AC%D8%A9',100,'img/6.png','',1) 






	
        addDir('المسلسلات','http://alfajertv.com/mediacategory/1',200,'img/7.png','',1)
        return
        

  
def livechannels():##not active movies 111,series 210

        addDir('قناة 1الضفه','http://alfajertv.com/live/live-westbank-1.php',301,'img/2.png','',1)
        addDir('قناة 2 الضفه','http://alfajertv.com/live/live-westbank-2.php',301,'img/2.png','',1)
	addDir('قناة 3 الضفه ','http://alfajertv.com/live/live-westbank-3.php',301,'img/2.png','',1)
        addDir('قناة 4 الضفه ','http://alfajertv.com/live/live-westbank-4.php',301,'img/2.png','',1)	
        addDir('قناة 5 الضقه','http://alfajertv.com/live/live-westbank-5.php',301,'img/2.png','',1)



        addDir('غزة قناة 1','http://alfajertv.com/live/live-gaza-jordan-1.php',301,'img/2.png','',1)
        addDir('غزه قناة 2','http://alfajertv.com/live/live-gaza-jordan-2.php',301,'img/2.png','',1)
	addDir('غزه قناة 3','http://alfajertv.com/live/live-gaza-jordan-3.php',301,'img/2.png','',1)
        addDir('غزة قناة 4','http://alfajertv.com/live/live-gaza-jordan-4.php',301,'img/2.png','',1)	


        addDir('دولي','http://alfajertv.com/live/live-international.php',301,'img/2.png','',1)




           


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  

        
        
         
 
          
       


def search(name,sterm,page):##may pastte code of getmovies here
                surl='http://alfajertv.com/index.php?act=search&type=posts&text='

                if page>1:
                    
                        #http://alfajertv.com/index.php?act=search&type=posts&text=%D8%A7%D9%84%D8%B0%D8%A6%D8%A7%D8%A8&page=2
                        filename=os.path.basename(url)
                        page_url='http://alfajertv.com/index.php?act=search&type=posts&text='+sterm+"&page="+str(page)
                  
                else:
                
                        page_url=surl+sterm
                print "url_page",page_url
                data=readnet(page_url)           
##################################################################                
                
            
               
                if data is None:
                    return
               
                
               
                blocks=data.split('class="item"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<p class="title">(.*?)</p>'''
                    regx='''<p class="title">(.*?)</p>'''
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)'''                    
                                     
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    
                    addDir(title,href,1,'','',1)
                    
               
                   
                
                if len(blocks)>8:
                    
                   addDir("next page",url,103,'img/next.png','',str(page+1))

                
                





               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                    
                        #http://alfajertv.com/playlist/3/page-2/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9
                        filename=os.path.basename(url)
                        npage="page-"+str(page)
                        page_url=url.replace(filename,npage+"/"+filename)
                        
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('class="item"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<p class="title">(.*?)</p>'''                    
                    try:
                            title=re.findall(regx,block.replace("\n",""), re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    if True:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    else:
                            trace_error()
                            image=''
                            pass                            
                    
                   
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>8:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                









###############################################series


def getseries(name,url,page):##series
                if page>1:
                    
                        #http://alfajertv.com/playlist/3/page-2/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9
                        filename=os.path.basename(url)
                        npage="page-"+str(page)
                        page_url=url.replace(filename,npage+"/"+filename)
                        
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('class="item"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<p class="title">(.*?)</p>'''                    
                    try:
                            title=re.findall(regx,block.replace("\n",""), re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,202,image,'',1)
                    except:
                            trace_error(0)
                            continue
               
                   
                
               


                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,url,page):##series

                if page>1:
                    
                        #http://alfajertv.com/playlist/3/page-2/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9
                        filename=os.path.basename(url)
                        npage="page-"+str(page)
                        page_url=url.replace(filename,npage+"/"+filename)
                        
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('class="item"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<p class="title">(.*?)</p>'''                    
                    try:
                            title=re.findall(regx,block.replace("\n",""), re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            image=''
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1)
                    except:
                            trace_error(0)
                            continue
               

#######################################host resolving                                                    
def getData(url, data = {}, host = '', Referer = ''):
    import requests
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.get(url, headers=headers)
    htmldata = r.content
    return htmldata
                    

def getservers(name,url):
                data=readnet(url)
                regx='''<source type="video/mp4" src="(.*?)">'''
                href=re.findall(regx,data, re.M|re.I)[0]
                mhref=href
                addDir("play",href,0,'','',1,link=True)
                regx='''<track kind="subtitles" default srclang="ar" label="Arabic" src="(.*?)">'''
                try:href=re.findall(regx,data, re.M|re.I)[0]
                except:return
                
                #href=os.path.abspath(href)+"/"+os.path.basename(mhref).replace("mp4","srt")
                dfile=name+".srt"
                
                #urllib.urlretrieve(href, "d:/"+dfile)
                try:
                        srt = getData(href, data = {}, host = 'alfajertv.com', Referer = url)
                        drfile=open("/media/hdd/"+dfile,"w")
                        drfile.write(srt)
                        drfile.close()
                except:
                        pass
                
def getliveservers(url):


     data=readnet(url)
     regx='''<a.*?href="(.*?)".*?id=".*?".*?data-title="(.*?)"></a>'''
     regx2='''<a.*?href='(.*?)'.*?id=".*?".*?data-title="(.*?)"></a>'''
     match=re.findall(regx,data, re.M|re.I)
     match2=re.findall(regx2,data, re.M|re.I)
     for href,server in match:
             
             addDir(server,href,0,"img/play.png",'',1,link=True)

     for href,server in match2:
             addDir(server,href,0,"img/play.png",'',1,link=True)

        
def resolve_host(url):
        resolve_host(url)    

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        resolvehost(url)        
elif mode==0:
        print "xxxf"+url
        playlink(url)
elif mode==300:
        print ""+url
        livechannels()
elif mode==301:
        print ""+url
        getliveservers(url)          
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
        sterm = getsearchtext()      
         
        search("Search",sterm,page) 
##extra years 104,genres 105,a-z 106        
###series        
elif mode==1001:

	infolist()

elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           
elif mode==1002:
	print ""+url
        infolist()  
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
