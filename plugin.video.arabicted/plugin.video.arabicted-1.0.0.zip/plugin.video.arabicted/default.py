# -*- coding: utf8 -*-


import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,getnet,playlink,getDomain,xbmc,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error
################''
baseurl='https://www.ted.com'

##########################################parsing tools


def showmenu():
        addDir('ٍSearch','https://www.ted.com/talks?language=ar&sort=newest&q=',103,'img/search.png','',1)

        addDir('المواضيع','https://www.ted.com/talks?language=ar',100,'img/1.png','',1)
        return
       

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):#not active mvoies 112,series 212
		abc = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'/?letter='+letter,100,'',1)
			
###################################movies
			  

        
        
         
 
          
       


def search(name,sterm,page):##may pastte code of getmovies here
                surl='ttps://www.ted.com/?s='

                if page>1:
                    
                        #https://www.almstba.tv/video/category.php?cat=english-movies&page=2&order=DESC
                       
                        page_url='https://www.ted.com/talks?language=ar&page='+str(page)+'&q='+sterm+'&sort=newest'
                  
                else:
                
                        page_url='https://www.ted.com/talks?language=ar&page=1&q='+sterm+'&sort=newest'
                print "url_page",page_url
                data=readnet(page_url)           
##################################################################                

                
               
                blocks=data.split("class='talk-link'")
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                    regx="href='(.*?)'"
                    
                    if True:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            href="https://www.ted.com"+href
                    else:
                            trace_error()
                            continue

                    regx='''<a.*?lang='ar'>(.*?)</a>'''                    
                    try:
                            title=re.findall(regx,block.replace("\n",""), re.M|re.I)[0]
                            title=title.strip()
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    print "image",image

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
   

                
                
               
                   
                
                if len(blocks)>30:
                    
                   addDir("next page",sterm,103,'img/next.png','',str(page+1))

                
                





               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                    
                        #https://www.ted.com/talks?language=ar&page=2
                        page_url=url+"&page="+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split("class='talk-link'")
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    block=block.replace(';','')
                    regx="href='(.*?)'"
                   
                    if True:
                            href=re.findall(regx,block, re.M|re.I)[0]
                            href="https://www.ted.com"+href
                    else:
                            trace_error()
                            continue

                    regx='''<a.*?lang='ar'>(.*?)</a>'''                    
                    try:
                            title=re.findall(regx,block.replace("\n",""), re.M|re.I)[0]
                            title=title.strip()
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>8:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                









###############################################series


def getseries(name,url,page):##series
                if page>1:
                    
                        #https://www.almstba.tv/video/category.php?cat=english-movies&page=2&order=DESC
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=readnet(page_url)           
                
                
               
                if data is None:
                    return
               
                
               
                blocks=data.split('class="thumbnail animation-2"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''<img.*?src="(.*?)" alt="(.*?)".*?/>'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    
                    try:
                      addDir(title,href,100,image,'',1,maintitle=True)
                    except:
                            trace_error(0)
                            continue
               
                   
                
                if len(blocks)>50:
                    
                   addDir("next page",url,100,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))




                    
def getseasons(name,url,page):##series

                 
                data=readnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,url,page):##series

                print "page",page
               
                if page>1:
                    
                        #http://www.movs4u.com/movie/page/2/
                        page_url=url+"/page/"+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
               
                data=readnet(page_url)
               
                
                
               
                if data is None:
                    return
               
                #blocks=data.split('قائمة الحلقات:')
                regx='''<li><a target="_blank" href="(.*?)" title=".*?">(.*?)</a></li>'''
                match=re.findall(regx,tblock, re.M|re.I)
                print "match",match
                for href,title in match:
                    addDir(title,href,1,'','',1,maintitle=True)    
                i=0
                return 


#######################################host resolving                                                    
                    

def getservers(name,url):
                data=readnet(url)
                #"name":"Arabic","low":"https://download.ted.com/talks/BobInglis_2017X-low-ar.mp4","high":"https://download.ted.com/talks/BobInglis_2017X-480p-ar.mp4"}
                item=finddata(data,'"name":"Arabic",','}')
                print "item",item
               # sys.exit(o)

                regx='''"(.*?)":"(.*?)"'''
                
                match=re.findall(regx,item, re.M|re.I)
                print "match",match
                for qual,href in match:
                        
                    addDir(qual,href,2,"img/server.png",'',1,link=True)
                #http://aflam06.com/wp-content/themes/YourColor/servers/server.php?q=11878&i=1
               
                 
def resolve_host(url):
        resolve_host(url)    

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        resolvehost(url)        
elif mode==3:
        print ""+url
        playlink(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
        sterm = getsearchtext()      
         
        search("Search",sterm,page) 
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
