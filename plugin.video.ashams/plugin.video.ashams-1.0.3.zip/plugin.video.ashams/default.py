# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py


try:import sys, syspath
except:pass
import os, sys
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
from addon.common.net import Net

import StringIO

__settings__ = xbmcaddon.Addon(id='plugin.video.ashams')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://www.ashams.com/'
host='www.ashams.com'
####functions
def read_url2(url):
      #try:  
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.ashams.com')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
      #except:
            #addDir("Download failed:"+str(e.reason),"","",'') 
def read_url(url):
     
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
    
def readnet(url):
            
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      
def decodeHtml(text):
    text = text.replace('&auml;', 'ae').replace('&Auml;', 'Ae').replace('&ouml;', 'oe').replace('&ouml;', 'Oe').replace('&uuml;', 'ue')
    text = text.replace('&Uuml;', 'Ue').replace('&szlig;', 'ss').replace('&amp;', '&').replace('&quot;', '"').replace('&gt;', "'")
    text = text.replace('&#228;', 'ae').replace('&#246;', 'oe').replace('&#252;', 'ue').replace('&#223;', 'ss').replace('&#8230;', '...')
    text = text.replace('&#8222;', ',').replace('&#8220;', "'").replace('&#8216;', "'").replace('&#8217;', "'").replace('&#8211;', '-')
    text = text.replace('&#8230;', '...').replace('&#8217;', "'").replace('&#128513;', ':-)').replace('&#8221;', '"')
    text = text.replace('&#038;', '&').replace('&#039;', "'")
    text = text.replace('\\u00c4', 'Ae').replace('\\u00e4;', 'ae').replace('\\u00d6', 'Oe').replace('\\u00f6', 'oe')
    text = text.replace('\\u00dc', 'Ue').replace('\\u00fc', 'ue').replace('\\u00df', 'ss')
    text = text.replace('&#196;', 'Ae').replace('&#228;', 'ae').replace('&#214;', 'Oe').replace('&#246;', 'oe').replace('&#220;', 'Ue').replace('&#252;', 'ue')
    text = text.replace('<br />\n', '')
    return text 
def removeunicode(data):
             
             
            
              try:
                    type(data)
                    data=data.decode('unicode_escape').encode('ascii','replace').replace("?","").strip()
        
              except:
                    pass
              
              return data
              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

                genreliste=[]
                #http://eldrama.com/search/site/%D8%B7%D8%B1%D9%8A%D9%82%D9%8A
                #genreliste.append(("Search", 'http://ashams.com/search/site/',103,'img/ar.png','',1))
                genreliste.append(("مسلسلات رمضان 2016", 'http://www.ashams.com/new_media/2044/',200,'img/2015.png','',1))
		genreliste.append(("مسلسلات رمضان 2015", 'http://www.ashams.com/new_media/1680/',200,'img/2015.png','',1))
		genreliste.append(("مسلسلات رمضان 2014", 'http://www.ashams.com/new_media/1345/',200,'img/2014.png','',1))
		genreliste.append(("مسلسلات رمضان 2013", 'http://www.ashams.com/new_media/1091/',200,'img/2013.png','',1))
		genreliste.append(("مسلسلات عربية", 'http://www.ashams.com/new_media/551/',200,'img/ar.png','',1))
		genreliste.append(("مسلسلات تركية", 'http://www.ashams.com/new_media/552/',200,'img/tur.png','',1))
		genreliste.append(("مسلسلات تركية مترجمة", 'http://www.ashams.com/new_media/608/',200,'img/tur2.png','',1))
	       
	        genreliste.append(("مسلسلات هنديه", 'http://www.ashams.com/new_media/1648/',200,'img/tur2.png','',1))
		genreliste.append(("مسلسلات كوريه", 'http://www.ashams.com/new_media/1647/',200,'img/tur2.png','',1))
		genreliste.append(("افلام عربية", 'http://www.ashams.com/new_media/554/',100,'img/film.png','',1))
	        genreliste.append(("افلام هنديه", 'http://www.ashams.com/new_media/578/',100,'img/film.png','',1))	
		genreliste.append(("أفلام وثائقية", 'http://www.ashams.com/new_media/576/',100,'img/docu.png','',1))
		genreliste.append(("مسلسلات اطفال", 'http://www.ashams.com/new_media/565/',2001,'img/cartoon.png','',1))
		genreliste.append(("منوعات", 'http://www.ashams.com/new_media/1156/',2001,'img/cartoon.png','',1))
	        #genreliste.append(("منوعات", 'http://www.ashams.com/new_media/1156/',2001,'img/cartoon.png','',1))	
	        genreliste.append(("اذاعة الشمس مباشر", "rtmp://live1.ashams.com/live playpath=live swfUrl=http://www.ashams.com/admin-aps/inc/player/player.swf pageUrl=http://www.ashams.com/live2.php",22,'img/cartoon.png','',1))	
	
               
		#3genreliste.append(("Movie top 100", baseurl+'/movies/sort=hits/order=desc',100))
		
		#genreliste.append(("Movies Genre", baseurl,101))
		#genreliste.append(("Movies A-Z", baseurl,102))
		

		#genreliste.append(("TV-Shows Featured", baseurl+"/featured-tv-shows",200))
		#genreliste.append(("TV-Shows Genre", baseurl,201))
		#genreliste.append(("TV-Shows A-Z",baseurl,202))
		#genreliste.append(("TV-Shows Sort List", "http://watchmovies.to/tv-shows",107))
		#genreliste.append(("Watchlist","dump",108))

		#genreliste.insert(0, ("--- Search ---", "http://online.filmovisaprevodom.org/?s=",103))
                for title, url, mode,pic,desc,page in genreliste:
                    addDir(title, url, mode, pic,desc,page)
                    
def getgenre(name='movies'):##cinema and tv featured

                data=read_url(baseurl)
                if data is None:
                    return
		match = re.findall('menu_genre">(.*?)</ul>', data, re.S|re.I)
		if match:
			Cats = re.findall('href=".*?">(.*?)<',match[0], re.S)
			if Cats:
				for Cat in Cats:
					#self.genreliste.append((Cat, True))
                                        if name=='movies':
                                           addDir(Cat,baseurl+"/category/genre="+Cat,100,'')
                                        else:
                                           url=baseurl+"/tv-shows/genre=%s" % Cat   
                                           addDir(Cat,url,200,'')

def getA_Z(name='movies'):
		abc = ["0-9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        if name=='movies':
			  addDir(letter,baseurl+"/category/letter="+letter.lower(),100,'',1)
			else:
                          url = baseurl+"/tv-shows/letter=%s" % letter.lower()    
                          addDir(letter,url,200,'',1)    
###################################movies		 
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getseries("Search",url,0)
                                        
def getvideos_cinema(name,urlmain,page):##cinema and tv featured
                if page>1:
                  #page-2
                 #http://www.hakchouf.com/films_fr.php?page=%205
                        #http://www.ashams.com/player/52867/%D9%81%D9%8A%D9%84%D9%85_%D9%86%D9%88%D8%A7%D8%B1%D8%A9_&page=2
                  url_page=urlmain+'&page='+str(page)
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url(url_page)

                if data is None:
                    return

                print "page",page
               
       
                blocks=data.split("<article class='videos'")
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block
                    block=block.lower()
                    regxhref="href='(.*?)'"
                    href=re.findall(regxhref,block, re.M|re.I)[0]
                               
                    regximg='''<img itemprop="image" src='(.*?)'>'''
                    img=re.findall(regximg,block, re.M|re.I)[0]

                    regx='''<h2 itemprop="name">(.*?)</h2></a>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,1,img,'',1)                        
               
                   
                if len(blocks)>7:
                   addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
###############################################tv shows
def getseries(name,urlmain,page):##series
                if page>0:
                  #page-2
                  #http://ashams.com/genres/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2015?page=1    
                  url_page=urlmain+'?page='+str(page)
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url2(url_page)
                print "url_page",url_page
               # print data
                #sys.exit(0)
                if data is None:
                    return
                if name=='Search':
                   regx='''<strong class="title">\s.*?<a href="(.*?)">(.*?)</a>\s.*?</strong>'''  
                else:
                   regx='''<div class='videoscat'>\n<a href='(.*?)'><img src='(.*?)'><h2>(.*?)</h2></a>'''
                
                if data:
                   
                    blocks=data.split("<div class='videoscat'>")   
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='''<a href='(.*?)'><img src='(.*?)'><h2>(.*?)</h2></a>'''
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       print "match",match
                
                    
                       for href,img,name in match:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,2002,img,'',1)      
def getseries2(name,urlmain,page):##series
                if page>0:
                  #page-2
                  #http://ashams.com/genres/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2015?page=1    
                  url_page=urlmain+'?page='+str(page)
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url2(url_page)
                print "url_page",url_page
               # print data
                #sys.exit(0)
                if data is None:
                    return
                if name=='Search':
                   regx='''<strong class="title">\s.*?<a href="(.*?)">(.*?)</a>\s.*?</strong>'''  
                else:
                   regx='''<div class='videoscat'>\n<a href='(.*?)'><img src='(.*?)'><h2>(.*?)</h2></a>'''
                
                if data:
                   
                    blocks=data.split("<div class='videoscat'>")   
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='''<a href='(.*?)'><img src='(.*?)'><h2>(.*?)</h2></a>'''
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       print "match",match
                
                    
                       for href,img,name in match:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,2002,img,'',1)                         
                
                
def getepisodes2(name,urlmain,page):##series
                if page>0:
                  #page-2
                  #http://ashams.com/genres/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2015?page=1    
                  url_page=urlmain+'?page='+str(page)
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url2(url_page)
                print "url_page",url_page
               # print data
                #sys.exit(0)
                if data is None:
                    return
                if name=='Search':
                   regx='''<strong class="title">\s.*?<a href="(.*?)">(.*?)</a>\s.*?</strong>'''  
                else:
                   regx='''<div class='videoscat'>\n<a href='(.*?)'><img src='(.*?)'><h2>(.*?)</h2></a>'''
                
                if data:
                   
                    blocks=data.split("<article class='videos'")   
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='''<a itemprop="url" href='(.*?)' target='_parent'><img itemprop="image" src='(.*?)'>'''
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       print "match",match
                
                    
                       for href,img in match:
                            name=os.path.split(href)[1]
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,1,img,'',1)      
                   
                
                                                

def getvideos_seasons(name,urlmain,page):##series
                if page>1:
                  #page-2
                  url_page=urlmain+'/page-'+str(page)+"/"
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain.strip()
                
                print "url_page",url_page
                
                data=read_url2(url_page)
                data=data.split('<div id="alleps">')[1]
                if data is None:
                    return
		regx='''class=<a itemprop="url" href='(.*?)' target='_parent'><img itemprop="image" src='(.*?)'>'''
		regx='''<a itemprop="url" href='(.*?)' target='_parent'><img itemprop="image" src='(.*?)'>'''
		
		episodes= re.findall(regx, data, re.S)
		
		
                print "episodes",episodes
  
  
		i=0
		if episodes:
			for href,image in episodes:
                              
					
			    title=os.path.split(href)[1]
			    
			    addDir(title,href,1,image,'',1)
                            i=i+1
                        
						
		else:				
                        addDir("Error:script error",urlmain,1,'','',1)



            

 


#######################################host resolving                                                    
                         

def gethosts(urlmain):##cinema and tv featured

                
                data=read_url2(urlmain)
                if data is None:
                    return
                regx1='''<iframe src="(.*?)" frameborder=0 marginwidth=0 marginheight=0 scrolling=NO allowfullscreen='true' width=640 height=400></iframe>'''
                regx2='''"src":"(.*?)"'''
                regx='''<script data-config="(.*?)" data-css='''
               

		#host1= re.findall(regx1,data, re.M|re.I)
		host2= re.findall(regx,data, re.M|re.I)
		#src="https://cdn.video.playwire.com/15880/videos/4763522/video-sd.mp4?hosting_id=15880"
		#<script data-config="//config.playwire.com/15880/videos/v2/4763522/zeus.json" data-height="542
		if 'playwire' in data:
                        regx='''<script data-config="(.*?)"'''
                        link= re.findall(regx,data, re.M|re.I)[0]
                        print "link",link
                        link=link.replace('//config.playwire.com/','https://cdn.video.playwire.com/').replace('zeus.json','video-sd.mp4').replace("v2/","")
                        playlink(link)
                        return
                if 'rtmp' in data:
                        #rtmp://vod1.ashams.com/vod/<playpath>mp4:monwat/Mr-Bean/TheLibrary.mp4 <swfUrl>http://www.ashams.com/admin-aps/inc/player/player.swf <pageUrl>http://www.ashams.com/player/25740/%D9%85%D8%B3%D8%AA%D8%B1_%D8%A8%D9%86_%D9%81%D9%8A_%D8%A7%D9%84%D9%85%D9%83%D8%AA%D8%A8%D8%A9_
                        regx=''''file':'(.*?)','''
                        link= re.findall(regx,data, re.M|re.I)[0]
                        rtmp='rtmp://vod1.ashams.com/vod/' +' playpath=mp4:'+link+' swfUrl=http://www.ashams.com/admin-aps/inc/player/player.swf pageUrl='+urlmain
                        playlink(rtmp)
                        return

		try:
                        link=host2[0]
                except:
                        regx='''file: "(.*?)",'''
                        videoid= re.findall(regx,data, re.M|re.I)[0].split("?v=")[1]
                        if "&" in videoid:
                                videoid=videoid.split("&")[0]
                        stream_link = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                        playlink(stream_link)
                        return

		parts=link.split("/")
		hosting_id=parts[3]
		id=parts[6]
		
		#//config.playwire.com/15880/videos/v2/4343765/zeus.json

		stream_link='https://cdn.phoenix.intergi.com/'+hosting_id+'/videos/'+id+'/video-sd.mp4?hosting_id='+hosting_id
		
                playlink(stream_link)
            
def gethosts2(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                print data
                if data is None:
                    return
                regx="'http://moshahda.net/cgi-bin/index_dl.cgi(.*?)'"
		host= re.findall(regx,data, re.M|re.I)
		if host:
                        for href in host:
                          href= 'http://moshahda.net/cgi-bin/index_dl.cgi'+href 
			  playlink(href)

	    
def resolve_host1(url):#last good-used with local resolver
 
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(stream_link)
	     
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    playlink(stream_link)
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(url):
            print "m2",url
            xbmc.Player().play(url)
            sys.exit(0)

            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok



params=get_params()
url=None
name=None
mode=None
page=0

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==2:
        print ""+url
        resolve_host1(url)
elif mode==21:
        print ""+url
        gethosts2(url)
        
elif mode==22:
        print ""+url
        playlink(url)          
        
elif mode==100:
        print ""+url
        getvideos_cinema(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
	
	search(url)
elif mode==200:
	print "mfaraj"+url
	getseries(name,url,page)
	#getvideopage(url,page)
elif mode==2001:
	print "mfaraj"+url
	getseries2(name,url,page)
	#getvideopage(url,page)	
elif mode==2002:
	print "mfaraj"+url
	getepisodes2(name,url,page)
	#getvideopage(url,page)	
elif mode==201:
	getgenre('shows')
elif mode==202:
	print ""+url
	getA_Z('shows')
	
elif mode==203:
	getvideos_seasons(name,url,page)

xbmcplugin.endOfDirectory(int(sys.argv[1]))                               
