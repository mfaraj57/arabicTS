# -*- coding: utf8 -*-


try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,os
from xbmctools import addDir,readnet,supported,get_params,playlink,getnet,getDomain,xbmc,requestsurl,xbmcplugin,resolvehost,getsearchtext,resolvehost,finddata,trace_error,finditem
################''
baseurl='http://tv.shof.co.il'
def read_url3(url):#filmon
              data=None
              m=True
              if True:
                  import cfscrape

                  scraper = cfscrape.create_scraper()  # returns a CloudflareScraper instance
                  # Or: scraper = cfscrape.CloudflareScraper()  # CloudflareScraper inherits from requests.Session
                  data=scraper.get(url).content  # => "<!DOCTYPE html><html><head>..."
                                          
                         
              else:
                        addDir("Download error,try again","","",'')
                        return

              return data
##########################################parsing tools


def showmenu():
        ##main
	#addDir('search',"http://tv.shof.co.il/?mod=search&searchq=",103,'img/search.png','',1)
        #addDir('الافلام الاجنبيه','https://www.almstba.tv/video/category.php?cat=english-movies',100,'img/movies.png','',1)
        
	addDir('الافلام العربيه','http://www.farfesh.com/Video.asp?ZoneID=1',102,'img/amovies.png','',1)
        addDir('المسلسلات العربيه','http://www.farfesh.com/mosalsalat_arabic_all.asp',101,'img/aseries.png','',1)
        addDir('مسلسلات رمضان 2017','http://www.farfesh.com/AllMosalsalatRamadan.asp',101,'img/rseries.png','',1)
        addDir('مسلسلات عالميه','http://www.farfesh.com/mosalsalat_world_all.asp',101,'img/hseries.png','',1)
        addDir('مسلسلات تركيه','http://www.farfesh.com/mosalsalat_turkey_all.asp',101,'img/tseries.png','',1)
        #addDir('ترفيه','http://www.farfesh.com/Fun_And_Games.asp',200,'img/eshows.png','',1)
        addDir('برامج تلفزيونيه','http://www.farfesh.com/BramejPage.asp',101,'img/tvshows.png','',1)
        addDir('مقاطع مضحكه','http://www.farfesh.com/Video.asp?ZoneID=3',100,'img/1.jpg','',1)
        addDir('مواهب','http://www.farfesh.com/Video.asp?ZoneID=7',100,'img/2.jpg','',1)
        addDir('سحر','http://www.farfesh.com/Video.asp?ZoneID=8',100,'img/3.jpg','',1)
        addDir('ريبوتاجات خاصه','http://www.farfesh.com/Video.asp?ZoneID=4',100,'img/4.jpg','',1)
        addDir('افلام كرتون','http://www.farfesh.com/Video.asp?ZoneID=107',100,'img/5.jpg','',1)
        addDir('توم وجيري','http://www.farfesh.com/Video.asp?ZoneID=9',100,'img/6.jpg','',1)
        addDir('صلاح الدين','http://www.farfesh.com/Video.asp?ZoneID=112',100,'img/7.jpg','',1)
        addDir('النمر الوردي','http://www.farfesh.com/Video.asp?ZoneID=10',100,'img/8.jpg','',1)
        addDir('شيرلوك هلمز','http://www.farfesh.com/Video.asp?ZoneID=11',100,'img/9.jpg','',1)
        addDir('سبايدرمان','http://www.farfesh.com/Video.asp?ZoneID=150',100,'img/10.jpg','',1)
        return
        

        

def years(url):###nt active-movies 110,series 210
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             #addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
             return       
def genres(urlmain):##not active movies 111,series 210

                data=getnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name,url):#not active mvoies 112,series 212
		abc = ['\xd8\xa3', '\xd8\xa8', '\xd8\xaa', '\xd8\xab', '\xd8\xac', '\xd8\xad', '\xd8\xae', '\xd8\xaf', '\xd8\xb0', '\xd8\xb1', '\xd8\xb2', '\xd8\xb3', '\xd8\xb4', '\xd8\xb5', '\xd8\xb6', '\xd8\xb7', '\xd8\xb8', '\xd8\xb9', '\xd8\xba', '\xd9\x81', '\xd9\x82', '\xd9\x83', '\xd9\x84', '\xd9\x85', '\xd9\x86', '\xd9\x87\xd9\x80', '\xd9\x88', '\xd9\x8a']
                i=0
		for letter in abc:
                          i=i+1
                          if name=='movies':
                                  mode=100
                                  href=url+'&Chosen_ID='+str(i) 
                          else:
                                  href=url+"?Chosen_ID="+str(i) 
                                  mode=200
                              
			  addDir(letter,href,mode,'','',1)
			
###################################movies
			  
def search(url):
        
        
         
        searchkey = getsearchtext()      
         
        url= url+searchkey      
        print "url",url
        url=url.strip()
        search_results("Search",url,0)


def search_results(namemain,page_url,page):##may pastte code of getmovies here


                if page>1:
                    
                        #http://tv.shof.co.il/?mod=videocat&ID=14&page=2
                        page_url=url+"&page="+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=getnet(page_url)           
                
                
                
                if data is None:
                    return
               
                
               
                blocks=data.split('class="visual shadow"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''href="(.*?)"'''                    
                    try:
                            href='http://tv.shof.co.il'+re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue

                    regx='''<div class="txt">\s\s(.*?)\s\s</div>'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    #name,image
                    regx='''src="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    try:image=image.encode("utf-8",'ignore')
                    except:image=str(image)
                    title=title.strip()
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                
                if len(blocks)>20:
                    
                   addDir("next page",url,104,'img/next.png','',str(page+1))

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))



               
                   
                
               
                   
                
        
def getmovies(name,url,page):##movies
               
               
                if page>1:
                    
                        #http://tv.shof.co.il/?mod=videocat&ID=14&page=2
                        page_url=url+"&page="+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=getnet(page_url)           
                try:data=data.split('Class="text1a"')[2]
                except:pass
                
                
                if data is None:
                    return
               
                
               
                blocks=data.split('<TD width="190" valign="top">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''HREF="(.*?)"'''
                    try:
                       href=re.findall(regx,block, re.M|re.I)[0]
                    except:

                            trace_error()
                            continue                            
                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    
                    regx='''SRC="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    try:image=image.encode("utf-8",'ignore')
                    except:image=str(image)
                    title=title.strip()
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))












###############################################series


def getseries(name,url,page):##series
               
                if page>1:
                    
                        #http://tv.shof.co.il/?mod=videocat&ID=14&page=2
                        page_url=url+"&page="+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=getnet(page_url)           
                #try:data=data.split('مسلسلات فرفش تبدا بحرف')[1]
                #except:pass
                
                
                if data is None:
                    return
               
                
               
                blocks=data.split('text-align:center;cursor: pointer;"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''HREF="(.*?)"'''
                    try:
                       href='http://www.farfesh.com/'+re.findall(regx,block, re.M|re.I)[0]
                    except:

                            trace_error()
                            continue                            
                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    
                    regx='''SRC="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    try:image=image.encode("utf-8",'ignore')
                    except:image=str(image)
                    title=title.strip()
                    try:
                      addDir(title,href,202,image,'','',maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))





                    
def getseasons(name,url,page):##series

                 
                data=getnet(url)
                try:data=data.split('<div class="title6">')[1]
                except:pass
              
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                
                
                for href,title in seasons:
                    
                    
                    addDir(title,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,url,page):##series

               
                if page>1:
                    
                        #http://tv.shof.co.il/?mod=videocat&ID=14&page=2
                        page_url=url+"&page="+str(page)
                  
                else:
                
                       page_url=url
                print "url_page",page_url
                data=getnet(page_url)           
                try:data=data.split('Class="text1a"')[2]
                except:pass
                
                
                if data is None:
                    return
               
                
               
                blocks=data.split('<TD width="190" valign="top">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #link
                    regx='''HREF="(.*?)"'''
                    try:
                       href=re.findall(regx,block, re.M|re.I)[0]
                    except:

                            trace_error()
                            continue                            
                    regx='''title="(.*?)"'''                    
                    try:
                            title=re.findall(regx,block, re.M|re.I)[0]
                    except:
                            trace_error()
                            continue
                    
                    regx='''SRC="(.*?)"'''                    
                    try:
                            image=re.findall(regx,block, re.M|re.I)[0]
                            ###if image and title in regx
                            #match=re.findall(regx,block, re.M|re.I)
                            #image=match[0][0]
                            #title=match[0][1]

                    except:
                            trace_error()
                            pass                            
                    

                    
                    
                             
                               
                    

                    
                    try:href=href.encode("utf-8",'ignore')
                    except:href=str(href)
                    try:image=image.encode("utf-8",'ignore')
                    except:image=str(image)
                    title=title.strip()
                    try:
                      addDir(title,href,1,image,'',1,maintitle=True)
                    except:
                            trace_error()
                            continue
               
                   
                

                
                if len(blocks)==0:
                    addDir("Error:No items found",url,100,'','',str(page+1))





#######################################host resolving                                                    
                    

def getservers(name,url):
                data=getnet(url)
                regx='''<iframe class="video" src="(.*?)".*?></iframe>'''
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                #regx='''<iframe width="750" height="440" scrolling="false" frameborder="0" src="https://www.wintv.live/player/farfeshplusPDn/?video=viewm/5/183/5183.mp4&poster=https://images.farfeshplus.com/videos/ba7ebak.jpg&pd=1&ads=1&schedule=all" allowfullscreen></iframe>'''
                #regx='''<iframe.*?data-iframe-id="(.*?)" data-src="(.*?)".*?></iframe>'''
                href=re.findall(regx,data, re.M|re.I)[0]
                print "href1",href
                if "youtube" in href:
                    videoid=os.path.split(href)[1]
                    stream_link = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                    print 'stream_link',stream_link
                    addDir(name,stream_link,9,'','',1,link=True)
                    #playlink(stream_link)
                    return
                data=requestsurl(href)
                regx='''"file": "(.*?)",'''
                print "data",data
                regx='''mp4: ['(.*?)']'''
                #regx2='''<iframe width="750" height="440" scrolling="false" frameborder="0" src="http://dotosi.com/player/farfeshhlsnew/?video=vod5n/30-yom-29.mp4&poster=http://www.farfesh.com/ramadanimages/1290.jpg&ads=1&schedule=all" allowfullscreen></iframe>

                
                href2=finditem(data,"https://myvideo","'")
               
                href2="https://myvideo"+href2      
                print "href2",href2
               
                
                playlink(href2)
                return
                for href in match:

                        
                   
                    

                    
                    
                    title=getDomain(href)
                   
                    if supported(name):
                            try:addDir(title,href,2,"img/server.png",'',1)
                            except:pass

                 
def resolve_host(url):
        resolve_host(url)    

  
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu and tools
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##hosts        
elif mode==1:
        print ""+url
        
        getservers(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
        
###movies     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)

elif mode==101:
	print ""+url
	
	getA_Z('series',url)	

elif mode==102:
	print ""+url
	
	getA_Z('movies',url)
	
elif mode==103:
	print ""+url
        search(url)
elif mode==104:

	search_results(name,url,page)        
##extra years 104,genres 105,a-z 106        
###series        


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)

elif mode==203:
	print ""+url
        search_tvshows(url)           

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
