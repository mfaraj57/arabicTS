# 2014.10.25 00:28:23 Jordan Daylight Time
#Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.farfesh/default.py
try:import sys, syspath
except:pass
import os, sys
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
from string import find
from urllib2 import urlopen, Request
import re
import base64
__settings__ = xbmcaddon.Addon(id='plugin.video.farfesh')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://mobile.farfesh.com/'

def read_url2(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Host', 'www.movie25.com')
    req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
    response = urllib2.urlopen(req)
    link = response.read()
    return link


def read_url(url):
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        response = urllib2.urlopen(req)
        data = response.read()
        response.close()
        return data
    except urllib2.URLError as e:
        print 'URL: ' + url
        if hasattr(e, 'code'):
            print 'We failed with error code - %s.' % e.code
        elif hasattr(e, 'reason'):
            print 'We failed to reach a server.'
            print 'Reason: %s' % e.reason


sortorder = [('release', 'Release date'),
 ('views', 'Popular'),
 ('ratings', 'Ratings'),
 ('featured', 'Featured'),
 ('alphabet', 'Alphabet'),
 ('favorites', 'Favorites')]
sortdefault = 'alphabet'

def decodeHtml(text):
    text = text.replace('&auml;', 'ae').replace('&Auml;', 'Ae').replace('&ouml;', 'oe').replace('&ouml;', 'Oe').replace('&uuml;', 'ue')
    text = text.replace('&Uuml;', 'Ue').replace('&szlig;', 'ss').replace('&amp;', '&').replace('&quot;', '"').replace('&gt;', "'")
    text = text.replace('&#228;', 'ae').replace('&#246;', 'oe').replace('&#252;', 'ue').replace('&#223;', 'ss').replace('&#8230;', '...')
    text = text.replace('&#8222;', ',').replace('&#8220;', "'").replace('&#8216;', "'").replace('&#8217;', "'").replace('&#8211;', '-')
    text = text.replace('&#8230;', '...').replace('&#8217;', "'").replace('&#128513;', ':-)').replace('&#8221;', '"')
    text = text.replace('&#038;', '&').replace('&#039;', "'")
    text = text.replace('\\u00c4', 'Ae').replace('\\u00e4;', 'ae').replace('\\u00d6', 'Oe').replace('\\u00f6', 'oe')
    text = text.replace('\\u00dc', 'Ue').replace('\\u00fc', 'ue').replace('\\u00df', 'ss')
    text = text.replace('&#196;', 'Ae').replace('&#228;', 'ae').replace('&#214;', 'Oe').replace('&#246;', 'oe').replace('&#220;', 'Ue').replace('&#252;', 'ue')
    text = text.replace('<br />\n', '')
    return text


def cats():
    addDir('Aflam', 'http://mobile.farfesh.com/Movies.asp', 1, '')
    addDir('Series', 'http://mobile.farfesh.com/Mosalsalat.asp', 112, '')
    addDir('Music', 'http://mobile.farfesh.com/ArabicMP3.asp', 111, '')
    addDir('TV programs', 'http://mobile.farfesh.com/TV.series.asp', 1111, '')
    addDir('Mawahb', 'http://mobile.farfesh.com/TVSeries.asp', 1112, '')


def getlanggenreliste():
    genrelist = []
    genrelist.append(('England', 'en'))
    genrelist.append(('France', 'fr'))
    genrelist.append(('German', 'de'))
    genrelist.append(('Spain', 'es'))
    genrelist.append(('Italy', 'it'))
    genrelist.append(('Japan', 'jp'))
    genrelist.append(('Turkey', 'tr'))
    genrelist.append(('Russia', 'ru'))
    for item in genreliste:
        title = item[0]
        country = item[1]
        url = baseurl + 'index.php?lang=' + country
        addDir(title, url, 3, '', 1)


def moviemenu():
    data = '<option value="Mosalsalat.asp?Id=1" Selected>\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xa7</option>\n                        <option value="Mosalsalat.asp?Id=2" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xa8</option>\n                        <option value="Mosalsalat.asp?Id=3" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xaa</option>\n                        <option value="Mosalsalat.asp?Id=4" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xab</option>\n                        <option value="Mosalsalat.asp?Id=5" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xac</option>\n                        <option value="Mosalsalat.asp?Id=6" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xad</option>\n                        <option value="Mosalsalat.asp?Id=7" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xae</option>\n                        <option value="Mosalsalat.asp?Id=8" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xaf</option>\n                        <option value="Mosalsalat.asp?Id=9" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb0</option>\n                        <option value="Mosalsalat.asp?Id=10" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb1</option>\n                        <option value="Mosalsalat.asp?Id=11" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb2</option>\n                        <option value="Mosalsalat.asp?Id=12" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb3</option>\n                        <option value="Mosalsalat.asp?Id=13" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb4</option>\n                        <option value="Mosalsalat.asp?Id=14" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb5</option>\n                        <option value="Mosalsalat.asp?Id=15" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb6</option>\n                        <option value="Mosalsalat.asp?Id=16" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb7</option>\n                        <option value="Mosalsalat.asp?Id=17" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb8</option>\n                        <option value="Mosalsalat.asp?Id=18" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb9</option>\n                        <option value="Mosalsalat.asp?Id=19" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xba</option>\n                        <option value="Mosalsalat.asp?Id=20" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x81</option>\n                        <option value="Mosalsalat.asp?Id=21" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x82</option>\n                        <option value="Mosalsalat.asp?Id=22" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x83</option>\n                        <option value="Mosalsalat.asp?Id=23" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x84</option>\n                        <option value="Mosalsalat.asp?Id=24" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x85</option>\n                        <option value="Mosalsalat.asp?Id=25" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x86</option>\n                        <option value="Mosalsalat.asp?Id=26" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x87</option>\n                        <option value="Mosalsalat.asp?Id=27" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x88</option>\n                        <option value="Mosalsalat.asp?Id=28" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x8a</option>\n                                </select>\n                        </div>'
    regx = '<option value="(.*?)".*?>\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81(.*?)</option>'
    matches = re.findall(regx, data, re.S)
    for item in matches:
        title = item[1].replace('-', '').strip()
        url = baseurl + item[0]
        pic = ''
        url = url.replace('Mosalsalat.asp?Id=', 'Movies.asp?Id=')
        print 'titles', title
        addDir(title, url, 3, pic)


def seriesmenu():
    data = '<option value="Mosalsalat.asp?Id=1" Selected>\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xa7</option>\n                        <option value="Mosalsalat.asp?Id=2" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xa8</option>\n                        <option value="Mosalsalat.asp?Id=3" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xaa</option>\n                        <option value="Mosalsalat.asp?Id=4" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xab</option>\n                        <option value="Mosalsalat.asp?Id=5" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xac</option>\n                        <option value="Mosalsalat.asp?Id=6" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xad</option>\n                        <option value="Mosalsalat.asp?Id=7" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xae</option>\n                        <option value="Mosalsalat.asp?Id=8" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xaf</option>\n                        <option value="Mosalsalat.asp?Id=9" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb0</option>\n                        <option value="Mosalsalat.asp?Id=10" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb1</option>\n                        <option value="Mosalsalat.asp?Id=11" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb2</option>\n                        <option value="Mosalsalat.asp?Id=12" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb3</option>\n                        <option value="Mosalsalat.asp?Id=13" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb4</option>\n                        <option value="Mosalsalat.asp?Id=14" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb5</option>\n                        <option value="Mosalsalat.asp?Id=15" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb6</option>\n                        <option value="Mosalsalat.asp?Id=16" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb7</option>\n                        <option value="Mosalsalat.asp?Id=17" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb8</option>\n                        <option value="Mosalsalat.asp?Id=18" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb9</option>\n                        <option value="Mosalsalat.asp?Id=19" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xba</option>\n                        <option value="Mosalsalat.asp?Id=20" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x81</option>\n                        <option value="Mosalsalat.asp?Id=21" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x82</option>\n                        <option value="Mosalsalat.asp?Id=22" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x83</option>\n                        <option value="Mosalsalat.asp?Id=23" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x84</option>\n                        <option value="Mosalsalat.asp?Id=24" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x85</option>\n                        <option value="Mosalsalat.asp?Id=25" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x86</option>\n                        <option value="Mosalsalat.asp?Id=26" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x87</option>\n                        <option value="Mosalsalat.asp?Id=27" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x88</option>\n                        <option value="Mosalsalat.asp?Id=28" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x8a</option>\n                                </select>\n                        </div>'
    regx = '<option value="(.*?)".*?>\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81(.*?)</option>'
    matches = re.findall(regx, data, re.S)
    for item in matches:
        title = item[1].replace('-', '').strip()
        url = baseurl + item[0]
        pic = ''
        try:
            mode = item[2]
        except:
            mode = 3

        print 'titles', title
        addDir(title, url, 14, pic)


def musicmenu():
    data = '<option value="Mosalsalat.asp?Id=1" Selected>\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xa7</option>\n                        <option value="Mosalsalat.asp?Id=2" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xa8</option>\n                        <option value="Mosalsalat.asp?Id=3" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xaa</option>\n                        <option value="Mosalsalat.asp?Id=4" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xab</option>\n                        <option value="Mosalsalat.asp?Id=5" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xac</option>\n                        <option value="Mosalsalat.asp?Id=6" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xad</option>\n                        <option value="Mosalsalat.asp?Id=7" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xae</option>\n                        <option value="Mosalsalat.asp?Id=8" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xaf</option>\n                        <option value="Mosalsalat.asp?Id=9" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb0</option>\n                        <option value="Mosalsalat.asp?Id=10" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb1</option>\n                        <option value="Mosalsalat.asp?Id=11" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb2</option>\n                        <option value="Mosalsalat.asp?Id=12" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb3</option>\n                        <option value="Mosalsalat.asp?Id=13" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb4</option>\n                        <option value="Mosalsalat.asp?Id=14" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb5</option>\n                        <option value="Mosalsalat.asp?Id=15" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb6</option>\n                        <option value="Mosalsalat.asp?Id=16" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb7</option>\n                        <option value="Mosalsalat.asp?Id=17" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb8</option>\n                        <option value="Mosalsalat.asp?Id=18" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xb9</option>\n                        <option value="Mosalsalat.asp?Id=19" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd8\xba</option>\n                        <option value="Mosalsalat.asp?Id=20" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x81</option>\n                        <option value="Mosalsalat.asp?Id=21" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x82</option>\n                        <option value="Mosalsalat.asp?Id=22" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x83</option>\n                        <option value="Mosalsalat.asp?Id=23" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x84</option>\n                        <option value="Mosalsalat.asp?Id=24" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x85</option>\n                        <option value="Mosalsalat.asp?Id=25" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x86</option>\n                        <option value="Mosalsalat.asp?Id=26" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x87</option>\n                        <option value="Mosalsalat.asp?Id=27" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x88</option>\n                        <option value="Mosalsalat.asp?Id=28" >\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81 \xd9\x8a</option>\n                                </select>\n                        </div>'
    regx = '<option value="(.*?)".*?>\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa \xd8\xaa\xd8\xa8\xd8\xaf\xd8\xa3 \xd8\xa8\xd8\xad\xd8\xb1\xd9\x81(.*?)</option>'
    matches = re.findall(regx, data, re.S)
    for item in matches:
        title = item[1].replace('-', '').strip()
        url = baseurl + item[0]
        pic = ''
        url = url.replace('Mosalsalat.asp?Id=', 'ArabicMP3.asp?Id=')
        print 'titles', title
        addDir(title, url, 151, pic)


def movies_a_z():
    abc = ['#',
     'A',
     'B',
     'C',
     'D',
     'E',
     'F',
     'G',
     'H',
     'I',
     'J',
     'K',
     'L',
     'M',
     'N',
     'O',
     'P',
     'Q',
     'R',
     'S',
     'T',
     'U',
     'V',
     'W',
     'X',
     'Y',
     'Z',
     '#']
    for letter in abc:
        url = baseurl + 'movies-all-%s-' % letter
        url = baseurl + 'movies-all-' + letter
        url = baseurl + letter + '/'
        addDir(letter, url, 3, '', 1)


def series_a_z():
    matches = [('Mosalsalat.asp?Id=1', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xc7'),
     ('Mosalsalat.asp?Id=2', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xc8'),
     ('Mosalsalat.asp?Id=3', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xca'),
     ('Mosalsalat.asp?Id=4', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xcb'),
     ('Mosalsalat.asp?Id=5', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xcc'),
     ('Mosalsalat.asp?Id=6', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xcd'),
     ('Mosalsalat.asp?Id=7', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xce'),
     ('Mosalsalat.asp?Id=8', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xcf'),
     ('Mosalsalat.asp?Id=9', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd0'),
     ('Mosalsalat.asp?Id=10', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd1'),
     ('Mosalsalat.asp?Id=11', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd2'),
     ('Mosalsalat.asp?Id=12', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd3'),
     ('Mosalsalat.asp?Id=13', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd4'),
     ('Mosalsalat.asp?Id=14', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd5'),
     ('Mosalsalat.asp?Id=15', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd6'),
     ('Mosalsalat.asp?Id=16', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd8'),
     ('Mosalsalat.asp?Id=17', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xd9'),
     ('Mosalsalat.asp?Id=18', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xda'),
     ('Mosalsalat.asp?Id=19', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xdb'),
     ('Mosalsalat.asp?Id=20', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xdd'),
     ('Mosalsalat.asp?Id=21', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xde'),
     ('Mosalsalat.asp?Id=22', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xdf'),
     ('Mosalsalat.asp?Id=23', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xe1'),
     ('Mosalsalat.asp?Id=24', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xe3'),
     ('Mosalsalat.asp?Id=25', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xe4'),
     ('Mosalsalat.asp?Id=26', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xe5'),
     ('Mosalsalat.asp?Id=27', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xe6'),
     ('Mosalsalat.asp?Id=28', '\xe3\xd3\xe1\xd3\xe1\xc7\xca \xca\xc8\xcf\xc3 \xc8\xcd\xd1\xdd \xed')]
    for item in matches:
        title = item[1]
        url = baseurl + item[0]
        pic = ''
        try:
            mode = item[2]
        except:
            mode = 3

        addDir(title, url, 14, pic)


def getlanggenreliste_series():
    key = getkey()
    genreliste = []
    genreliste = [('UK', 'UK'),
     ('France', 'France'),
     ('Germany', 'Germany'),
     ('USA', 'USA'),
     ('Egypt', 'Egypt'),
     ('Netherlands', 'Netherlands'),
     ('Italy', 'Italy'),
     ('Poland', 'Poland'),
     ('Spain', 'Spain'),
     ('Greece', 'Greece'),
     ('Sweden', 'Sweden'),
     ('Turkey', 'Turkey')]
    for item in genreliste:
        title = item[0]
        country = item[1]
        url = baseurl + 'index.php?search_section=2&search_keywords=&genre=&director=&actor_name=&tag=&country=' + country + '&search_rating=0&year=0&month=0&decade=0&host=&advanced=1&key=' + str(key)
        addDir(title, url, 14, '', 1)


def getgenre_series(mainurl):
    if mainurl == 'release' or mainurl == 'views' or mainurl == 'ratings' or mainurl == 'featured':
        url = baseurl + '?tv=&sort=' + mainurl
    else:
        url = baseurl + '?tv=&genre=' + mainurl + '&sort=' + sortdefault
    getseries(mainurl, url, 1)


def getgenrelisteseries():
    addDir('All', baseurl + 'Mosalsalat.asp?Id=1', 14, '')
    return
    genreliste = []
    data = read_url('http://mobile.farfesh.com/Mosalsalat.asp?Id=1')
    regx = '<option value="(.*?)" Selected>(.*?)</option>'
    matches = re.findall(regx, data, re.S)
    for href, title in matches:
        title = title.encode('utf-8')
        addDir(title, href, 14, '')


def getgenre(name, mainurl):
    if mainurl == 'release' or mainurl == 'views' or mainurl == 'ratings' or mainurl == 'featured':
        url = baseurl + '?sort=' + mainurl
    else:
        url = baseurl + '?genre=' + mainurl + '&sort=' + sortdefault
    getmovies(mainurl, url, 1)


def getmovies_language(name1, urlmain, page):
    if page > 1:
        url_page = urlmain + '-' + str(page) + '.html'
    else:
        url_page = urlmain + '.html'
    print 'url_page', url_page
    data = read_url(url_page)
    print data
    regx = '<TR id="coverPreview(.*?)">.*?<a href="(.*?)">(.*?)     '
    matches = re.findall(regx, data, re.S)
    if matches:
        for image, teil_url, title in matches:
            image = image.replace('coverPreview', '')
            url = '%s%s' % (baseurl, teil_url)
            print 'title', title
            title = title.strip()
            print title
            addDir(decodeHtml(title), url, 20, image)

    else:
        print 'No movies'
        return
    addDir('next page>', urlmain, 3, '', str(page + 1))


def getmovies(name1, urlmain, page):
    print 'mahmoud1', urlmain
    print 'page', page
    if page > 1:
        url_page = urlmain + '&page=' + str(page)
    else:
        url_page = urlmain
    url_page = urlmain
    data = read_url(url_page)
    oldregx = '<div class="index_item index_item_ie"><a href="(.*?)" title="Watch.(.*?)"><img src="(.*?)"'
    regx = '<option value="(.*?)">(.*?)</option>'
    regx = '<option value="(.*?)">(.*?)</option>'
    regx = '<img src="http://www.farfesh.com/images/button_white_play.png" style=".*?"></a></div></div><div style=".*?"><a href="(.*?)" class="TitleLinkLrg">(.*?)</a></div></div>'
    series = re.findall(regx, data, re.S)
    i = 0
    if series:
        for href, title in series:
            i = i + 1
            print href
            print title
            title = title.strip()
            if 'empty' not in title:
                title = title.replace('br', '')
            else:
                continue
            if href.startswith('http'):
                print name1, title
                if title.startswith(name1):
                    addDir(title, href, 201, '')


def getmovies_updates(name1, urlmain, page):
    print 'mahmoud1', urlmain
    print 'page', page
    url_page = 'http://www.movie4k.to/movies-updates.html'
    data = read_url(url_page)
    regx = '<TR id="coverPreview(.*?)">.*?<a href="(.*?)">(.*?)     '
    matches = re.findall(regx, data, re.S)
    if matches:
        for image, teil_url, title in matches:
            image = image.replace('coverPreview', '')
            url = '%s%s' % (baseurl, teil_url)
            print 'title', title
            title = title.strip()
            print title
            addDir(decodeHtml(title), url, 20, image)

    else:
        print 'No movies'
        return
    addDir('next page>', urlmain, 3, '', str(page + 1))


def getmovies_search(name1, urlmain, page):
    data = read_url(urlmain)
    regx = '<div class="movie_pic"><a href="(.*?)" target="_blank">'
    movies = re.findall(regx, data, re.S)
    if movies:
        for url in movies:
            print url
            title = url.replace('movies/', '').replace('.html', '')
            title = title[1:]
            image = ''
            url = url[1:]
            url = '%s%s' % (baseurl, url)
            addDir(decodeHtml(title), url, 20, image)

        addDir('next page>', urlmain, 3, '', str(page + 1))


def search(mainurl):
    mainurl = '1'
    search_entered = ''
    debug = True
    if debug:
        keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText().replace(' ', '+')
            print 'mfarajx3', search_entered
    else:
        print 'search error'
    if 'searchyear' in mainurl:
        url = baseurl + 'search.php?year=' + search_entered
    else:
        url = baseurl + 'search.php?key=' + search_entered
    print 'mfarajx4_url', url
    getmovies_search('Search', url, 1)


def getseries(name1, urlmain, page):
    print 'mahmoud1', urlmain
    print 'page', page
    if page > 1:
        url_page = urlmain + '&page=' + str(page)
    else:
        url_page = urlmain
    url_page = urlmain
    data = read_url(url_page)
    oldregx = '<div class="index_item index_item_ie"><a href="(.*?)" title="Watch.(.*?)"><img src="(.*?)"'
    regx = '<option value="(.*?)">(.*?)</option>'
    regx = '<option value="(.*?)">(.*?)</option>'
    series = re.findall(regx, data, re.S)
    i = 0
    if series:
        for href, title in series:
            i = i + 1
            print href
            print title
            title = title.strip()
            if 'empty' not in title:
                title = title.replace('br', '')
            else:
                continue
            if href.startswith('http'):
                print name1, title
                if title.startswith(name1):
                    addDir(title, href, 152, '')


def getartists(name1, urlmain, page):
    print 'mahmoud1', urlmain
    print 'page', page
    if page > 1:
        url_page = urlmain + '&page=' + str(page)
    else:
        url_page = urlmain
    url_page = urlmain
    data = read_url(url_page)
    oldregx = '<div class="index_item index_item_ie"><a href="(.*?)" title="Watch.(.*?)"><img src="(.*?)"'
    regx = '<option value="(.*?)">(.*?)</option>'
    regx = '<option value="(.*?)">(.*?)</option>'
    series = re.findall(regx, data, re.S)
    i = 0
    if series:
        for href, title in series:
            i = i + 1
            print href
            print title
            title = title.strip()
            if 'empty' not in title:
                title = title.replace('br', '')
            else:
                continue
            if href.startswith('http'):
                print name1, title
                if title.startswith(name1):
                    addDir(title, href, 1522, '')


def getsongs(name1, urlmain, page):
    print 'mahmoud1', urlmain
    print 'page', page
    if page > 1:
        url_page = urlmain + '&page=' + str(page)
    else:
        url_page = urlmain
    url_page = urlmain
    data = read_url(url_page)
    oldregx = '<div class="index_item index_item_ie"><a href="(.*?)" title="Watch.(.*?)"><img src="(.*?)"'
    regx = '<a href="(.*?)"><img src="(.*?)".*?>(.*?)<br/>'
    regx = '<a href="(.*?)"><img src=".*?" style=".*?" /></a></div><div style=".*?" class="txtBlackLarge">(.*?)<br/>'
    regx=  '<a href="(.*?)"><img src=.*?class="txtBlackLarge">(.*?)</div></h2></div>'''
    series = re.findall(regx, data, re.M | re.I)
    i = 0
    print 'series', series
    if series:
        for href, title in series:
            i = i + 1
            title=title.replace("<br","")
            addDir(title, href, 22, '')


def getseasons(name, mainurl, page):
    data = read_url(mainurl)
    staffeln = re.findall('<TD id="tdmovies" width="538"><a href="(.*?)".*?Season:(.*?)<', data, re.S)
    if staffeln:
        for urlPart, season in staffeln:
            url = '%s%s' % (baseurl, urlPart)
            formatTitle = 'Season %s' % season
            addDir(decodeHtml(formatTitle), url, 152, '')


def getepisodes(name, mainurl, page):
    data = read_url(mainurl)
    regx='<div style="text-align: right; float: right; padding-right: 5px; padding-top: 30px;"><h2><a href="(.*?)" class="TitleLinkLrg">(.*?)</a></h2></div>'
    episodes = re.findall(regx, data, re.M | re.I)
    print 'episodes', episodes
    if episodes:
        for href, title in episodes:
            title=title.replace("<br","")
            try:
                href = href.split('"')[0]
            except:
                pass

            addDir(title, href, 201, '')


def getprograms(name1, urlmain, page):
    print 'mahmoud1', urlmain
    print 'page', page
    if page > 1:
        url_page = urlmain + '&page=' + str(page)
    else:
        url_page = urlmain
    url_page = urlmain
    data = read_url(url_page)
    regx = '<div style=".*?"><a href="(.*?)" class="TitleLinkLrg">(.*?)<br>(.*?)</a></div></div>'
    programs = re.findall(regx, data, re.S)
    for href, title, title2 in programs:
        if href.startswith('http:'):
            try:
                href = href.split('"')[0]
            except:
                pass

            addDir(title + ' ' + title2, href, 201, '')


def getmawahb(name1, urlmain, page):
    print 'mahmoud1', urlmain
    print 'page', page
    if page > 1:
        url_page = urlmain + '&page=' + str(page)
    else:
        url_page = urlmain
    url_page = urlmain
    data = read_url(url_page)
    regx = '<div style=".*?"><a href="(.*?)" class="TitleLinkLrg">(.*?)<br>(.*?)</a></div></div>'
    regx = '<div style=".*?"><a href="(.*?)" class="TitleLinkLrg">(.*?)</a>'
    programs = re.findall(regx, data, re.S)
    for href, title in programs:
        if href.startswith('TVSeriesVideos'):
            href = baseurl + href
            try:
                href = href.split('"')[0]
            except:
                pass

            if not title.startswith(' '):
                print 'title', title
                title = title.replace('<div', '')
                addDir(title.strip(), href, 152, '')


def get_servers(mainurl):
    data = read_url(mainurl)
    regxc = '<li class="link_name">(.*?)</li>\\s(.*?)<li class="playing_button"><span><a href="(.*?).html"'
    hoster = re.findall(regxc, data, re.S)
    if hoster:
        for hostername, extra, link in hoster:
            link = link[1:]
            url = baseurl + link + '.html'
            print hostername, url
            addDir(hostername.strip(), url, 24, '')
            continue
            if isSupportedHoster(hostername):
                addDir(hostername, url, 24, '')
            else:
                print 'Not supported host:' + hostername


def isSupportedHoster(linkOrHoster, regexFlags = re.S | re.I):
    if not linkOrHoster:
        return False
    print 'check hoster: %s' % linkOrHoster
    hosters = getSupportedHosters()
    for hosterInfo in hosters:
        if linkOrHoster.lower() == hosterInfo[0].lower() or re.match('.*?' + hosterInfo[0], linkOrHoster, regexFlags) or re.search(hosterInfo[1], linkOrHoster, regexFlags):
            print 'match: %s %s' % hosterInfo
            return hosterInfo

    print 'hoster not supported'
    return False


def getSupportedHosters():
    return (('firedrive', 'http://.*?firedrive.com/(file|embed)/'),
     ('streamcloud', 'http://streamcloud.eu/'),
     ('streamclou', 'http://streamcloud.eu/'),
     ('flashx.tv', 'http:/.*?flashx.tv'),
     ('flashx', 'http:/.*?flashx.tv'),
     ('xvidstage', 'http://xvidstage.com'),
     ('movreel', 'http://movreel.com/'),
     ('xvidstream', 'http://xvidstream.net/'),
     ('played.to', 'http://played.to'),
     ('novamov', 'novamov.com'),
     ('movshare', '.movshare.net'),
     ('vodlocker', 'vodlocker\\.com'),
     ('nowvideo', 'nowvideo'),
     ('mightyupload', 'mightyupload.com/embed'),
     ('youwatch', 'http://youwatch.org'),
     ('shared.sx', 'http://shared.sx'),
     ('rapidgator', 'rapidgator.net'),
     ('rg.to', 'rg.to'),
     ('netload', 'netload.in'),
     ('uploaded', 'uploaded.net'),
     ('ul.to', 'ul.to'),
     ('uploadable.ch', 'uploadable.ch'),
     ('filesmonster.com', 'filesmonster.com'),
     ('freakshare', 'freakshare.com'),
     ('terafile', 'terafile.co'),
     ('bitshare', 'http://.*?bitshare.com'),
     ('mrfile', 'http://mrfile\\.me/'),
     ('vk.com', 'vk.com'),
     ('sockshare', 'http://.*?sockshare.com/(file|embed)/'),
     ('putlocker', 'http://.*?putlocker.com/(file|embed)/'),
     ('vreer', 'http://vreer.com'),
     ('flashstream', 'flashstream.in'),
     ('ginbig', 'ginbig.com'),
     ('videoweed', 'videoweed.es'),
     ('divxstage', 'divxstage'),
     ('yesload', 'yesload.tv'),
     ('faststream', 'faststream'),
     ('primeshare', 'primeshare'),
     ('vidstream.us', 'http://vidstream.us'),
     ('vidstream', 'http://vidstream.in'),
     ('putme', 'putme.org'),
     ('divxmov', 'divxmov.net'),
     ('sharesix', 'sharesix.com/'),
     ('userporn', 'userporn.com'),
     ('ecostream', 'ecostream.tv'),
     ('limevideo', 'limevideo.net'),
     ('videomega', 'videomega.tv'),
     ('vidxden', 'vidxden\\.com'),
     ('vidx', 'vidx.to'),
     ('mixturecloud', 'mixturecloud.com'),
     ('allmyvideos', 'allmyvideos.net'),
     ('promptfile', 'promptfile.com'),
     ('mooshare', 'mooshare.biz'),
     ('mp4upload', 'mp4upload\\.com'),
     ('videonest', 'videonest\\.net'),
     ('videodrive', 'videodrive\\.tv'),
     ('veoh', 'voeh\\.com'),
     ('vidbull', 'vidbull\\.com'),
     ('vidplay', 'vidplay\\.net'),
     ('180upload', 'http://180upload\\.com/embed-'),
     ('divxpress', 'http://www\\.divxpress\\.com/embed-'),
     ('cloudzilla', 'cloudzilla\\.to'),
     ('cloudyvideos', 'cloudyvideos\\.com'),
     ('stream2k', 'stream2k.com'))


def get_servers_series(mainurl):
    data = read_url(mainurl)
    regx = '<a href="(.*?)".*?><.*?src=".*?" alt="(.*?)"'
    regx = '"url":"(.*?)"'
    
    regx='''<a href="(.*?)" class="TitleLinkLrg">
'''
    regx='<link rel="video_src" href="(.*?)"/>'
    regx='<div style="text-align: center;width: 100%; float: right; padding-top: 10px;"><a href="(.*?)" class="TitleLinkLrg">.*?</a></div>'
   
    hoster_media_id = re.findall(regx, data, re.S)[0]
    
    print "hoster_media_id",hoster_media_id
    #sys.exit(0)
    #http://vgrp1.viewstream.co.il/viewstream/34/98/950/98950.flv?vtraffid=98950&ctraffid=34
    data2 = read_url( hoster_media_id )
    regx = '"url":"(.*?)",'
    hoster2 = re.findall(regx, data2, re.S)[0]
    url = urllib.unquote_plus(hoster2)
    url = urllib.unquote_plus(hoster2).split('.flv')[0] + '.flv'
    print 'url', url
    playlink(url)
   


def get_hostlink(host, url):
    data = read_url(url)
    regx = 'onclick="location.href=\'http://(.*?)\'"  value="Click Here to Play" />'
    link = re.findall(regx, data, re.S)
    url = link[0]
    id = os.path.split(url)[1]
    from urlresolver import HostedMediaFile, resolve
    source = HostedMediaFile('', host, id)
    link = source.resolve()
    print 'mmm', link, id, url
    try:
        if 'unresolvable' in link:
            link = resolve(url)
    except:
        link = resolve(url)

    if link:
        playlink(link)


def resolve_host(url):
    import urlresolver
    stream_link = urlresolver.resolve(url)
    print 'stream_link', stream_link
    if stream_link is None:
        return
    else:
        listItem = xbmcgui.ListItem(path=str(stream_link))
        xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)
        return


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]

    print 'input,output', paramstring, param
    return param


def addLink(name, url, mode, iconimage):
    u = _pluginName + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name})
    liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=_thisPlugin, url=u, listitem=liz, isFolder=False)
    return ok


def addDir(name, url, mode, iconimage, page = 0):
    u = sys.argv[0] + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&page=' + str(page)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


def playlink(url):
    print 'm2', url
    xbmc.Player().play(url)
    sys.exit(0)
    listItem = xbmcgui.ListItem(path=str(url))
    xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)


def resolve_host(url):
    import urlresolver
    stream_link = urlresolver.resolve(url)
    print 'stream_link', stream_link
    if stream_link is None:
        return
    else:
        listItem = xbmcgui.ListItem(path=str(stream_link))
        xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)
        return


params = get_params()
url = None
name = None
mode = None
page = 0
try:
    url = urllib.unquote_plus(params['url'])
except:
    pass

try:
    name = urllib.unquote_plus(params['name'])
except:
    pass

try:
    mode = int(params['mode'])
except:
    pass

try:
    page = int(params['page'])
except:
    pass

print 'Mode: ' + str(mode)
print 'URL: ' + str(url)
print 'Name: ' + str(name)
print 'page: ' + str(page)
if mode == None or url == None or len(url) < 1:
    print ''
    cats()
elif mode == 1:
    print '' + url
    moviemenu()
elif mode == 112:
    print '' + url
    seriesmenu()
elif mode == 111:
    print '' + url
    musicmenu()
elif mode == 1111:
    getprograms(name, url, page)
elif mode == 1112:
    getmawahb(name, url, page)
elif mode == 2:
    print '' + url
    movies_a_z()
elif mode == 3:
    print '' + url
    getmovies(name, url, page)
elif mode == 31:
    print 'mfaraj' + url
    getmovies_updates(name, url, page)
elif mode == 4:
    getlanggenreliste()
elif mode == 6:
    search(url)
elif mode == 5:
    print 'mfaraj' + url
    getgenre(name, url)
elif mode == 10:
    print 'mfaraj' + url
    getgenrelisteseries()
elif mode == 11:
    print 'mfaraj' + url
    series_a_z()
elif mode == 12:
    getlanggenreliste_series(url)
elif mode == 13:
    getgenre_series(url)
elif mode == 14:
    getseries(name, url, page)
elif mode == 151:
    getartists(name, url, page)
elif mode == 1522:
    getsongs(name, url, page)
elif mode == 152:
    getepisodes(name, url, page)
elif mode == 16:
    search(url)
elif mode == 20:
    print '' + url
    get_servers(url)
elif mode == 201:
    print '' + url
    get_servers_series(url)
elif mode == 21:
    resolve_host(url)
elif mode == 22:
    playlink(url)
elif mode == 24:
    get_hostlink(name, url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))    
# okay decompyling D:\addons1\arabic\plugin.video.farfesh\default.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2014.10.25 00:28:25 Jordan Daylight Time
