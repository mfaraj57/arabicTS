
# -*- coding: utf-8 -*-
try:import sys
except:pass
import urllib,re
from xbmctools import Item,trace_error,readnet,finddata,getDomain,resolvehost,get_params,playlink
item=Item()
addDir=item.addDir
endDir=item.endDir
baseurl = 'http://movizland.online'

##########################################main menu
def showmenu():
        
        addDir('Search',baseurl+'/?s=',104,'img/0.png','',1,searchall=__file__)
        addDir('اخــر الاضــافات',baseurl+'/',10000,'img/12.png','',1)
        addDir('افلام اجنبية',baseurl+'/cat/foreign/',100,'img/1.png','',1)
        addDir('السنوات','url',800,'img/16.png','',1)
        addDir('أفلام مصنفة','url',30,'img/15.png','',1)		
        addDir('طلبات الاعضاء',baseurl+'/tags/?q=submition',136,'img/14.png','',1)
        addDir('بوكس اوفيس',baseurl+'/tags/?q=boxoffice',106,'img/17.png','',1)
        addDir('جودة عالية',baseurl+'/?type=quality&s=720p+HDTV',126,'img/18.png','',1)
        addDir('افلام عربية',baseurl+'/cat/arab/',100,'img/2.png','',1)	
        addDir('افلام هندية',baseurl+'/cat/india/',100,'img/3.png','',1)
        addDir('افلام تركية',baseurl+'/cat/turkey/',100,'img/8.png','',1)
        addDir('افلام اسيوية',baseurl+'/cat/asia/',100,'img/10.png','',1)
        
        addDir('افلام وثائقية',baseurl+'/cat/documentary/',100,'img/9.png','',1)
        addDir('افلام انيميشن',baseurl+'/cat/anime/',100,'img/4.png','',1)
        addDir('مسلسلات اجنبيه',baseurl+'/cat/foreign-series/',100,'img/6.png','',1)
        addDir('مسلسلات عربيه',baseurl+'/cat/arab-series/',100,'img/5.png','',1)
        addDir('WWE','url',28,'img/11.png',1)
      
        addDir('برامج تلفزيونية',baseurl+'/cat/tv-progs/',100,'img/13.png','',1)
        
def GENRES(url):
        addDir('••أفلام رعـــب••',baseurl+'/all/%D8%B1%D8%B9%D8%A8/',100,'img/1.png','',1)
        addDir('••الجريمة••',baseurl+'/all/%d8%ac%d8%b1%d9%8a%d9%85%d9%87/',100,'img/2.png','',1)
        addDir('••أفلام رومــــانسية••',baseurl+'/all/%d8%b1%d9%88%d9%85%d8%a7%d9%86%d8%b3%d9%8a/',100,'img/3.png','',1)
        addDir('••مغامرات••',baseurl+'/all/%d9%85%d8%ba%d8%a7%d9%85%d8%b1%d9%87/',100,'img/4.png','',1)
        addDir('••كـــومديـــا••',baseurl+'/all/%d9%83%d9%88%d9%85%d9%8a%d8%af%d9%8a/',100,'img/5.png','',1)
        addDir('••درامــــــــــــا••',baseurl+'/all/%d8%af%d8%b1%d8%a7%d9%85%d8%a7/',100,'img/6.png','',1)
        addDir('••الحرب••',baseurl+'/all/%d8%ad%d8%b1%d8%a8/',100,'img/7.png','',1)
        addDir('••أفلام أكشــــن••',baseurl+'/all/%d8%a7%d9%83%d8%b4%d9%86/',100,'img/8.png','',1)
        addDir('••الخيال العلمي••',baseurl+'/all/%d8%ae%d9%8a%d8%a7%d9%84-%d8%b9%d9%84%d9%85%d9%8a/',100,'img/12.png','',1)
        
        
        

        
        
def years(url):

        addDir('2018',baseurl+'/?type=year&s=2018',116,'img/4.png','',1)        

        addDir('2017',baseurl+'/?type=year&s=2017',116,'img/7.png','',1)        

        addDir('2016',baseurl+'/?type=year&s=2016',116,'img/1.png','',1)        
        addDir('2015',baseurl+'/?type=year&s=2015',116,'img/2.png','',1)      
        addDir('2014',baseurl+'/?type=year&s=2014',116,'img/5.png','',1)
        addDir('2013',baseurl+'/?type=year&s=2013',116,'img/6.png','',1)        
        addDir('2012',baseurl+'/?type=year&s=2012',116,'img/3.png','',1)      
        addDir('2011',baseurl+'/?type=year&s=2011',116,'img/8.png','',1)
        addDir('2010',baseurl+'/?type=year&s=2010',116,'img/7.png','',1)        
        addDir('2009',baseurl+'/?type=year&s=2009',116,'img/6.png','',1)      
        addDir('2008',baseurl+'/?type=year&s=2008',116,'img/16.png','',1)
        addDir('2007',baseurl+'/?type=year&s=2007',116,'img/2.png','',1)      
        addDir('2006',baseurl+'/?type=year&s=2006',116,'img/3.png','',1)      
        addDir('2005',baseurl+'/?type=year&s=2005',116,'img/4.png','',1)
        addDir('2004',baseurl+'/?type=year&s=2004',116,'img/3.png','',1)        
        addDir('2003',baseurl+'/?type=year&s=2003',116,'img/7.png','',1)        

        
        
        
def WWE(url):
        addDir('WWE',baseurl+'/cat/other-shows/',100,'img/11.png','',1)        
        addDir('WWE-SMAK-DOWN',baseurl+'/cat/smack-down/',100,'img/11.png','',1)      
        addDir('WWE-RAW',baseurl+'/cat/raw/',100,'img/11.png','',1)
        

####################movies		
               
def getyears_movies(url):
        for i in range(2002,2016):
             addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                    
def getgenre_movies(url):
        #http://www.vidics.ch/Category-Movies/Genre-comedy/Letter-Any/ByPopularity/1.htm
        genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
        for item in genrelist:
                
                 addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-Movies'),100,'http://i45.tinypic.com/2d9u26c.jpg','',1)
        

                            
                    


def getA_Z_movies(name,mode):
        AZ_DIRECTORIES = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z']
        for character in AZ_DIRECTORIES:
                #http://www.vidics.ch/Category-Movies/Genre-Any/
                addDir(character,"http://www.vidics.ch/"+name+"/Genre-Any/Letter-"+character+"/ByPopularity/1.htm",mode,"",'',1)
                        
                                  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
       # search_entered=urllib.quote_plus(search_entered)   
       #url=url+search_entered
        print "mfarajx4_url",url
        
        search_series2("Search",search_entered,1)


def search_series2(name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  #http://movizland.online/?s=30+%D9%8A%D9%88%D9%85&page=2
                   url_page='http://movizland.online/?s='+urlmain+'&page='+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                      url='http://movizland.online/?s='+urlmain
                      url_page=url
                print "page",page
               
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('class="block"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''href="(.*?)"'''
                   
                    regx='<li><a href="(.*?)">سيرفرات اضافية</a></li>'                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    print "href",href
                   
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="bottom-title"> <a href=".*?" title="(.*?)">'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                                       
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,555,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                

                   

def getmovies(main_name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)
                  url_page=urlmain+"/page/"+str(page)+"/"
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    #regx='''href="(.*?)"'''
                    regx='<a href="(.*?)">سيرفرات اضافية</a></li>'
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''title="(.*?)"'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,main_name,1,True)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))



def getaddtmovies(main_name,urlmain,page):##movies
                if page>1:
                  url_page=urlmain+'/?page='+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''href="(.*?)"'''
                    regx='<li><a href="(.*?)">سيرفرات اضافية</a></li>'
                    
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="bottom-title"> <a href=".*?" title="(.*?)">'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,main_name,1,True)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,10000,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
def getboxmovies(main_name,urlmain,page):##movies
                if page>1:
                  url_page=baseurl+'/tags/page/'+str(page)+'/?q=boxoffice'
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    regx='<li><a href="(.*?)">سيرفرات اضافية</a></li>'
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="bottom-title"> <a href=".*?" title="(.*?)">'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,main_name,1,True)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,106,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def ReqVideos(name,urlmain,page):


                if page>1:
                  url_page=baseurl+'/tags/page/'+str(page)+'/?q=submition'
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''href="(.*?)"'''
                    regx='<li><a href="(.*?)">سيرفرات اضافية</a></li>'
                    
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="bottom-title"> <a href=".*?" title="(.*?)">'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,136,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                    
def gethdmovies(main_name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=baseurl+'/?type=quality&s=720p+HDTV&page='+str(page)+''
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''href="(.*?)"'''
                    regx='<li><a href="(.*?)">سيرفرات اضافية</a></li>'
                    
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="bottom-title"> <a href=".*?" title="(.*?)">'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,main_name,1,True)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,126,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
def getyears(name,urlmain,page):##movies
                    
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'&page='+str(page)+"/"

                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''href="(.*?)"'''
                    regx='<li><a href="(.*?)">سيرفرات اضافية</a></li>'
                    
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="bottom-title"> <a href=".*?" title="(.*?)">'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,116,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))


        
def search_movies(main_name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  url_page=urlmain+str(page)+"/"
                  url_page=urlmain+'/?page='+str(page)+"/"
                  
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split(' <!-- cd-item -->')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                            
                            
                    
                    regx='''data-permalink="(.*?)" data-content="" class="cd-item">'''
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
        
                            
                            
                            
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                    

                   
                    #regx='''<div class="small-play">'''
                    
                    regx='''<div class="Bottomtitle"><a href=".*?">(.*?)</a>'''
                    #regx='''<a href="(.*?)" title="(.*?)</a>'''
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,main_name,1,True)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,1000,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
###############################################tv shows
def getyears_series(url):
        for i in range(2002,2016):
             addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                    
def getgenre_series(url):
       
        genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
        for item in genrelist:
                
          addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-Movies'),100,'http://i45.tinypic.com/2d9u26c.jpg',1)
        

                            
                    


def getA_Z_series(name,mode):
        AZ_DIRECTORIES = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z']
        for character in AZ_DIRECTORIES:
                
                addDir(character,"http://www.vidics.ch/"+name+"/Genre-Any/Letter-"+character+"/ByPopularity/1.htm",mode,"")
                        
                                                      
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getseries_search("Search",url,0)
                    

               
                                    
def getseries(main_name,urlmain,page):##series
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)+"/"
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a .*? href="(.*?)">'''
                    regx='<li><a href="(.*?)">سيرفرات اضافية</a></li>'
                    
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="bottom-title"> <a href=".*?" title="(.*?)">'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,main_name,1,True)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
def getseries_search(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                 
                  url1=os.path.split(urlmain)[0]
                  url_page=url1+"/"+str(page)+".htm"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split(" <option value='none'")[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<option')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)" title="(.*?)">'''
                    regx='''value='(.*?)'>(.*?)</option>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    href=match[0][0]
                    name=match[0][1]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    year=''
                    img=''

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:name=str(name)+"("+year+")"
                    except:name=str(name)
                    
                    
                    try:addDir(name,href,2001,img,'',1)
                    except:pass
               
                   
                
                
                                                            

def getseasons(name,urlmain,page):##series
                print "page",page
            
                if page>1:
                  
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                print "data",data
                
                if not "<option value='none' selected>=" in data:
                        gethosts(urlmain)
                        return                   
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="moviefilm">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*?src="(.*?)"'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regx='''<div class="movief"><a href="(.*?)">(.*?)</a></div>'''
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    #name=removeunicode(name)
                    try:addDir(name,href,201,img,'',1)
                    except:pass
               
                   
                
               
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    

               
                   
                
               
                
def getAddseries(name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://hakchouf.tv/english-movies/2/
                  #     
                  #url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+'?page='+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)+"/"
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('class="block"')
                i=0
                
                names=''
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''href="(.*?)"'''
                    #regx='<li><a href="(.*?)">سيرفرات اضافية</a></li>'
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''src="(.*?)"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()    
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="bottom-title"> <a href=".*?" title="(.*?)">'''

                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                    try:name=name.split('الحلقه')[0]
                    except:pass                                             
                    if not name=='' and name in names:
                            continue
                    names=names+","+name
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,133,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))



def getepisodes(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                 
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                
                   
               
                if data is None:
                    return
               
                blocks=data.split('</a>')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    block=block.replace("\n","")
                    regx='''<a href="(.*?)".*?<em>(.*?)</em>'''
                    match=re.findall(regx,block, re.M|re.I)  
                    for href,name in match:                 
                        name= "episode"+ " "+name.strip()
                    try:name=name.encode("utf-8")
                    except:name=str(name)
            
                    try:addDir(name,href,1,'img/00.jpg','',1)
                    except:pass
       
               
                   
                
               #addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    
                    

               
                           
                        


        #######################################host resolving                                                    
def resolve_moashada(url):
                    from addon.common.net import Net
                    net=Net()
                    import re,time
                    print "url",url
                    #sys.exit(0)            

                    html=readnet(url)
                                      
                    id = re.findall('<input type="hidden" name="id" value="(.*?)">',html, re.M|re.I)[0]
                    fname = re.findall('<input type="hidden" name="fname" value="(.*?)">',html, re.M|re.I)[0]
                    hash = re.findall('<input type="hidden" name="hash" value="(.*?)">',html, re.M|re.I)[0]
                    action = re.findall('''<Form method="POST" action='(.*?)'>''',html, re.M|re.I)[0]
                    print "id,fname,hash,action",id,fname,hash,action
                    time.sleep(10)
                    #sys.exit(0)
                    data= {
                        'imhuman': "Proceed to video",    
                        'op': 'download1',
                        'usr_login': '',
                        'id': id,
                        'fname': fname,
                        'referer': '',
                        'method': 'POST',
                        'action': action,
                        'hash': hash}   
                    result=net.http_POST(url, data, headers={}, compression=True).content
                    print "result",result.encode("utf-8")
                    regx2='''file:"(.*?)",label:"(.*?)"'''
                    result=result.split('jwplayer("vplayer").setup')[2]
                    match2 = re.findall(regx2,result, re.M|re.I)
                    href='''http://163.172.32.146/hls/l7y2x4s6drmjvkrxw47cafcoimydxs2xi5ogml57t,a2qdxbbinzhfhtpzfda,y5qbxbbinzcjygaqata,q5qbxbbinzdxkkkqcoa,.urlset/master.m3u8"},{file:"http://163.172.32.146/l7y2x4s6drmjvkrxw47cafcoimydxs2xi5ogml57ta2qdxbbinzhfhtpzfda/v.mp4'''
                    i=0
                    for href,qual in match2:
                            
                            if 'm3u8' in href:
                                    hrefs=href.split(".m3u8")
                                    href1=hrefs[0]+".m3u8"
                                    href2=finddata(href,'file:"',".mp4")+".mp4"
                                    addDir("m3u8",href1,11,"","",1)
                                    addDir("hd",href2,11,"","",1)
                                    continue
                                    
                            addDir(qual,href,11,"","",1)
def get_servers(name,url,img):
                import xbmctools
                data=readnet(url)
                data1=data
                #regx='''href="(.+?)">ذهاب الان</a>'''
                #regx='href="(.+?)">.+?</a>'
                #regx2='''font-size: 25px;" href="(.+?)">.+?</a>'''
                #regx2='''<a rel="nofollow" href="(.+?)" target="_blank">'''
                #match2 = re.findall(regx2,data, re.S)
               
                #regx2='''<a rel="nofollow" href="(.+?)" target="_blank">.+?</a><br'''                
                #new_url=match2[0]
                #print "new_url",new_url
                #data2=readnet(new_url)
                #try:
                       # data2=data2.split('سيرفرات المشاهده')[1]
                #except:
                       # pass
                regx='''href="http://e5tsar.com/(.+?)"'''
                
                match = re.findall(regx,data, re.S)
               
                        
                for link in match:
                        href='http://e5tsar.com/'+link
                        print "href",href
                        data=readnet(href)
                        regx='''<a href='(.+?)'.+?Click to get your link'''
                        link = re.findall(regx,data,re.M|re.I)[0]
                        
                        print "link",link
                        server,image,issupported=getDomain(link)
                        if issupported:
                           addDir(server+"-"+name,link,2,img,name,1)
                        
                        
                regx='''href="http://moshahda.online/(.+?)"'''
                match = finddata(data1,'moshahda.online','.html')
                
                print "match4",match
                if match:
                    href="http://moshahda.online/"+match+".html"
                     
                    resolve_moashada(href)
					
					
					
					
					
					
					
					
					
					
					
					
					
def start():                    
        params=get_params()
        url=None
        name=None
        mode=None
        page=1


        name=params.get("name",None)
        url=params.get("url",None)
        try:mode=int(params.get("mode",None))
        except:mode=None
        image=params.get("image",None)
        section=params.get("section",None)
        page=int(params.get("page",1))
        extra=params.get("extra",None)
        show=params.get("show",None)





        print "Mode1: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "Image: "+str(image)
        print "page: "+str(page)
        print "section: "+str(section)
        print "show: "+str(show)
        print "extra: "+str(extra)
        if mode==None :
                print ""
                #parsearabseed()
                showmenu()
        ##parsing tools        
        elif mode==1:
                print ""+url
                get_servers(name,url,image)
                
        elif mode==2:
                print ""+url
                resolvehost(item,name,url)     
        elif mode==10:
                print ""+url
                gethosts2(name,url,image)

        elif mode==11:
                playlink(Item,name,url)             

        elif mode==55:
                print ""+url                        
                GENRES(url)
        elif mode==20:
                print ""+url
                resolve_host2(url)          
        ####movies        
        elif mode==100:
                print ""+url
                getmovies(name,url,page)
        elif mode==1000:
                print ""+url
                search_movies(name,url,page)        
        elif mode==10000:
                print ""+url     
                getaddtmovies(name,url,page) 
        elif mode==116:
                print ""+url     
                
                getyears(name,url,page)
                
        elif mode==126:
                print ""+url     
                
                gethdmovies(name,url,page) 
        elif mode==133:
                print ""+url     
                getAddseries(name,url,page) 
        elif mode==106:
                print ""+url     
                
                getboxmovies(name,url,page)
        elif mode==136:
                print ""+url     
                
                
                ReqVideos(name,url,page) 
        elif mode==101:
                print ""+url
                getgenre_movies('movies')	

        elif mode==102:
                
                getA_Z_movies(name,100)

        elif mode==103:
                print ""+url
                
                getyears_movies(name)
                
                        
        elif mode==104:
                print ""+url
                search(url)

        elif mode==105:
                print ""+url
                
                getmovies_search(url)

        ###series        
        elif mode==200:
                
                getseries(name,url,page)
        elif mode==222:	
                getseries3(name,url,page)
                
        elif mode==2000:
                
                getseries2(name,url,page)
                
        elif mode ==555:
                search_series2(name,url,page)
        elif mode==201:
                
                getseasons(name,url,page)
                
        elif mode==202:
                getepisodes(name,url,page)
        elif mode==203:
                
                getA_Z_series(name,100)

        elif mode==28:
                print ""+url        
                WWE(url)
                
        elif mode==800:
                print ""+url                
                years(url) 
        elif mode==30:
                print ""+url        
                GENRES(url)
        elif mode==3:
                print ""+url
                search(url)		

        elif mode==6:
                print ""+url
                get_hostlink(url)
        elif mode==7:
                resolve_host(url)
        elif mode==8:
                playlink(url)
        elif mode==9:        
           getVideos_search
        elif mode==20:
                getseries(name,url,page)
        return endDir()
start()
